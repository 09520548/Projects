//
//  GlobalData.h
//  Watsup
//
//  Created by NhiepPhong on 6/16/13.
//  Copyright (c) 2013 NhiepPhong. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AppDelegate.h"

@interface GlobalData : NSObject

@property (nonatomic) float versionOS;
@property (nonatomic, retain) NSString *tokenDevice;
@property (nonatomic, retain) NSString *deviceModel;
@property (nonatomic, retain) NSDictionary *userInfo;
@property (nonatomic, retain) NSString *keyConnectApp;
@property (nonatomic, retain) NSString *language;
@property (nonatomic, retain) NSDictionary *dataNotification;
@property (nonatomic, retain) NSString* linkThumbCoupon;
@property (nonatomic, retain) NSDictionary *advertisement;
@property (nonatomic, retain) NSArray *dataCity;
@property (nonatomic, retain) NSArray *dataPlace;
@property (nonatomic, retain) NSArray *dataDishes;
@property (nonatomic, retain) NSArray *dataPlaceCheckin;


+ (GlobalData *)shareGlobalData;

- (NSDictionary *)getUserInfo;
- (void) saveUserInfo:(NSDictionary *)dt;
- (void) clearUserInfo;

- (NSString *)getLanguage;
- (void) saveLanguage:(NSString *)dt;
- (void) clearLanguage;

- (BOOL)validateEmail:(NSString *)emailStr;

- (UIImage *) imageWithView:(UIView *)view;
- (void) showAlert:(NSString*)mess Title:(NSString *)title;
- (UIView *)createViewLoading;

- (CGFloat)widthOfString:(NSString *)string withFont:(UIFont *)font andMaxWidth:(CGFloat)max;
@end
