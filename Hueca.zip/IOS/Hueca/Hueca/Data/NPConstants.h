//
//  NPConstants.h
//  PhimSoc
//
//  Created by NhiepPhong on 1/9/13.
//  Copyright (c) 2013 Climaxinteractive. All rights reserved.
//

#ifndef Watsup_NPConstants_h
#define Watsup_NPConstants_h

//#define HOST @"http://localhost/Cty/mobile/2014_wizard_hueca_locationapp_cms/Code/Server/"
#define HOST @"http://la-hueca.com/api_mobile/"


#define METERS_PER_MILE 1609.344

#define LINK_LOGIN                       HOST @"login"
#define LINK_REGISTER                    HOST @"register"
#define LINK_GET_USER                    HOST @"getInfoUser"
#define LINK_GET_CITY                    HOST @"loadCity"
#define LINK_GET_PLACE                   HOST @"loadPlaces"
#define LINK_FORGET_PASSWORD             HOST @"user/forget_password"
#define LINK_UPDATE_PROFILE              HOST @"updateProfileUser"
#define LINK_GET_LIST_FOR_CATE           HOST @"getListRest"
#define LINK_GET_DETAIL_RESTAURANT       HOST @"detailRestaurant"
#define LINK_GET_HOME_RESTAURANT         HOST @"getListRestHome"
#define LINK_GET_CHECKIN_RESTAURANT      HOST @"checkinRest"
#define LINK_GET_FAVOURITE_RESTAURANT    HOST @"favRest"
#define LINK_GET_SHARE_RESTAURANT        HOST @"shareRest"
#define LINK_GET_PHOTO_RESTAURANT        HOST @"listPhotoRest"
#define LINK_GET_COMMENT                 HOST @"listComment"
#define LINK_GET_FEED                    HOST @"getListFeed"
#define LINK_GET_RANKING                 HOST @"rankingUsers"
#define LINK_GET_PROFILE                 HOST @"getDetailUser"
#define LINK_GET_ACTIVITY                HOST @"getActivityUser"
#define LINK_ADD_RESTAURANT              HOST @"addNewRestaurant"
#define LINK_ADD_MAKE_REVIEW             HOST @"makeReview"
#define LINK_GET_DISHES                  HOST @"loadDishes"
#define LINK_GET_LISTCOMMENT             HOST @"commentPhotosRest"
#define LINK_GET_AUTOCOMPLE              HOST @"autocomplete"

#define LINK_DOWNLOAD_GAME  @"https://itunes.apple.com/us/app/number-khoanh-so/id822431696?ls=1&mt=8"

#endif

