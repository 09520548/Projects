//
//  GlobalData.m
//  Watsup
//
//  Created by NhiepPhong on 6/16/13.
//  Copyright (c) 2013 NhiepPhong. All rights reserved.
//

#import "GlobalData.h"


@implementation GlobalData

static GlobalData *shareGlobalData = nil;

+ (GlobalData *) shareGlobalData
{
    if (shareGlobalData == nil) {
        shareGlobalData = [[super allocWithZone:NULL] init];
        shareGlobalData.tokenDevice = @"";
        shareGlobalData.deviceModel = @"";
        shareGlobalData.versionOS = 0;
        shareGlobalData.userInfo = nil;
        shareGlobalData.keyConnectApp = @"KdwAcfRdw";
        shareGlobalData.language = @"";
        shareGlobalData.dataNotification = nil;
        shareGlobalData.linkThumbCoupon = @"";
        shareGlobalData.advertisement = nil;
        shareGlobalData.dataCity = [NSArray new];
        shareGlobalData.dataPlace = [NSArray new];
        shareGlobalData.dataDishes = [NSArray new];
        shareGlobalData.dataPlaceCheckin = [NSArray new];
    }
    return shareGlobalData;
}

/*
 *  ===== USER ====
 */
- (NSDictionary *)getUserInfo
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSDictionary *loadString = [defaults objectForKey:@"user_info"];
    if (loadString != nil)
    {
        shareGlobalData.userInfo = loadString;
    }
    
    return shareGlobalData.userInfo;
}

- (void) saveUserInfo:(NSDictionary *)dt
{
    shareGlobalData.userInfo = dt;
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:dt forKey:@"user_info"];
    [defaults synchronize];
}

- (void) clearUserInfo
{
    shareGlobalData.userInfo = nil;
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:nil forKey:@"user_info"];
    [defaults synchronize];
}

/*
 *  ===== LANGUAGE ====
 */
- (NSString *)getLanguage
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *loadString = [defaults objectForKey:@"language"];
    if (loadString != nil)
    {
        shareGlobalData.language = loadString;
    }
    
    return shareGlobalData.language;
}

- (void) saveLanguage:(NSString *)dt
{
    shareGlobalData.language = dt;
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:dt forKey:@"language"];
    [defaults synchronize];
}

- (void) clearLanguage
{
    shareGlobalData.language = @"";
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:@"" forKey:@"language"];
    [defaults synchronize];
}

- (UIImage *) imageWithView:(UIView *)view
{
    UIGraphicsBeginImageContextWithOptions(view.bounds.size, view.opaque, 0.0);
    [view.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage*img=UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    UIGraphicsEndImageContext();
    
    return img;
}

- (BOOL)validateEmail:(NSString *)emailStr
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:emailStr];
}

#pragma mark - Alert
- (void) showAlert:(NSString*)mess Title:(NSString *)title
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
                                                        message:mess
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
    [alertView show];
    
}

- (UIView *)createViewLoading
{
//    UIView *loadingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 290, 100)];
//    
//    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 290, 30)];
//    title.textColor = [UIColor colorFromHexString:@"#282828"];
//    title.font = [UIFont rw_FontBoldWithSize:16];
//    title.textAlignment = NSTextAlignmentCenter;
//    title.text = @"Connecting to server";
//    [loadingView addSubview:title];
//    
//    UILabel *content = [[UILabel alloc] initWithFrame:CGRectMake(0, 30, 290, 30)];
//    content.textColor = [UIColor colorFromHexString:@"#282828"];
//    content.font = [UIFont rw_FontRegularWithSize:14];
//    content.textAlignment = NSTextAlignmentCenter;
//    content.text = @"Processing..";
//    [loadingView addSubview:content];
    
//    UIActivityIndicatorView *spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
//    spinner.color = [UIColor colorFromHexString:@"#167beb"];
//    spinner.center = CGPointMake(139.5, 75.5);
//    [spinner startAnimating];
    
    NSArray *imageNames = @[@"logo_hueca_0.png", @"logo_hueca_1.png", @"logo_hueca_2.png", @"logo_hueca_3.png",
                            @"logo_hueca_4.png", @"logo_hueca_5.png", @"logo_hueca_6.png", @"logo_hueca_7.png",
                            @"logo_hueca_8.png", @"logo_hueca_9.png", @"logo_hueca_10.png", @"logo_hueca_11.png",
                            @"logo_hueca_12.png", @"logo_hueca_13.png", @"logo_hueca_14.png", @"logo_hueca_15.png", @"logo_hueca_16.png", @"logo_hueca_17.png", @"logo_hueca_18.png",
                            @"logo_hueca_19.png", @"logo_hueca_20.png", @"logo_hueca_21.png", @"logo_hueca_22.png", @"logo_hueca_23.png", @"logo_hueca_24.png"];
    
    NSMutableArray *images = [[NSMutableArray alloc] init];
    for (int i = 0; i < imageNames.count; i++) {
        [images addObject:[UIImage imageNamed:[imageNames objectAtIndex:i]]];
    }
    
    // Normal Animation
    UIImageView *animationImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 75, 45)];
    animationImageView.animationImages = images;
    animationImageView.animationDuration = 1;
//    animationImageView.center = CGPointMake(139.5, 75.5);
    [animationImageView startAnimating];
//    [loadingView addSubview:animationImageView];
    
    return animationImageView;
}

- (CGFloat)widthOfString:(NSString *)string withFont:(UIFont *)font andMaxWidth:(CGFloat)max
{
    CGSize theSize = [string sizeWithFont:font forWidth:max lineBreakMode:NSLineBreakByWordWrapping];
    return theSize.width;
}
@end
