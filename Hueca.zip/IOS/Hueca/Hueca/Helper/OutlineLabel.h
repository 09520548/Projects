//
//  OutlineLabel.h
//  Hueca
//
//  Created by Mobiz on 6/18/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OutlineLabel : UILabel
{
    BOOL drawOutline;
    BOOL drawGradient;
}

@property BOOL drawOutline;
@property BOOL drawGradient;

@end
