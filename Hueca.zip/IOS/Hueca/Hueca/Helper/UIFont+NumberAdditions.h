
@interface UIFont (NumberAdditions)

+ (id)rw_FontRegularWithSize:(CGFloat)size;
+ (id)rw_FontItalicWithSize:(CGFloat)size;
+ (id)rw_FontBoldItalicWithSize:(CGFloat)size;
+ (id)rw_FontBoldWithSize:(CGFloat)size;

@end
