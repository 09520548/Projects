
#import "UIFont+NumberAdditions.h"

@implementation UIFont (NumberAdditions)

+ (id)rw_FontRegularWithSize:(CGFloat)size
{
	return [UIFont fontWithName:@"Oxygen" size:size];
}
+ (id)rw_FontItalicWithSize:(CGFloat)size
{
	return [UIFont fontWithName:@"Oxygen-Italic" size:size];
}
+ (id)rw_FontBoldItalicWithSize:(CGFloat)size
{
	return [UIFont fontWithName:@"Oxygen-BoldItalic" size:size];
}
+ (id)rw_FontBoldWithSize:(CGFloat)size
{
	return [UIFont fontWithName:@"Oxygen-Bold" size:size];
}

@end
