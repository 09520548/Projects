//
//  NumberBudget.h
//  TimMuaOto
//
//  Created by SiNguyen on 12/16/13.
//  Copyright (c) 2013 NhiepPhong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NumberBudget : UIView
{
    UIFont *_font;
    UIColor *_color;
    UILabel *label;
}

- (id)initFont:(UIFont*)font color:(UIColor*)color;
- (void)setText:(int)v;
- (int) getNumber;

@property (nonatomic, strong) NSString *txt;

@end
