//
//  NumberBudget.m
//  TimMuaOto
//
//  Created by SiNguyen on 12/16/13.
//  Copyright (c) 2013 NhiepPhong. All rights reserved.
//

#import "NumberBudget.h"
#import <QuartzCore/QuartzCore.h>

@implementation NumberBudget
@synthesize txt = _txt;

- (id)initFont:(UIFont*)font color:(UIColor*)color
{
    self = [super initWithFrame:CGRectMake(0.0f, 0.0f, 20.0f, 20.0f)];
    if (self)
    {
        _txt = nil;
        _font = font;
        _color = color;
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 20, 20)];
        label.textColor = color;
        label.textAlignment = NSTextAlignmentCenter;
        label.font = font;
        label.backgroundColor = [UIColor colorFromHexString:@"#f35050"];
        [label setOpaque:YES];
        
        label.layer.cornerRadius = 10.0;
        label.layer.masksToBounds = YES;
        
        [self addSubview:label];
        [self setBackgroundColor:[UIColor clearColor]];
        [self setOpaque:YES];
        
    }
    return self;
}

- (void)setText:(int)v
{
    NSString *text = [NSString stringWithFormat:@"%d", v];

    if(v == 0)
    {
        [self setHidden:YES];
    }
    else
    {
        [self setHidden:NO];
    }
    _txt = text;
    
    label.text = _txt;
    
    CGSize maximumLabelSize = CGSizeMake(100, 20);
    CGSize expectedLabelSize = [_txt sizeWithFont:_font constrainedToSize:maximumLabelSize lineBreakMode:label.lineBreakMode];
    
    CGRect newFrame = label.frame;
    newFrame.size.width = expectedLabelSize.width + 10;
    if(newFrame.size.width < 20)
    {
        newFrame.size.width = 20;
    }
    label.frame = newFrame;
    
    CGRect frame = self.frame;
    frame.size.width = newFrame.size.width;
    //set X
    frame.origin.x = frame.origin.x - frame.size.width/2;
    self.frame = frame;
}

- (int) getNumber
{
    return  [label.text intValue];
}

@end
