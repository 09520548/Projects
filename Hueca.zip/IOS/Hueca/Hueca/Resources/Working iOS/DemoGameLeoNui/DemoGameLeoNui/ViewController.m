//
//  ViewController.m
//  DemoGameLeoNui
//
//  Created by Mobiz on 3/7/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    [[UIAccelerometer sharedAccelerometer]setDelegate:self];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)accelerometer:(UIAccelerometer *)accelerometer didAccelerate:(UIAcceleration *)acceleration
{
    [self.xLabel setText:[NSString stringWithFormat:@"%f",acceleration.x]];
    [self.yLabel setText:[NSString stringWithFormat:@"%f",acceleration.y]];
    [self.zLabel setText:[NSString stringWithFormat:@"%f",acceleration.z]];
}

@end
