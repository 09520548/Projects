//
//  NMoviePlayerVC.m
//  MaxChat
//
//  Created by Nho Nguyen on 11/29/12.
//  Copyright (c) 2012 Climax Interactive. All rights reserved.
//

#import "NMoviePlayerVC.h"

@implementation NMoviePlayerVC

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
{
    return UIInterfaceOrientationIsLandscape(toInterfaceOrientation);
}

@end
