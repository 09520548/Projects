//
//  NImageLoader.h
//  MaxChat
//
//  Created by Nho Nguyen on 10/3/12.
//  Copyright (c) 2012 Climax Interactive. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NURLCache.h"

@class NImageLoader;

@protocol NImageLoaderDelegate <NSObject>

@required
- (void)loader:(NImageLoader*)loader didLoadImage:(UIImage*)image;

@optional
- (void)loader:(NImageLoader*)loader didLoadError:(NSError*)error;

@end

@interface NImageLoader : NSObject

- (id)initWithURL:(NSString*)url;
- (void)load;
- (UIImage*)loadWithCache:(NURLCache*)cache;

- (id)initWithURL:(NSString*)url delegate:(id<NImageLoaderDelegate>)delegate;
- (id)initWithURL:(NSString*)url completeHandler:(void(^)(UIImage*))handler;

- (void)cancel;

@end
