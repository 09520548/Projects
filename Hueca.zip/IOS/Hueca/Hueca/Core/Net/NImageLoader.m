//
//  NImageLoader.m
//  MaxChat
//
//  Created by Nho Nguyen on 10/3/12.
//  Copyright (c) 2012 Climax Interactive. All rights reserved.
//

#import "NImageLoader.h"

@interface NImageLoader() <NSURLConnectionDelegate, NSURLConnectionDataDelegate>
{
    NSURLConnection *_connection;
    NSMutableData *_data;
    NSString *_url;
    NSString *_key;
    NURLCache *_cache;
    
    id<NImageLoaderDelegate> _delegate;
    void (^_completeHandler)(UIImage*);
}
- (void)loadURL:(NSString*)url;
@end

@implementation NImageLoader

- (id)initWithURL:(NSString *)url
{
    self = [super init];
    
    if(self)
    {
        _completeHandler = NULL;
        _delegate = nil;
        _url = url;
        _cache = nil;
        _key = nil;
    }
    return self;
}

- (void)load
{
    _cache = nil;
    _key = nil;
    
    [self loadURL:_url];
}

- (UIImage*)loadWithCache:(NURLCache *)cache
{
    NSData *data = nil;
    
    _cache = cache ? cache : [NURLCache shareCache];
    _key = [NURLCache keyForURL:_url];
    
    data = [_cache cacheForKey:_key];
    
    if(data)
    {
        UIImage *image = [UIImage imageWithData:data];
        
        if(image)
        {
            return image;
        }
    }
    [self loadURL:_url];
    return nil;
}

- (id)initWithURL:(NSString *)url delegate:(id<NImageLoaderDelegate>)delegate
{
    self = [self initWithURL:url];
    
    if(self)
    {
        _delegate = delegate;
    }
    return self;
}

- (id)initWithURL:(NSString *)url completeHandler:(void (^)(UIImage *))handler
{   
    self = [self initWithURL:url];
    
    if(self)
    {
        _completeHandler = handler;
    }
    return self;
}

- (void)loadURL:(NSString *)url
{
    _data = nil;
    _connection = [NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]] delegate:self];
}

- (void)clean
{
    _completeHandler = NULL;
    _delegate = nil;
    _data = nil;
    _connection = nil;
    _url = nil;
    _cache = nil;
    _key = nil;
}

- (void)cancel
{
    if(_connection)
    {
        [_connection cancel];
    }
    [self clean];
}

- (void)didError:(NSError*)error
{
    if(_delegate && [_delegate respondsToSelector:@selector(loader:didLoadError:)])
    {
        [_delegate loader:self didLoadError:error];
    }
    
    [self clean];
}

- (void)didFinish:(UIImage*)image
{
    if(_delegate)
    {
        [_delegate loader:self didLoadImage:image];
    }
    if(_completeHandler)
    {
        _completeHandler(image);
    }
    [self clean];
}

#pragma mark - NSURLConnectionDataDelegate

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    if(_data)
    {
        [_data appendData:data];
    }
    else
    {
        _data = [NSMutableData dataWithData:data];
    }
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    if(_data)
    {
        UIImage *image = [UIImage imageWithData:_data];
        
        if(image)
        {
            if(_cache && _key)
            {
                [_cache setCache:_data forKey:_key];
            }
            [self didFinish:image];
        }
        else
        {
            [self didError:nil];
        }
    }
}

#pragma mark - NSURLConnectionDelegate

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    [self didError:error];
}

@end
