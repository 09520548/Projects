//
//  NLoader.m
//  MaxChat
//
//  Created by Nho Nguyen on 10/1/12.
//  Copyright (c) 2012 Climax Interactive. All rights reserved.
//

#import "NLoader.h"
#import "SBJson.h"

@implementation NLoader

+ (NSDictionary*)jsonData:(NSData *)data
{
    if(data)
    {
        NSError *error = nil;
        SBJsonParser *parser = [[SBJsonParser alloc] init];
        NSDictionary *json = [parser objectWithData:data];
        
        if(error == nil)
        {
            return json;
        }
        else
        {
            NSLog(@"NLoader.jsonData: Error\n%@", [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]);
        }
    }
    
    return nil;
}

+ (NSDictionary*)jsonDataOfURL:(NSString *)url
{
    NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:url]];
    
    return [NLoader jsonData:data];
}

+ (NSDictionary*)jsonDataOfURLRequest:(NSURLRequest *)request
{
    NSError *error = nil;
    NSURLResponse *response = nil;
    NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    //NSLog(@"jsonDataOfURLRequest %@", data);
    
    if(error == nil && data)
    {
        return [NLoader jsonData:data];
    }
    return nil;
}

+ (NSDictionary*)jsonDataOfURLRequest:(NSURLRequest *)request cacheFile:(NSString*)cacheFile
{
    NSError *error = nil;
    NSURLResponse *response = nil;
    NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    if(error == nil && data)
    {
        [data writeToFile:cacheFile atomically:YES];
        
        return [NLoader jsonData:data];
    }
    
    if([[NSFileManager defaultManager] fileExistsAtPath:cacheFile])
    {
        data = [NSData dataWithContentsOfFile:cacheFile];
        
        if(data)
        {
            return [NLoader jsonData:data];
        }
    }
    
    return nil;
}

+ (NSDictionary*)jsonDataOfURL:(NSString *)url params:(NSDictionary *)params
{
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    NSMutableString *post = [NSMutableString string];
    
    for(NSString *key in params)
    {
        [post appendFormat:@"%@=%@&", [key stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding], [[params valueForKey:key] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    }
    [post appendFormat:@"rnd=%d", rand()];
    [req setHTTPMethod:@"POST"];
    [req setHTTPBody:[post dataUsingEncoding:NSUTF8StringEncoding]];
    
    return [NLoader jsonDataOfURLRequest:req];
}

+ (NSDictionary*)jsonDataOfURL:(NSString *)url params:(NSDictionary *)params cacheFile:(NSString *)cacheFile
{
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    if(params)
    {
        NSMutableString *post = [NSMutableString string];
        
        for(NSString *key in params)
        {
            [post appendFormat:@"%@=%@&", [key stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding], [[params valueForKey:key] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
        }
        [post appendFormat:@"rnd=%d", rand()];
        [req setHTTPMethod:@"POST"];
        [req setHTTPBody:[post dataUsingEncoding:NSUTF8StringEncoding]];
    }
    
    return [NLoader jsonDataOfURLRequest:req cacheFile:cacheFile];
}

+ (NSDictionary*)jsonWithURL:(NSString *)url params:(NSDictionary *)params fileData:(NSData *)fileData
{
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    NSString *boundary = [NSString stringWithFormat:@"tinho%d7RYv64F", rand()];
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@",boundary];
    NSMutableData *body = [NSMutableData data];
    
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    
    if(params)
    {
        for(NSString *key in params)
        {
            [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n%@\r\n--%@\r\n", key, [params valueForKey:key], boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        }
    }
    
    [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"file\"; filename=\"%d.jpg\"\r\n", rand()] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"Content-Type: application/octet-stream\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:fileData];
    [body appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    
    [req setHTTPMethod:@"POST"];
    [req addValue:contentType forHTTPHeaderField: @"Content-Type"];
    [req setHTTPBody:body];
    
    return [NLoader jsonDataOfURLRequest:req];
}

+ (NSDictionary*)jsonWithURL:(NSString *)url params:(NSDictionary *)params listfileData:(NSArray *)listFile
{
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    NSString *boundary = [NSString stringWithFormat:@"tinho%d7RYv64F", rand()];
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@",boundary];
    NSMutableData *body = [NSMutableData data];
    
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    
    if(params)
    {
        for(NSString *key in params)
        {
            [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n%@\r\n--%@\r\n", key, [params valueForKey:key], boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        }
    }
    int i = 0;
    for (NSData*fileData in listFile)
    {
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"file[%d]\"; filename=\"%d.jpg\"\r\n",i, rand()] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[@"Content-Type: application/octet-stream\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:fileData];
        [body appendData:[[NSString stringWithFormat:@"\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
        
        i++;
    }
    
    [body appendData:[[NSString stringWithFormat:@"--%@--\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    
    [req setHTTPMethod:@"POST"];
    [req addValue:contentType forHTTPHeaderField: @"Content-Type"];
    [req setHTTPBody:body];
    
    return [NLoader jsonDataOfURLRequest:req];
}


+ (NImageLoader*)imageWithURL:(NSString *)url delegate:(id<NImageLoaderDelegate>)delegate
{
    NImageLoader *loader = [[NImageLoader alloc] initWithURL:url delegate:delegate];
    
    [loader load];
    
    return loader;
}

+ (NImageLoader*)imageWithURL:(NSString *)url completeHandler:(void (^)(UIImage *))handler
{
    NImageLoader *loader = [[NImageLoader alloc] initWithURL:url completeHandler:handler];
    
    [loader load];
    
    return loader;
}

+ (UIImage*)imageWithURL:(NSString *)url delegate:(id<NImageLoaderDelegate>)delegate cache:(NURLCache *)cache
{
    return [[[NImageLoader alloc] initWithURL:url delegate:delegate] loadWithCache:cache];
}

+ (UIImage*)imageWithURL:(NSString *)url completeHandler:(void (^)(UIImage *))handler cache:(NURLCache *)cache
{
    return [[[NImageLoader alloc] initWithURL:url completeHandler:handler] loadWithCache:cache];
}

+ (NSString*)stringData:(NSData*)data
{
    return data ? [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] : nil;
}

+ (NSString*)stringWithURL:(NSString *)url
{
    NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:url]];
    
    return [NLoader stringData:data];
}

+ (NSString*)stringWithURLRequest:(NSURLRequest *)request
{
    NSError *error = nil;
    NSURLResponse *response = nil;
    NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    if(error == nil && data)
    {
        return [NLoader stringData:data];
    }
    return nil;
}

+ (NSString*)stringWithURLRequest:(NSURLRequest *)request cacheFile:(NSString*)cacheFile
{
    NSError *error = nil;
    NSURLResponse *response = nil;
    NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    if(error == nil && data)
    {
        [data writeToFile:cacheFile atomically:YES];
        
        return [NLoader stringData:data];
    }
    
    if([[NSFileManager defaultManager] fileExistsAtPath:cacheFile])
    {
        data = [NSData dataWithContentsOfFile:cacheFile];
        
        if(data)
        {
            return [NLoader stringData:data];
        }
    }
    
    return nil;
}

+ (NSString*)stringWithURL:(NSString *)url params:(NSDictionary *)params
{
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    NSMutableString *post = [NSMutableString string];
    
    for(NSString *key in params)
    {
        [post appendFormat:@"%@=%@&", [key stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding], [[params valueForKey:key] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    }
    [post appendFormat:@"rnd=%d", rand()];
    [req setHTTPMethod:@"POST"];
    [req setHTTPBody:[post dataUsingEncoding:NSUTF8StringEncoding]];
    
    return [NLoader stringWithURLRequest:req];
}

+ (NSString*)stringWithURL:(NSString *)url params:(NSDictionary *)params cacheFile:(NSString *)cacheFile
{
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    if(params)
    {
        NSMutableString *post = [NSMutableString string];
        
        for(NSString *key in params)
        {
            [post appendFormat:@"%@=%@&", [key stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding], [[params valueForKey:key] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
        }
        [post appendFormat:@"rnd=%d", rand()];
        [req setHTTPMethod:@"POST"];
        [req setHTTPBody:[post dataUsingEncoding:NSUTF8StringEncoding]];
    }
    
    return [NLoader stringWithURLRequest:req cacheFile:cacheFile];
}

+ (NSString*)stringWithURL:(NSString *)url params:(NSDictionary *)params fileData:(NSData *)fileData
{
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    NSString *boundary = [NSString stringWithFormat:@"tinho%d7RYv64F", rand()];
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@",boundary];
    NSMutableData *body = [NSMutableData data];
    
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    
    if(params)
    {
        for(NSString *key in params)
        {
            [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n%@\r\n--%@\r\n", key, [params valueForKey:key], boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        }
    }
    
    [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"file\"; filename=\"%d.jpg\"\r\n", rand()] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"Content-Type: application/octet-stream\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:fileData];
    [body appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    
    [req setHTTPMethod:@"POST"];
    [req addValue:contentType forHTTPHeaderField: @"Content-Type"];
    [req setHTTPBody:body];
    
    return [NLoader stringWithURLRequest:req];
}

@end
