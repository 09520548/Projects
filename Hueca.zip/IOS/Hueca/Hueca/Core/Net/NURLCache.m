//
//  NURLCache.m
//  MaxChat
//
//  Created by Nho Nguyen on 11/20/12.
//  Copyright (c) 2012 Climax Interactive. All rights reserved.
//

#import "NURLCache.h"
#import "NApp.h"
#import "NSString+NMD5.h"

@interface NURLCache() <NSCacheDelegate>
{
    NSCache *_cache;
    NSString *_basePath;
}

@end

static NURLCache *NURLCache_shareCache = nil;

@implementation NURLCache

+ (NURLCache*)shareCache
{
    if(NURLCache_shareCache == nil)
    {
        NURLCache_shareCache = [[NURLCache alloc] initWithName:@"_NURLCache" capacity:5*1024*1024];
    }

    return NURLCache_shareCache;
}

+ (NSString*)keyForURL:(NSString *)url
{
    return [url MD5];
}

- (id)initWithName:(NSString*)name capacity:(NSUInteger)capacity
{
    self = [super init];
    
    if(self)
    {
        BOOL isDir = YES;
        NSFileManager *fman = [NSFileManager defaultManager];
        
        _cache = [[NSCache alloc] init];
        _basePath = [NApp documentDirectoryForName:name];
        
        if([fman fileExistsAtPath:_basePath isDirectory:&isDir])
        {
            NSError *error = nil;
            NSString *filename = nil;
            NSString *filepath = nil;
            NSUInteger filesize;
            NSDirectoryEnumerator *direnum = [fman enumeratorAtPath:_basePath];
            
            while((filename = [direnum nextObject]))
            {
                filepath = [_basePath stringByAppendingPathExtension:filename];
                filesize = [[fman attributesOfItemAtPath:filepath error:&error] fileSize];
                
                if(!error)
                {
                    [_cache setObject:filepath forKey:filename cost:filesize];
                }
            }
        }
        else
        {
            NSError *error = nil;
            
            [fman createDirectoryAtPath:_basePath withIntermediateDirectories:YES attributes:nil error:&error];
            
            if(error)
            {
                NSLog(@"Error: Create CACHE FOLDER failed");
                
                _basePath = nil;
            }
        }
        
        [_cache setCountLimit:capacity];
    }
    
    return self;
}

- (NSData*)cacheForKey:(NSString *)key
{
    NSString *path = [_cache objectForKey:key];
    
    if(path && [[NSFileManager defaultManager] fileExistsAtPath:path])
    {
        return [NSData dataWithContentsOfFile:path];
    }
    return nil;
}

- (void)setCache:(NSData *)data forKey:(NSString *)key
{
    if(data)
    {
        NSUInteger size = [data length];
        
        if(size > 0 && size < _cache.countLimit)
        {
            NSError *error = nil;
            NSString *path = [_basePath stringByAppendingPathComponent:key];
            
            [data writeToFile:path options:0 error:&error];
            
            if(!error)
            {
                [_cache setObject:path forKey:key cost:size];
            }
        }
    }
}

- (NSData*)cacheForURL:(NSString *)url
{
    return [self cacheForKey:[url MD5]];
}

- (void)setCache:(NSData *)data forURL:(NSString *)url
{
    [self setCache:data forKey:[url MD5]];
}

#pragma mark - NSCacheDelegate

- (void)cache:(NSCache *)cache willEvictObject:(id)obj
{
    if(_basePath)
    {
        NSFileManager *fman = [NSFileManager defaultManager];
        NSString *path = [_basePath stringByAppendingPathComponent:obj];
        
        if([fman fileExistsAtPath:path])
        {
            NSError *error = nil;
            
            [fman removeItemAtPath:path error:&error];
        }
    }
}

@end
