//
//  NLoader.h
//  MaxChat
//
//  Created by Nho Nguyen on 10/1/12.
//  Copyright (c) 2012 Climax Interactive. All rights reserved.
//

#import "NImageLoader.h"

#define kBgQueue dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0)

@interface NLoader : NSObject

+ (NSDictionary*)jsonData:(NSData*)data;
+ (NSDictionary*)jsonDataOfURL:(NSString*)url;
+ (NSDictionary*)jsonDataOfURLRequest:(NSURLRequest*)request;
+ (NSDictionary*)jsonDataOfURL:(NSString*)url params:(NSDictionary*)params;
+ (NSDictionary*)jsonDataOfURL:(NSString*)url params:(NSDictionary*)params cacheFile:(NSString*)cacheFile;
+ (NSDictionary*)jsonWithURL:(NSString *)url params:(NSDictionary *)params fileData:(NSData *)fileData;
+ (NSDictionary*)jsonWithURL:(NSString *)url params:(NSDictionary *)params listfileData:(NSArray *)listFile;

+ (NImageLoader*)imageWithURL:(NSString*)url delegate:(id<NImageLoaderDelegate>)delegate;
+ (NImageLoader*)imageWithURL:(NSString*)url completeHandler:(void(^)(UIImage*))handler;
+ (UIImage*)imageWithURL:(NSString*)url delegate:(id<NImageLoaderDelegate>)delegate cache:(NURLCache*)cache;
+ (UIImage*)imageWithURL:(NSString*)url completeHandler:(void(^)(UIImage*))handler cache:(NURLCache*)cache;
+ (NSString*)stringWithURL:(NSString*)url;
+ (NSString*)stringWithURL:(NSString*)url params:(NSDictionary*)params;
+ (NSString*)stringWithURL:(NSString*)url params:(NSDictionary*)params cacheFile:(NSString*)cacheFile;
+ (NSString*)stringWithURL:(NSString*)url params:(NSDictionary*)params fileData:(NSData*)fileData;


@end
