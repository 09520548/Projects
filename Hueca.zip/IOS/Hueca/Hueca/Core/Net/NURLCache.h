//
//  NURLCache.h
//  MaxChat
//
//  Created by Nho Nguyen on 11/20/12.
//  Copyright (c) 2012 Climax Interactive. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NURLCache : NSObject

+ (NURLCache*)shareCache;
+ (NSString*)keyForURL:(NSString*)url;

- (id)initWithName:(NSString*)name capacity:(NSUInteger)capacity;

- (NSData*)cacheForKey:(NSString*)key;
- (void)setCache:(NSData*)data forKey:(NSString*)key;

- (NSData*)cacheForURL:(NSString*)url;
- (void)setCache:(NSData*)data forURL:(NSString*)url;

@end
