//
//  NApp.h
//  MaxChat
//
//  Created by Nho Nguyen on 10/1/12.
//  Copyright (c) 2012 Climax Interactive. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NApp : NSObject

+ (NSString*)documentDirectory;
+ (NSString*)documentDirectoryForName:(NSString*)name;

@end
