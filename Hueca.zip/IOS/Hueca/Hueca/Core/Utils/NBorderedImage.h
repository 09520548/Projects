//
//  NBorderedImage.h
//  MaxChat
//
//  Created by Nho Nguyen on 9/27/12.
//  Copyright (c) 2012 Climax Interactive. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NBorderedImage : UIView

- (id)initWithFrame:(CGRect)frame imageSize:(CGSize)imgSize border:(UIImage*)border;
- (id)initWithFrame:(CGRect)frame imageSize:(CGSize)imgSize border:(UIImage*)border image:(UIImage*)image;
- (id)initWithFrame:(CGRect)frame imageSize:(CGSize)imgSize border:(UIImage*)border url:(NSString*)url placeholder:(UIImage*)placeholder;

@property (nonatomic, strong) UIImage *image;

- (void)loadURL:(NSString*)url;
- (void)loadURL:(NSString*)url placeholder:(UIImage*)placeholder;

@end
