//
//  NPFile.m
//  Fudahospital
//
//  Created by NhiepPhong on 3/10/13.
//  Copyright (c) 2013 NhiepPhong. All rights reserved.
//

#import "NPFile.h"

@implementation NPFile

+ (NSString *)writeStringToFile:(NSString*)data andFileName:(NSString *)fileName
{
    
    // Build the path, and create if needed.
    NSString* filePath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString* fileAtPath = [filePath stringByAppendingPathComponent:fileName];
    
    if (![[NSFileManager defaultManager] fileExistsAtPath:fileAtPath]) {
        [[NSFileManager defaultManager] createFileAtPath:fileAtPath contents:nil attributes:nil];
    }
    
    // The main act.
    [[data dataUsingEncoding:NSUTF8StringEncoding] writeToFile:fileAtPath atomically:NO];
    
    return fileAtPath;
}

+ (NSString*)readStringFromFile:(NSString *)fileName
{
    NSString* filePath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString* fileAtPath = [filePath stringByAppendingPathComponent:fileName];
    NSString *data;
    data = [[NSString alloc] initWithData:[NSData dataWithContentsOfFile:fileAtPath] encoding:NSUTF8StringEncoding];
    return data;
}

@end
