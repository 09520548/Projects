//
//  NFormat.m
//  MaxChat
//
//  Created by Nho Nguyen on 10/3/12.
//  Copyright (c) 2012 Climax Interactive. All rights reserved.
//

#import "NFormat.h"

@implementation NFormat

+ (NSString*)stringFromDate:(NSDate *)date format:(NSString *)format
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    
    [formatter setDateFormat:format];
    
    return [formatter stringFromDate:date];
}

+ (NSDate*)dateFromString:(NSString *)date format:(NSString *)format
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    
    [formatter setDateFormat:format];
    
    return [formatter dateFromString:date];
}

@end
