//
//  NPFile.h
//  Fudahospital
//
//  Created by NhiepPhong on 3/10/13.
//  Copyright (c) 2013 NhiepPhong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NPFile : NSObject

+ (NSString *)writeStringToFile:(NSString*)data andFileName:(NSString *)fileName;
+ (NSString*)readStringFromFile:(NSString *)fileName;

@end
