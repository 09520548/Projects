//
//  NSString+NMD5.h
//  MaxChat
//
//  Created by Nho Nguyen on 11/20/12.
//  Copyright (c) 2012 Climax Interactive. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (NMD5)

- (NSString *)MD5;

@end
