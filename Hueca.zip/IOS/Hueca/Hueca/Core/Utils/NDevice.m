//
//  NDevice.m
//  MaxChat
//
//  Created by Nho Nguyen on 9/22/12.
//  Copyright (c) 2012 Climax Interactive. All rights reserved.
//

#import "NDevice.h"

static NDeviceScreen NDevice_screenType = NDeviceScreenUnknown;

@implementation NDevice

+ (NDeviceScreen)screenType
{
    if(NDevice_screenType == NDeviceScreenUnknown)
    {
        UIScreen *screen = [UIScreen mainScreen];
        CGSize size = screen.bounds.size;
        
        if(screen.scale > 1.5f)
        {
            if(size.height < 500.0f && size.width < 500.0f)
            {
                NDevice_screenType = NDeviceScreenIPHONE4;
            }
            else if(size.height < 700.0f && size.width < 700.0f)
            {
                NDevice_screenType = NDeviceScreenIPHONE5;
            }
            else
            {
                NDevice_screenType = NDeviceScreenIPAD3;
            }
        }
        else if(size.height < 500.0f)
        {
            NDevice_screenType = NDeviceScreenIPHONE;
        }
        else
        {
            NDevice_screenType = NDeviceScreenIPAD;
        }
    }
    return NDevice_screenType;
}

+ (float) getHeight
{
    UIScreen *screen = [UIScreen mainScreen];
    CGSize size = screen.bounds.size;
    
    return size.height;
}

+ (float) getWidth
{
    UIScreen *screen = [UIScreen mainScreen];
    CGSize size = screen.bounds.size;
    
    return size.width;
}

@end
