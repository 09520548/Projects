//
//  NApp.m
//  MaxChat
//
//  Created by Nho Nguyen on 10/1/12.
//  Copyright (c) 2012 Climax Interactive. All rights reserved.
//

#import "NApp.h"

static NSString* NApp_documentDirectory = nil;

@implementation NApp

+ (NSString*)documentDirectory
{
    if(NApp_documentDirectory == nil)
    {
        NApp_documentDirectory = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    }
    
    return NApp_documentDirectory;
}

+ (NSString*)documentDirectoryForName:(NSString *)name
{
    return [[NApp documentDirectory] stringByAppendingPathComponent:name];
}

@end
