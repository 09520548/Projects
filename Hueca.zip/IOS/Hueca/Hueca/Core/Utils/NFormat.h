//
//  NFormat.h
//  MaxChat
//
//  Created by Nho Nguyen on 10/3/12.
//  Copyright (c) 2012 Climax Interactive. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NFormat : NSObject

+ (NSString*)stringFromDate:(NSDate*)date format:(NSString*)format;
+ (NSDate*)dateFromString:(NSString*)date format:(NSString*)format;

@end
