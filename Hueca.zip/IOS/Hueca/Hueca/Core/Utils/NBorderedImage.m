//
//  NBorderedImage.m
//  MaxChat
//
//  Created by Nho Nguyen on 9/27/12.
//  Copyright (c) 2012 Climax Interactive. All rights reserved.
//

#import "NBorderedImage.h"
#import "NLoader.h"

@interface NBorderedImage() <NImageLoaderDelegate>
{
    UIImage *_border;
    UIImage *_placeholder;
    CGRect _imgRec;
    NImageLoader *_imageLoader;
}
- (void)startLoadURL:(NSString*)url;
- (void)cancel;
@end

static UIImage* NBorderedImage_border = nil;

CGRect NBorderedImage_CGRectFit(CGSize size1, CGSize size2)
{
    return CGRectMake((size1.width - size2.width)/2, (size1.height - size2.height)/2, size2.width, size2.height);
}

UIImage* NBorderedImage_BorderImage(UIImage* border)
{
    if(border == nil)
    {
        if(NBorderedImage_border == nil)
        {
            NBorderedImage_border = [[UIImage imageNamed:@"ThumbBorder"] resizableImageWithCapInsets:UIEdgeInsetsMake(4.0f, 4.0f, 4.0f, 4.0f)];
        }
        border = NBorderedImage_border;
    }
    return border;
}

@implementation NBorderedImage
@synthesize image = _image;

- (id)initWithFrame:(CGRect)frame imageSize:(CGSize)imgSize border:(UIImage *)border
{   
    self = [super initWithFrame:frame];
    if (self)
    {
        _imgRec = NBorderedImage_CGRectFit(frame.size, imgSize);
        _border = NBorderedImage_BorderImage(border);
        _image = nil;
        _imageLoader = nil;
        _placeholder = nil;
        
        [self setBackgroundColor:nil];
        [self setOpaque:NO];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame imageSize:(CGSize)imgSize border:(UIImage *)border image:(UIImage *)image
{
    self = [super initWithFrame:frame];
    if(self)
    {
        _imgRec = NBorderedImage_CGRectFit(frame.size, imgSize);
        _border = NBorderedImage_BorderImage(border);
        _image = image;
        _imageLoader = nil;
        _placeholder = nil;
        
        [self setBackgroundColor:nil];
        [self setOpaque:NO];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame imageSize:(CGSize)imgSize border:(UIImage *)border url:(NSString *)url placeholder:(UIImage *)placeholder
{
    self = [super initWithFrame:frame];
    if(self)
    {
        _imgRec = NBorderedImage_CGRectFit(frame.size, imgSize);
        _border = NBorderedImage_BorderImage(border);
        _image = nil;
        _imageLoader = nil;
        _placeholder = placeholder;
        
        [self setBackgroundColor:nil];
        [self setOpaque:NO];
        [self startLoadURL:url];
    }
    return self;
}

- (void)setImage:(UIImage *)image
{
    [self cancel];
    
    _image = image;
    
    [self setNeedsDisplay];
}

- (void)drawRect:(CGRect)rect
{
    if(_image)
    {
        [_image drawInRect:_imgRec];
    }
    else if(_placeholder)
    {
        [_placeholder drawInRect:_imgRec];
    }
    [_border drawInRect:rect];
}

- (void)loadURL:(NSString *)url
{
    [self loadURL:url placeholder:nil];
}

- (void)loadURL:(NSString *)url placeholder:(UIImage *)placeholder
{
    if(placeholder)
    {
        _placeholder = placeholder;
    }
    _image = nil;
    
    [self setNeedsDisplay];
    [self startLoadURL:url];
}

- (void)startLoadURL:(NSString *)url
{
    [self cancel];
    
    _imageLoader = [NLoader imageWithURL:url delegate:self];
}

- (void)cancel
{
    if(_imageLoader)
    {
        [_imageLoader cancel];
        _imageLoader = nil;
    }
}

#pragma mark - NImageLoaderDelegate

- (void)loader:(NImageLoader *)loader didLoadImage:(UIImage *)image
{
    [self setImage:image];
}

@end
