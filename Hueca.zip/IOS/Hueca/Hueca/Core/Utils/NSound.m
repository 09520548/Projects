//
//  NSound.m
//  MaxChat
//
//  Created by Nho Nguyen on 10/10/12.
//  Copyright (c) 2012 Climax Interactive. All rights reserved.
//

#import <AudioToolbox/AudioToolbox.h>
#import "NSound.h"

static BOOL NSound_loaded = NO;
static SystemSoundID NSound_msgin;
static SystemSoundID NSound_msgout;
static SystemSoundID NSound_alert;
static SystemSoundID NSound_tick;
static SystemSoundID NSound_pin;

@implementation NSound

+ (void)audioInit
{
    if(!NSound_loaded)
    {
        NSURL *url1 = [NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"msg_in" ofType:@"aiff"] isDirectory:NO];
        NSURL *url2 = [NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"msg_out" ofType:@"aiff"] isDirectory:NO];
        NSURL *url3 = [NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"Alert" ofType:@"aiff"] isDirectory:NO];
        NSURL *url4 = [NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"sound_score" ofType:@"mp3"] isDirectory:NO];
        NSURL *url5 = [NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"PIN" ofType:@"m4a"] isDirectory:NO];
        AudioServicesCreateSystemSoundID((__bridge CFURLRef)url1, &NSound_msgin);
        AudioServicesCreateSystemSoundID((__bridge CFURLRef)url2, &NSound_msgout);
        AudioServicesCreateSystemSoundID((__bridge CFURLRef)url3, &NSound_alert);
        AudioServicesCreateSystemSoundID((__bridge CFURLRef)url4, &NSound_tick);
        AudioServicesCreateSystemSoundID((__bridge CFURLRef)url5, &NSound_pin);
        
        NSound_loaded = YES;
    }
}

+ (void)playMsgReceiveSound
{
    [NSound audioInit];
    AudioServicesPlaySystemSound(NSound_msgin);
}

+ (void)playMsgSendSound
{
    [NSound audioInit];
    AudioServicesPlaySystemSound(NSound_msgout);
}

+ (void)playAlertSound
{
    [NSound audioInit];
    AudioServicesPlaySystemSound(NSound_alert);
}

+ (void)playSoundTick
{
    [NSound audioInit];
    AudioServicesPlaySystemSound(NSound_tick);
}

+ (void)playSoundPIN
{
    [NSound audioInit];
    AudioServicesPlaySystemSound(NSound_pin);
}
@end
