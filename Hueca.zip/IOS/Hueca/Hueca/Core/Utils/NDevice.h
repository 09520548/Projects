//
//  NDevice.h
//  MaxChat
//
//  Created by Nho Nguyen on 9/22/12.
//  Copyright (c) 2012 Climax Interactive. All rights reserved.
//

#import <Foundation/Foundation.h>


typedef enum {
    NDeviceScreenUnknown,
    NDeviceScreenIPHONE,
    NDeviceScreenIPHONE4,
    NDeviceScreenIPHONE5,
    NDeviceScreenIPAD,
    NDeviceScreenIPAD3
} NDeviceScreen;

@interface NDevice : NSObject

+ (NDeviceScreen)screenType;

+ (float)getHeight;

+ (float)getWidth;

@end
