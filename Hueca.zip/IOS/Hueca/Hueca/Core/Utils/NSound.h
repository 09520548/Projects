//
//  NSound.h
//  MaxChat
//
//  Created by Nho Nguyen on 10/10/12.
//  Copyright (c) 2012 Climax Interactive. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSound : NSObject

+ (void)playMsgReceiveSound;
+ (void)playMsgSendSound;
+ (void)playAlertSound;
+ (void)playSoundTick;
+ (void)playSoundPIN;

@end
