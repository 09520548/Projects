//
//  UIColor+cate.h
//  R
//
//  Created by NhiepPhong on 7/25/13.
//  Copyright (c) 2013 SiNguyen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (cate)

+ (UIColor *) colorFromHexString:(NSString *)hexString;

@end
