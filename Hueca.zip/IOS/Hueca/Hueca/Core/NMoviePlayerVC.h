//
//  NMoviePlayerVC.h
//  MaxChat
//
//  Created by Nho Nguyen on 11/29/12.
//  Copyright (c) 2012 Climax Interactive. All rights reserved.
//

#import <MediaPlayer/MediaPlayer.h>

@interface NMoviePlayerVC : MPMoviePlayerViewController

@end
