//
//  AdvertisementVC.h
//  Hueca
//
//  Created by NhiepPhong on 4/23/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AdvertisementVC : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *bg;
@property (weak, nonatomic) IBOutlet UIImageView *image;

- (IBAction)onReadMore:(UIButton *)sender;
- (IBAction)onGoHome:(UIButton *)sender;

@end
