//
//  AdvertisementVC.m
//  Hueca
//
//  Created by NhiepPhong on 4/23/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "AdvertisementVC.h"
#import "NDevice.h"
#import "MainVC.h"
#import "RestaurantProfileVC.h"
#import "GlobalData.h"
#import "NLoader.h"

@interface AdvertisementVC ()

@end

@implementation AdvertisementVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
    
    }
    return self;
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    NSString *imgName = @"bg";
    
    if([NDevice screenType] == NDeviceScreenIPHONE5)
    {
        imgName = @"bg-568h";
    }
    
    self.bg.image = [UIImage imageNamed:imgName];
    self.bg.frame = CGRectMake(0, 0, [NDevice getWidth], [NDevice getHeight]);
    
    if([GlobalData shareGlobalData].advertisement != nil)
    {
        NSString *link_thumb = [[GlobalData shareGlobalData].advertisement valueForKey:@"thumb"];
        UIImage *image = nil;
        image = [NLoader imageWithURL:link_thumb
                      completeHandler:^(UIImage *img) { [self setImageThumb:img]; }
                                cache:nil];
        if(image)
        {
            [self setImageThumb:image];
        }
        
        [self.image setContentMode:UIViewContentModeScaleAspectFill];
        [self.image setOpaque:YES];
        [self.image.layer setMasksToBounds:YES];
        self.image.layer.borderColor = [UIColor whiteColor].CGColor;
        self.image.layer.borderWidth = 4;
    }
}

- (void) setImageThumb:(UIImage*)img
{
    self.image.alpha = 0;
    [self.image setImage:img];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [UIView setAnimationDelay:0];
    
    self.image.alpha = 1;
    
    [UIView commitAnimations];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (IBAction)onReadMore:(UIButton *)sender
{
    if([[[GlobalData shareGlobalData].advertisement valueForKey:@"type"] isEqualToString:@"link"])
    {
        NSString *url = [[GlobalData shareGlobalData].advertisement valueForKey:@"link"];
        [[UIApplication sharedApplication]openURL:[NSURL URLWithString:url]];
    }
    else
    {
        RestaurantProfileVC *vc = [[RestaurantProfileVC alloc] initWithNibName:@"RestaurantProfileVC" bundle:nil];
        [vc setIdRestaurant:[[[GlobalData shareGlobalData].advertisement valueForKey:@"id"] intValue]];
        [self.navigationController pushViewController:vc animated:YES];
    }
}

- (IBAction)onGoHome:(UIButton *)sender
{
    MainVC *vc = [[MainVC alloc] initWithNibName:@"MainVC" bundle:nil];
    [self.navigationController pushViewController:vc animated:YES];
}
@end
