//
//  HomeVC.m
//  Hueca
//
//  Created by NhiepPhong on 4/22/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "HomeVC.h"
#import "NDevice.h"
#import "NSound.h"
#import "MapVC.h"
#import "FeedVC.h"
#import "SearchVC.h"
#import "MyProfileVC.h"
#import "UIViewController+MMDrawerController.h"
#import "MakeReviewVC.h"
#import "AddRestaurantVC.h"
#import "GlobalData.h"
#import "NLoader.h"
#import "NPConstants.h"
#import "CalloutView.h"
#import "AnnotationViewNearby.h"
#import "RestaurantProfileVC.h"
#import "PinView.h"

@interface HomeVC ()
{
    CustomIOS7AlertView *popupLoading;
    NSMutableArray *data;
    NSString *filter;
    CLLocationManager *locationManager;
    BOOL isFirtLoad;
    
    NSDictionary *restaurantSelect;
    
    UITapGestureRecognizer *tapGestureKeyboard;
    
    SLComposeViewController *slcComposeViewShareFB;
    BOOL pushNotification;
    NSString *textShare;
    
    BOOL isLoading;
    
    BOOL isTouchInside;
    NSDictionary *restaurantSelectTouch;
    
    NSMutableArray *dataSearch;
}
@end

@implementation HomeVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {

    }
    return self;
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    
    tapGestureKeyboard = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTapHideKeyboard:)];
    tapGestureKeyboard.numberOfTapsRequired = 1;
    tapGestureKeyboard.cancelsTouchesInView = NO;
    tapGestureKeyboard.delaysTouchesBegan = NO;
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
    slcComposeViewShareFB = nil;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(sharingStatusFB) name:@"share_fb_status" object:nil];
    
    NSString *imgName = @"bg";
    
    if([NDevice screenType] == NDeviceScreenIPHONE5)
    {
        imgName = @"bg-568h";
    }
    
    self.bg.image = [UIImage imageNamed:imgName];
    self.bg.frame = CGRectMake(0, 0, [NDevice getWidth], [NDevice getHeight]);
    
    self.viewPopup.frame = CGRectMake(0, 0, 320, self.view.frame.size.height);
    self.viewPopupContent.frame = CGRectMake(0, (self.viewPopup.frame.size.height - self.viewPopupContent.frame.size.height)/2, self.viewPopupContent.frame.size.width, self.viewPopupContent.frame.size.height);
    [self.view addSubview:self.viewPopup];
    
    [self.viewPopup setHidden:YES];
    
    restaurantSelect = nil;
    filter = @"all";
    isFirtLoad = TRUE;
    [self setBtnFilter:self.menuAll];
    
    self.map.delegate = self;
    self.map.mapType = MKMapTypeStandard;
    self.map.userTrackingMode = MKUserTrackingModeFollow;
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.distanceFilter = kCLDistanceFilterNone; // whenever we move
    locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters; // 100 m
    locationManager.delegate = self;
    [locationManager startUpdatingLocation];
    
    [self.viewSelectPlace initView:self.view.frame];
    [self.viewSelectPlace addDataList:[GlobalData shareGlobalData].dataPlaceCheckin];
//    [self.viewSelectPlace addDataList:[GlobalData shareGlobalData].dataPlace];
    self.viewSelectPlace.titlePage.text = @"Check-in";
    self.viewSelectPlace.delegate = self;
    [self.view addSubview:self.viewSelectPlace];
    
    isLoading = FALSE;
    
    dataSearch = [NSMutableArray new];
 
}

- (void) viewWillDisappear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:@"share_fb_status"];
    
    [super viewWillDisappear:animated];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    [locationManager stopUpdatingLocation];
    NSLog(@"didUpdateToLocation");
    [self showFocusMyLocation];
    [self loadData];
}

- (void) showFocusMyLocation
{
    MKCoordinateRegion viewRegion = MKCoordinateRegionMakeWithDistance(locationManager.location.coordinate, METERS_PER_MILE, METERS_PER_MILE);
    [self.map setRegion:viewRegion animated:YES];
    [self.map setShowsUserLocation:YES];
}

- (void) loadData
{
    if(!isLoading)
    {
        isLoading = TRUE;
        isFirtLoad = FALSE;
        
        [self.map removeAnnotations:self.map.annotations];
        
        [self showLoading];
        dispatch_async(kBgQueue, ^{
            NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
            [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"email"] forKey:@"email"];
            [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"key"] forKey:@"key"];
            [params setObject:[NSString stringWithFormat:@"%f",locationManager.location.coordinate.latitude] forKey:@"latitude"];
            [params setObject:[NSString stringWithFormat:@"%f",locationManager.location.coordinate.longitude] forKey:@"longitude"];
            [params setObject:filter forKey:@"type"];
            if(self.txtSearch.text != nil)
            {
                [params setObject:self.txtSearch.text forKey:@"search"];
            }
            
            
            NSDictionary *response = [NLoader jsonDataOfURL:LINK_GET_HOME_RESTAURANT params:params];
            
            [self performSelectorOnMainThread:@selector(getRestaurantComplete:) withObject:response waitUntilDone:NO];
        });
    }
}

- (void) getRestaurantComplete:(NSArray *)result
{
//    NSLog(@"getRestaurantComplete %@", result);
    isLoading = FALSE;
    [popupLoading close];
    if(result == nil)
    {
        [[GlobalData shareGlobalData] showAlert:@"Network error. Please check your connectivity." Title:@"Alert"];
    }
    else
    {
        data = nil;
        data = [[NSMutableArray alloc] initWithArray:result];
        
        if (data.count == 1) {
            NSDictionary *dic = [result objectAtIndex:0];
            CLLocationCoordinate2D zoomLocation;
            zoomLocation.latitude = [[dic objectForKey:@"latitude"] floatValue];
            zoomLocation.longitude= [[dic objectForKey:@"longitude"] floatValue];
            MKCoordinateRegion viewRegion = MKCoordinateRegionMakeWithDistance(zoomLocation, 0.5*METERS_PER_MILE, 0.5*METERS_PER_MILE);
            [self.map setRegion:viewRegion animated:YES];
        }
        
        [self addCouponInMap];
        [GlobalData shareGlobalData].dataPlaceCheckin = data;
        [self.viewSelectPlace addDataList:[GlobalData shareGlobalData].dataPlaceCheckin];
    }
}

- (void) addCouponInMap
{
    NSMutableArray *dataCouponInMap = [[NSMutableArray alloc] init];
    if(data.count > 0)
    {
        for(int i = 0; i < data.count; i++)
        {
            AnnotationViewNearby *item = [[AnnotationViewNearby alloc] init];
            [item addData:[data objectAtIndex:i]];
            item.tag = i;
            [dataCouponInMap addObject:item];
        }
    }
    
//    [self.map removeAnnotations:self.map.annotations];
    
    NSMutableArray * annotationsToRemove = [self.map.annotations mutableCopy] ;
    [annotationsToRemove removeObject:self.map.userLocation] ;
    [self.map removeAnnotations:annotationsToRemove] ;
    
    [self.map addAnnotations:dataCouponInMap];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (IBAction)menuTouch:(UIButton *)sender
{
    [self setBtnFilter:sender];
}

- (IBAction)onTouchPopup:(UIButton *)sender
{
    [self hidePopup];
    if(sender.tag == 1)
    {
        [self onShareFB];
    }
    else if(sender.tag == 2)
    {
        MakeReviewVC *vc = [[MakeReviewVC alloc] initWithNibName:@"MakeReviewVC" bundle:nil];
        [vc addRestaurant:restaurantSelect];
        [self.navigationController pushViewController:vc animated:YES];
    }
}

- (IBAction)onTouchPin:(UIButton *)sender
{
//    if(restaurantSelect == nil)
//    {
////        [[GlobalData shareGlobalData] showAlert:@"Please Choose Restaurant." Title:@"Alert"];
//        [self.viewSelectPlace show];
//    }
//    else
//    {
//        [NSound playSoundPIN];
//        [self postCheckIn];
////        [self showPopup];
//    }
    [self.viewSelectPlace show];
}

- (void)onSelectCategory:(NSDictionary *)dt
{
    NSLog(@"restaurantSelect: %@", dt);
    restaurantSelect = dt;
    [NSound playSoundPIN];
    [self postCheckIn];
//    [self showPopup];
}

- (IBAction)openMenu:(UIButton *)sender
{
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideRight animated:YES completion:nil];
}

- (IBAction)onNewRestaurant:(UIButton *)sender
{
    AddRestaurantVC *vc = [[AddRestaurantVC alloc] initWithNibName:@"AddRestaurantVC" bundle:nil];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void) showPopup
{
//    [self postCheckIn];
    
    [self.viewPopup setHidden:NO];
    self.viewPopupContent.alpha = 0;
    CGRect frame = self.viewPopupContent.frame;
    frame.origin.y = (self.viewPopup.frame.size.height - self.viewPopupContent.frame.size.height)/2 + 50;
    self.viewPopupContent.frame = frame;
    frame.origin.y = (self.viewPopup.frame.size.height - self.viewPopupContent.frame.size.height)/2;
    
    [UIView animateWithDuration:0.3
                          delay:0.0
                        options:UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         self.viewPopupContent.frame = frame;
                         self.viewPopupContent.alpha = 1;
                     } completion:^(BOOL finished) {
                     }];
}
- (void) hidePopup
{
    CGRect frame = self.viewPopupContent.frame;
    frame.origin.y = (self.viewPopup.frame.size.height - self.viewPopupContent.frame.size.height)/2 + 50;
    
    [UIView animateWithDuration:0.2
                          delay:0.0
                        options:UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         self.viewPopupContent.frame = frame;
                         self.viewPopupContent.alpha = 0;
                     } completion:^(BOOL finished) {
                        [self.viewPopup setHidden:YES];
                     }];
}

- (void) setBtnFilter:(UIButton *)btn
{
    [self.menuAll setSelected:NO];
    [self.menuFavorites setSelected:NO];
    [self.menuFeatured setSelected:NO];
    [self.menuHotspots setSelected:NO];
    [self.menuNew setSelected:NO];
    [self.menuOpen setSelected:NO];
    
    if(btn == self.menuFavorites)
    {
        [self.menuFavorites setSelected:YES];
        filter = @"favorites";
    }
    else if(btn == self.menuFeatured)
    {
        [self.menuFeatured setSelected:YES];
        filter = @"featured";
    }
    else if(btn == self.menuHotspots)
    {
        [self.menuHotspots setSelected:YES];
        filter = @"hotspots";
    }
    else if(btn == self.menuNew)
    {
        [self.menuNew setSelected:YES];
        filter = @"new";
    }
    else if(btn == self.menuOpen)
    {
        [self.menuOpen setSelected:YES];
        filter = @"open";
    }
    else
    {
        [self.menuAll setSelected:YES];
        filter = @"all";
    }
    
    if(!isFirtLoad)
    {
        [self loadData];
    }
}

- (void) showLoading
{
    popupLoading = [[CustomIOS7AlertView alloc] init];
    
    [popupLoading setContainerView:[[GlobalData shareGlobalData] createViewLoading]];
    
    [popupLoading setButtonTitles:nil];
    [popupLoading setDelegate:self];
    
    [popupLoading setUseMotionEffects:true];
    [popupLoading show];
    
}
- (void)customIOS7dialogButtonTouchUpInside: (CustomIOS7AlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    [alertView close];
}

#pragma mark - MKMapViewDelegate
- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation {
    if([annotation isKindOfClass:[MKUserLocation class]])
    {
        return nil;
    }
    
    NSString *identifier = [NSString stringWithFormat:@"myAnnotation-%@", filter];
    MKAnnotationView * annotationView = (MKAnnotationView *)[self.map dequeueReusableAnnotationViewWithIdentifier:identifier];
    if (!annotationView)
    {
        annotationView = [[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:identifier];

        int tag = ((AnnotationViewNearby *)annotation).tag;
        NSDictionary *dt = [data objectAtIndex:tag];
        NSString *pinName;
        

        if([[dt valueForKey:@"is_sponsor"] integerValue] == 1)
        {
//            NSLog(@"bao dt: %@", dt);
            PinView *pin = [[PinView alloc] initWithFrame:CGRectMake(0, 0, 42, 61)];
            [annotationView addSubview:pin];
            [pin addData:dt];
            
            pinName = @"pin_view";
            annotationView.image = [UIImage imageNamed:pinName];
            
            NSLog(@"ano: %@", annotationView);
           
        }
        else
        {
            pinName = [NSString stringWithFormat:@"home-%@-%@", [dt valueForKey:@"type"], [dt valueForKey:@"highlight"]];
            if ([[NSString stringWithFormat:@"%@", [dt valueForKey:@"type"]] isEqualToString:@"hotspots"]) {
                UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(-3, 0, 50, 30)];
//                [lbl setBackgroundColor:[UIColor redColor]];
                [lbl setTextAlignment:NSTextAlignmentCenter];
                lbl.text = [NSString stringWithFormat:@"%d", [[dt objectForKey:@"checkin"] intValue]];
                [annotationView addSubview:lbl];

            }
            annotationView.image = [UIImage imageNamed:pinName];
        }
        
        
        
    }
    else
    {
        annotationView.annotation = annotation;
        
        
        NSString *pinName;
        
        for (UIView *subView in annotationView.subviews) {
            if ([subView isKindOfClass:[UILabel class]] || [subView isKindOfClass:[PinView class]]) {
                [subView removeFromSuperview];
            }
        }
        
        int tag = ((AnnotationViewNearby *)annotation).tag;
        NSDictionary *dt = [data objectAtIndex:tag];
        if([[dt valueForKey:@"is_sponsor"] integerValue] == 1) {
            pinName = @"pin_view";
            annotationView.image = [UIImage imageNamed:pinName];
            
            PinView *pin = [[PinView alloc] initWithFrame:CGRectMake(0, 0, 42, 61)];
            [annotationView addSubview:pin];
            [pin addData:dt];
        }
        else {
            pinName = [NSString stringWithFormat:@"home-%@-%@", [dt valueForKey:@"type"], [dt valueForKey:@"highlight"]];
            annotationView.image = [UIImage imageNamed:pinName];
            
            if ([[NSString stringWithFormat:@"%@", [dt valueForKey:@"type"]] isEqualToString:@"hotspots"]) {
                UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(-3, 0, 50, 30)];
                //                [lbl setBackgroundColor:[UIColor redColor]];
                [lbl setTextAlignment:NSTextAlignmentCenter];
                lbl.text = [NSString stringWithFormat:@"%d", [[dt objectForKey:@"checkin"] intValue]];
                [annotationView addSubview:lbl];
                
            }
            
        }
        
    }
    annotationView.userInteractionEnabled = TRUE;
    
    return annotationView;
}

- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view {
    
    if([view.annotation isKindOfClass:[AnnotationViewNearby class]])
    {
        int tag = ((AnnotationViewNearby *)view.annotation).tag;
        CalloutView *calloutView = [[CalloutView alloc] initWithFrame:CGRectMake(0.0, 0.0, 207, 80)];
        
        NSDictionary *dtAddress = [data objectAtIndex:tag];
        
        restaurantSelect = dtAddress;
        
        [calloutView show:dtAddress];
        calloutView.userInteractionEnabled = TRUE;
        calloutView.center = CGPointMake(CGRectGetWidth(view.bounds) / 2.0 - 6, -CGRectGetWidth(view.bounds));
//        [calloutView setBackgroundColor:[UIColor blackColor]];

        [view addSubview:calloutView];
    }
}

- (void)mapView:(MKMapView *)mapView didDeselectAnnotationView:(MKAnnotationView *)view {
    for (UIView *subview in view.subviews) {
		if (![subview isKindOfClass:[CalloutView class]]) {
			continue;
		}
		
		[subview removeFromSuperview];
	}
    
    restaurantSelect = nil;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    isTouchInside = TRUE;
    restaurantSelectTouch = nil;
    
    UITouch *myTouch =[[event allTouches] anyObject];
    
    for (UIView *subview in myTouch.view.subviews)
    {
        if([subview isKindOfClass:[MKAnnotationView class]])
        {
            for (UIView *sub in subview.subviews)
            {
                if([sub isKindOfClass:[CalloutView class]])
                {
                    CalloutView *calloutView = (CalloutView *)sub;
                    
                    
                    CGPoint loca = [myTouch locationInView:sub];
                    UIView *v = [sub hitTest:loca withEvent:nil];

                    if(v)
                    {
                        restaurantSelectTouch = [calloutView getData];
                    }
                }
            }
        }
    }
}


- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    isTouchInside = FALSE;
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    if(isTouchInside && restaurantSelectTouch != nil)
    {
        RestaurantProfileVC *vc = [[RestaurantProfileVC alloc] initWithNibName:@"RestaurantProfileVC" bundle:nil];
        [vc setIdRestaurant:[[restaurantSelectTouch valueForKey:@"id"] intValue]];
        [self.navigationController pushViewController:vc animated:YES];
    }
}
- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    
}

- (void) postCheckIn
{
    dispatch_async(kBgQueue, ^{
        NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
        [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"email"] forKey:@"email"];
        [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"key"] forKey:@"key"];
        [params setObject:[NSString stringWithFormat:@"%@", [restaurantSelect valueForKey:@"id"]] forKey:@"id"];

        NSDictionary *response = [NLoader jsonDataOfURL:LINK_GET_CHECKIN_RESTAURANT params:params];
        [self performSelectorOnMainThread:@selector(postCheckInComplete:) withObject:response waitUntilDone:NO];
    });
}

- (void)postCheckInComplete:(NSDictionary *)result
{
    NSLog(@"postCheckInComplete: %@", result);
    if (result) {
        if ([[result objectForKey:@"status"] intValue] == 1) {
            [self showPopup];
        }
        else {
            [[GlobalData shareGlobalData] showAlert:[result objectForKey:@"message"] Title:@"Alert"];
        }
    }
}

- (void) postShare
{
    dispatch_async(kBgQueue, ^{
        NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
        [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"email"] forKey:@"email"];
        [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"key"] forKey:@"key"];
        [params setObject:[NSString stringWithFormat:@"%@", [restaurantSelect valueForKey:@"id"]] forKey:@"id"];
//        NSLog(@"params %@", params);
        NSDictionary *response = [NLoader jsonDataOfURL:LINK_GET_SHARE_RESTAURANT params:params];
        
        [self performSelectorOnMainThread:@selector(postShareComplete:) withObject:response waitUntilDone:NO];
    });
}

- (void) postShareComplete:(NSArray *)result
{
    NSLog(@"postShareComplete %@", result);
    
}

- (void) onTapHideKeyboard:(id) sender
{
    [self.txtSearch resignFirstResponder];
}

-(void) keyboardWillShow:(NSNotification *)note
{
    [self.map addGestureRecognizer:tapGestureKeyboard];
}

-(void) keyboardWillHide:(NSNotification *)note
{
    self.tableAutoSearch.hidden = YES;
    [self.map removeGestureRecognizer:tapGestureKeyboard];
}
- (BOOL) textFieldShouldReturn:(UITextField *)textField
{
    self.tableAutoSearch.hidden = YES;
    [self onTapHideKeyboard:nil];
//    [textField resignFirstResponder];
    
    [self showFocusMyLocation];
    [self loadData];
    
    return NO;
}

- (void) sharingStatusFB
{
    NSLog(@"sharingStatusFB");
    if(pushNotification)
    {
        pushNotification = FALSE;
        
        [self postShare];
    }
}

- (void) onShareFB
{
    
    if([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook])
    {
        pushNotification = TRUE;
        slcComposeViewShareFB = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
        [slcComposeViewShareFB addImage:[UIImage imageNamed:@"logo.png"]];
        [slcComposeViewShareFB setTitle:@"Share Facebook"];
        [slcComposeViewShareFB addURL:[NSURL URLWithString:@"https://www.facebook.com"]];
        [slcComposeViewShareFB setInitialText:textShare];
        [slcComposeViewShareFB setCompletionHandler:^(SLComposeViewControllerResult result){
            [[NSNotificationCenter defaultCenter] postNotificationName:@"share_fb_status" object:nil userInfo:nil];
        }];
        
        [self presentViewController:slcComposeViewShareFB animated:YES completion:NULL];
    }
    else
    {
        [[GlobalData shareGlobalData] showAlert:@"Không thể kết nối được Facebook. Vui lòng thử lại sau." Title:@"Alert"];
    }
}

#pragma mark - TABLE AUTO COMPLETE SEARCH
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    self.tableAutoSearch.hidden = NO;
    
    NSString *substring = [NSString stringWithString:textField.text];
    substring = [substring
                 stringByReplacingCharactersInRange:range withString:string];
    [self searchAutocompleteEntriesWithSubstring:substring];
    return YES;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [dataSearch count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Cell"];
    }
    if (dataSearch.count > 0) {
        cell.textLabel.text = [dataSearch objectAtIndex:indexPath.row];
    }
    
    return cell;
}

- (void)searchAutocompleteEntriesWithSubstring:(NSString *)substring {
    
    // Put anything that starts with this substring into the autocompleteUrls array
    // The items in this array is what will show up in the table view
//    [dataSearch removeAllObjects];
    [self getDataAutoSearch:substring];
//    for(NSString *curString in pastUrls) {
//        NSRange substringRange = [curString rangeOfString:substring];
//        if (substringRange.location == 0) {
//            [autocompleteUrls addObject:curString];
//        }
//    }
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self onTapHideKeyboard:nil];
    self.txtSearch.text = [dataSearch objectAtIndex:indexPath.row];
    NSLog(@"%@", [dataSearch objectAtIndex:indexPath.row]);
    
    [self showFocusMyLocation];
    [self loadData];
}

- (void) getDataAutoSearch:(NSString *)strSearch
{
    dispatch_async(kBgQueue, ^{
        NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
        [params setObject:strSearch forKey:@"search"];
        NSLog(@"params %@", params);
        NSDictionary *response = [NLoader jsonDataOfURL:LINK_GET_AUTOCOMPLE params:params];
        
        [self performSelectorOnMainThread:@selector(getDataAutoSearchComplete:) withObject:response waitUntilDone:NO];
    });
}

- (void) getDataAutoSearchComplete:(NSArray *)result
{
    NSLog(@"postShareComplete %@", result);
    if (result) {
        dataSearch = [[NSMutableArray alloc] initWithArray:result];
    }
    [self.tableAutoSearch reloadData];
}

@end
