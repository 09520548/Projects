//
//  HomeVC.h
//  Hueca
//
//  Created by NhiepPhong on 4/22/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>
#import "CustomIOS7AlertView.h"
#import <Social/Social.h>
#import "CategorySelectPlaceBox.h"

@interface HomeVC : UIViewController<CLLocationManagerDelegate, MKMapViewDelegate, CustomIOS7AlertViewDelegate, UITextFieldDelegate, CategorySelectPlaceBoxDelegate, UITableViewDataSource, UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UIImageView *bg;
@property (weak, nonatomic) IBOutlet MKMapView *map;
@property (weak, nonatomic) IBOutlet UITextField *txtSearch;
@property (weak, nonatomic) IBOutlet UIButton *menuHotspots;
@property (weak, nonatomic) IBOutlet UIButton *menuFavorites;
@property (weak, nonatomic) IBOutlet UIButton *menuNew;
@property (weak, nonatomic) IBOutlet UIButton *menuOpen;
@property (weak, nonatomic) IBOutlet UIButton *menuFeatured;
@property (weak, nonatomic) IBOutlet UIButton *menuAll;
@property (weak, nonatomic) IBOutlet UIButton *menuAddRestaurant;
@property (weak, nonatomic) IBOutlet UIButton *menuOption;
@property (weak, nonatomic) IBOutlet UIButton *menuPin;
@property (strong, nonatomic) IBOutlet UIView *viewPopup;
@property (weak, nonatomic) IBOutlet UIView *viewPopupContent;
@property (strong, nonatomic) IBOutlet CategorySelectPlaceBox *viewSelectPlace;
@property (weak, nonatomic) IBOutlet UITableView *tableAutoSearch;

- (IBAction)menuTouch:(UIButton *)sender;
- (IBAction)onTouchPopup:(UIButton *)sender;
- (IBAction)onTouchPin:(UIButton *)sender;
- (IBAction)openMenu:(UIButton *)sender;
- (IBAction)onNewRestaurant:(UIButton *)sender;

@end
