//
//  PinView.m
//  Hueca
//
//  Created by NhiepPhong on 6/4/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "PinView.h"
#import "NLoader.h"

@implementation PinView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        
    }
    return self;
}

- (void) addData:(NSDictionary *)dt
{
    //NSLog(@"DT %@", dt);
    
    thumb = [[UIImageView alloc] initWithFrame:CGRectMake(4, 4, 33, 33)];
    [thumb setContentMode:UIViewContentModeScaleAspectFill];
    thumb.layer.cornerRadius = 15;
    [thumb.layer setOpaque:YES];
    thumb.layer.masksToBounds = YES;
    
    [self addSubview:thumb];
    [thumb setImage:nil];
    
    UIImage *image = nil;
    image = [NLoader imageWithURL:[dt valueForKey:@"sponsor_icon"]
                  completeHandler:^(UIImage *img) { [thumb setImage:img]; }
                            cache:nil];
    
    if(image)
    {
        [thumb setImage:image];
    }
    
    
    
    self.backgroundColor = [UIColor clearColor];
}

@end
