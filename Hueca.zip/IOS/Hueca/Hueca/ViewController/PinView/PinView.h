//
//  PinView.h
//  Hueca
//
//  Created by NhiepPhong on 6/4/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PinView : UIView
{
    UIImageView *thumb;
    NSDictionary *data;
}
- (void) addData:(NSDictionary *)dt;

@end
