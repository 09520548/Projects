//
//  CategorySelectPlaceBox.h
//  Hueca
//
//  Created by Mobiz on 6/17/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ListPlaceCheckinCell.h"

@protocol CategorySelectPlaceBoxDelegate <NSObject>

@optional
- (void) onSelectCategory:(NSDictionary *)dt;
- (void) onClosePopupCategorySelect;

@end

@interface CategorySelectPlaceBox : UIView<UITableViewDataSource, UITableViewDelegate>
{
    NSArray *dataCategory;
    ListPlaceCheckinCell *_stubCell;
}

@property (weak, nonatomic) IBOutlet UIView *viewContent;
@property (weak, nonatomic) IBOutlet UILabel *titlePage;
@property (weak, nonatomic) IBOutlet UITableView *table;
@property (weak, nonatomic) IBOutlet UIButton *btnDone;
@property (nonatomic, weak) IBOutlet id<CategorySelectPlaceBoxDelegate>delegate;

- (void) initView:(CGRect)frame;
- (void) show;
- (void) hide;
- (void) addDataList:(NSArray *) data;
- (IBAction)onDone:(UIButton *)sender;

@end
