//
//  CategorySelectPlaceBox.m
//  Hueca
//
//  Created by Mobiz on 6/17/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "CategorySelectPlaceBox.h"
#import "GlobalData.h"

@implementation CategorySelectPlaceBox

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void) initView:(CGRect)frame
{
    self.table.delegate = self;
    self.table.dataSource = self;
    self.table.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.6];
    self.frame = frame;
    
    [self setHidden:YES];
//    dataCategory = [GlobalData shareGlobalData].dataCity;
    self.titlePage.font = [UIFont rw_FontRegularWithSize:16];
    self.btnDone.titleLabel.font = [UIFont rw_FontRegularWithSize:16];
    self.titlePage.text = @"Ciudad";
    
    self.viewContent.layer.cornerRadius = 6;
    [self.viewContent.layer setOpaque:YES];
    self.viewContent.layer.masksToBounds = YES;
    self.viewContent.layer.borderWidth = 0.5f;
    self.viewContent.layer.borderColor = [[UIColor brownColor] CGColor];
}

- (void) addDataList:(NSArray *) data
{
    dataCategory = data;
}

- (void) show
{
    [self setHidden:NO];
    
    [self.table reloadData];
    
    CGRect frameContent = self.viewContent.frame;
    
    frameContent.origin.y = self.frame.size.height - frameContent.size.height + frameContent.size.height/2;
    self.viewContent.frame = frameContent;
    self.viewContent.alpha = 0;
    
    frameContent.origin.y = self.frame.size.height - frameContent.size.height + 11;
    
    [UIView animateWithDuration:0.4
                          delay:0.0
                        options:UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         self.viewContent.frame = frameContent;
                         self.viewContent.alpha = 1;
                     } completion:^(BOOL finished) {
                     }];
}

- (void) hide
{
    CGRect frameContent = self.viewContent.frame;
    frameContent.origin.y = self.frame.size.height - frameContent.size.height + frameContent.size.height/2;
    
    [UIView animateWithDuration:0.4
                          delay:0.0
                        options:UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         self.viewContent.frame = frameContent;
                         self.viewContent.alpha = 0;
                     } completion:^(BOOL finished) {
                         [self setHidden:YES];
                     }];
}

- (IBAction)onDone:(UIButton *)sender
{
    [self hide];
    if ([self.delegate respondsToSelector:@selector(onClosePopupCategorySelect)])
    {
        [self.delegate onClosePopupCategorySelect];
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return dataCategory.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ListPlaceCheckinCell *cell = (ListPlaceCheckinCell *)[tableView dequeueReusableCellWithIdentifier:@"ListPlaceCheckinCell"];
    if(cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ListPlaceCheckinCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    [cell setData:[dataCategory objectAtIndex:indexPath.row]];
    return cell;
}

-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 44.0f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    [[tableView cellForRowAtIndexPath:indexPath] setSelected:NO animated:YES];
//    ListPlaceCheckinCell *cell = (ListPlaceCheckinCell *)[tableView cellForRowAtIndexPath:indexPath];
//    [cell.imgIcon setImage:[UIImage imageNamed:@"icon_checkin_hover"]];
    
    NSDictionary *dt = [dataCategory objectAtIndex:indexPath.row];
    [self hide];
    [self.delegate onSelectCategory:dt];
}

- (BOOL)tableView:(UITableView *)tableView shouldHighlightRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (void)tableView:(UITableView *)tableView didHighlightRowAtIndexPath:(NSIndexPath *)indexPath
{
    ListPlaceCheckinCell *cell = (ListPlaceCheckinCell *)[tableView cellForRowAtIndexPath:indexPath];
    [cell.imgIcon setImage:[UIImage imageNamed:@"icon_checkin_hover"]];
}

- (void)tableView:(UITableView *)tableView didEndEditingRowAtIndexPath:(NSIndexPath *)indexPath
{
	[tableView reloadData];
}

@end
