//
//  CategorySelectBox.h
//  Hueca
//
//  Created by NhiepPhong on 5/2/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CellCategory.h"

@protocol CategorySelectBoxDelegate <NSObject>

- (void) onSelectCategory:(NSDictionary *)dt;

@optional

- (void) onClosePopupCategorySelect;

@end

@interface CategorySelectBox : UIView<UITableViewDataSource, UITableViewDelegate>
{
    NSArray *dataCategory;
    CellCategory *_stubCell;
}

@property (weak, nonatomic) IBOutlet UIView *viewContent;
@property (weak, nonatomic) IBOutlet UILabel *titlePage;
@property (weak, nonatomic) IBOutlet UITableView *table;
@property (weak, nonatomic) IBOutlet UIButton *btnDone;
@property (nonatomic, weak) IBOutlet id<CategorySelectBoxDelegate>delegate;

- (void) initView:(CGRect)frame;
- (void) show;
- (void) hide;
- (void) addDataList:(NSArray *) data;
- (IBAction)onDone:(UIButton *)sender;

@end
