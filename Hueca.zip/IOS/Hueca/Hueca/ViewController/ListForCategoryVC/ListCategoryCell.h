//
//  ListCategoryCell.h
//  Hueca
//
//  Created by NhiepPhong on 5/21/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OutlineLabel.h"

@interface ListCategoryCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *thumb;
@property (weak, nonatomic) IBOutlet UILabel *count_comment;
@property (weak, nonatomic) IBOutlet UILabel *count_view;
@property (weak, nonatomic) IBOutlet UILabel *count_like;
@property (weak, nonatomic) IBOutlet OutlineLabel *txt_rating;
@property (weak, nonatomic) IBOutlet OutlineLabel *txtName;

- (void) setData:(NSDictionary*)dt;

@end
