//
//  ListForCategoryVC.m
//  Hueca
//
//  Created by NhiepPhong on 4/22/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "ListForCategoryVC.h"
#import "NDevice.h"
#import "ListCategoryCell.h"
#import "NLoader.h"
#import "GlobalData.h"
#import "NPConstants.h"
#import "RestaurantProfileVC.h"

@interface ListForCategoryVC ()
{
    NSMutableArray *data;
    NSString *filter;
    NSString *idCity;
    BOOL isLoading;
    BOOL isCanLoadMore;
}
@end

@implementation ListForCategoryVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        data = [NSMutableArray new];
    }
    return self;
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];

    viewHeader = [[ViewHeader alloc] initWithFrame:CGRectMake(0, 0, 320, 46)];
    [self.view addSubview:viewHeader];
    
    [viewHeader setVC:self];
    [viewHeader setTitlePage:@"Restaurants"];
    
    NSString *imgName = @"bg";
    
    if([NDevice screenType] == NDeviceScreenIPHONE5)
    {
        imgName = @"bg-568h";
    }
    
    self.bg.image = [UIImage imageNamed:imgName];
    self.bg.frame = CGRectMake(0, 0, [NDevice getWidth], [NDevice getHeight]);
    
    self.table.frame = CGRectMake(0, 144, 320, self.view.frame.size.height - 144);
    
    self.btnSelectCate.titleLabel.font = [UIFont rw_FontBoldWithSize:16];
    
    [self.view addSubview:self.viewSelectBox];
    
    [self.viewSelectBox initView:self.view.frame];
    
    [self.btnSelectCate setTitle:@"Ciudad" forState:UIControlStateNormal];
    
    
    
    [self.btnBest setHidden:YES];
    [self.btnFavourite setHidden:YES];
    [self.btnNew setHidden:YES];
    [self.btnRecommended setHidden:YES];
    self.table.frame = CGRectMake(0, 90, 320, self.view.frame.size.height - 90);
    
    
    
    UIView *headerTable = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 15)];
    headerTable.backgroundColor = [UIColor clearColor];
    self.table.tableHeaderView = headerTable;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    isLoading = FALSE;
    isCanLoadMore = TRUE;
    idCity = @"";
    data = [NSMutableArray new];
    [self setBtnFilter:self.btnNew];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void) loadData
{
    if(!isLoading)
    {
        isLoading = TRUE;
        [self showLoading];
        dispatch_async(kBgQueue, ^{
            NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
            [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"email"] forKey:@"email"];
            [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"key"] forKey:@"key"];
            [params setObject:idCity forKey:@"city"];
            [params setObject:filter forKey:@"filter"];
            [params setObject:[NSString stringWithFormat:@"%d", data.count] forKey:@"start"];
            
            NSDictionary *response = [NLoader jsonDataOfURL:LINK_GET_LIST_FOR_CATE params:params];

            [self performSelectorOnMainThread:@selector(getUserInfoComplete:) withObject:response waitUntilDone:NO];
        });
    }
}

- (void) getUserInfoComplete:(NSArray *)result
{
    [popupLoading close];
    if(result == nil)
    {
        [[GlobalData shareGlobalData] showAlert:@"Network error. Please check your connectivity." Title:@"Alert"];
    }
    else
    {
        isLoading = FALSE;
        isCanLoadMore = FALSE;
        if(result.count > 0)
        {
            isCanLoadMore = TRUE;
            [data addObjectsFromArray:result];
            [self.table reloadData];
        }
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    float yOffset = scrollView.contentOffset.y;
 
    if(yOffset >= (scrollView.contentSize.height - scrollView.frame.size.height)-10)
    {
        if(isCanLoadMore && !isLoading)
        {
            [self loadData];
        }
    }
}

- (IBAction)onFilter:(UIButton *)sender
{
    [self setBtnFilter:sender];
}

- (IBAction)onOpenSelectCate:(UIButton *)sender
{
    [self.viewSelectBox show];
}

- (void) setBtnFilter:(UIButton *)btn
{
    [self.btnBest setSelected:NO];
    [self.btnFavourite setSelected:NO];
    [self.btnNew setSelected:NO];
    [self.btnRecommended setSelected:NO];
    
    if(btn == self.btnBest)
    {
        [self.btnBest setSelected:YES];
        filter = @"best";
    }
    else if(btn == self.btnFavourite)
    {
        [self.btnFavourite setSelected:YES];
        filter = @"favorites";
    }
    else if(btn == self.btnNew)
    {
        [self.btnNew setSelected:YES];
        filter = @"new";
    }
    else if(btn == self.btnRecommended)
    {
        [self.btnRecommended setSelected:YES];
        filter = @"recommended";
    }
    
    data = [NSMutableArray new];
    [self.table reloadData];
    isLoading = FALSE;
    [self loadData];
}

- (void)onSelectCategory:(NSDictionary *)dt
{
    [self.btnSelectCate setTitle:[dt valueForKey:@"name"] forState:UIControlStateNormal];
    idCity = [NSString stringWithFormat:@"%@", [dt valueForKey:@"id"]];
    data = [NSMutableArray new];
    [self.table reloadData];
    [self loadData];
}
- (void) showLoading
{
    popupLoading = [[CustomIOS7AlertView alloc] init];
    
    [popupLoading setContainerView:[[GlobalData shareGlobalData] createViewLoading]];
    
    [popupLoading setButtonTitles:nil];
    [popupLoading setDelegate:self];
    
    [popupLoading setUseMotionEffects:true];
    [popupLoading show];
    
}
- (void)customIOS7dialogButtonTouchUpInside: (CustomIOS7AlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    [alertView close];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return data.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ListCategoryCell *cell = (ListCategoryCell *)[tableView dequeueReusableCellWithIdentifier:@"ListCategoryCell"];
    if(cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ListCategoryCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    [cell setData:[data objectAtIndex:indexPath.row]];
    
    return cell;
}

-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 250.0f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [[tableView cellForRowAtIndexPath:indexPath] setSelected:NO animated:YES];
    
    NSDictionary *dt = [data objectAtIndex:indexPath.row];
    RestaurantProfileVC *vc = [[RestaurantProfileVC alloc] initWithNibName:@"RestaurantProfileVC" bundle:nil];
    [vc setIdRestaurant:[[dt valueForKey:@"id"] intValue]];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)tableView:(UITableView *)tableView didEndEditingRowAtIndexPath:(NSIndexPath *)indexPath
{
	[tableView reloadData];
}
@end
