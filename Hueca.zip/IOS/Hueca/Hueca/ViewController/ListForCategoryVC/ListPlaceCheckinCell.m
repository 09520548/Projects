//
//  ListPlaceCheckinCell.m
//  Hueca
//
//  Created by Mobiz on 6/17/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "ListPlaceCheckinCell.h"

@implementation ListPlaceCheckinCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void) setData:(NSDictionary *)dt
{
    if (dt != nil) {
        self.title.font = [UIFont rw_FontRegularWithSize:14];
        self.title.text = [dt valueForKey:@"name"];
        self.distance.text = [dt valueForKey:@"distance"];
        self.numcheckin.text = [NSString stringWithFormat:@"%@ check-in",[dt valueForKey:@"checkin"]];
    }
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

- (float) getHeight
{
    return 44.0f;
}

@end
