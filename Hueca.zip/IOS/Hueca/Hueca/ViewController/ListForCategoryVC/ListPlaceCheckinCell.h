//
//  ListPlaceCheckinCell.h
//  Hueca
//
//  Created by Mobiz on 6/17/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ListPlaceCheckinCell : UITableViewCell
{
    NSDictionary *data;
}

- (void) setData:(NSDictionary *)dt;
- (float) getHeight;
@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UILabel *distance;
@property (weak, nonatomic) IBOutlet UILabel *numcheckin;
@property (weak, nonatomic) IBOutlet UIImageView *imgIcon;

@end
