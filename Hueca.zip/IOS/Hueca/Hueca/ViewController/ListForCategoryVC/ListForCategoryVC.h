//
//  ListForCategoryVC.h
//  Hueca
//
//  Created by NhiepPhong on 4/22/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewHeader.h"
#import "CategorySelectBox.h"
#import "CustomIOS7AlertView.h"

@interface ListForCategoryVC : UIViewController<UITableViewDataSource, UITableViewDelegate, CategorySelectBoxDelegate, CustomIOS7AlertViewDelegate>
{
    ViewHeader *viewHeader;
    CustomIOS7AlertView *popupLoading;
}
@property (weak, nonatomic) IBOutlet UIImageView *bg;
@property (weak, nonatomic) IBOutlet UIButton *btnFavourite;
@property (weak, nonatomic) IBOutlet UIButton *btnBest;
@property (weak, nonatomic) IBOutlet UIButton *btnRecommended;
@property (weak, nonatomic) IBOutlet UIButton *btnNew;
@property (weak, nonatomic) IBOutlet UIButton *btnSelectCate;
@property (weak, nonatomic) IBOutlet CategorySelectBox *viewSelectBox;
@property (weak, nonatomic) IBOutlet UITableView *table;

- (IBAction)onFilter:(UIButton *)sender;
- (IBAction)onOpenSelectCate:(UIButton *)sender;

@end
