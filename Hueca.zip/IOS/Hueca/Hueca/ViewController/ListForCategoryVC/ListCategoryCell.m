//
//  ListCategoryCell.m
//  Hueca
//
//  Created by NhiepPhong on 5/21/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "ListCategoryCell.h"
#import "NLoader.h"


static UIImage* Cell_bg = nil;
static UIImage* Cell_bgHover = nil;

@implementation ListCategoryCell

- (void)awakeFromNib
{

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

- (void) setData:(NSDictionary*)dt
{
    NSLog(@"DT %@", dt);
    self.count_comment.font = [UIFont rw_FontBoldWithSize:12];
    self.count_like.font = [UIFont rw_FontBoldWithSize:12];
    self.count_view.font = [UIFont rw_FontBoldWithSize:12];
    self.txt_rating.font = [UIFont rw_FontBoldWithSize:40];
    self.txt_rating.drawOutline = YES;
    self.txtName.font = [UIFont rw_FontBoldWithSize:20];
    self.txtName.drawOutline = YES;
    
    self.count_comment.text = [NSString stringWithFormat:@"%@", [dt valueForKey:@"count_comment"]];
    self.count_like.text = [NSString stringWithFormat:@"%@", [dt valueForKey:@"count_like"]];
    self.count_view.text = [NSString stringWithFormat:@"%@", [dt valueForKey:@"count_view"]];
    self.txt_rating.text = [NSString stringWithFormat:@"%@", [dt valueForKey:@"ranking"]];
    self.txtName.text = [NSString stringWithFormat:@"%@", [dt valueForKey:@"name"]];
    
    NSString *link_thumb = [dt valueForKey:@"thumb"];
    UIImage *image = nil;
    image = [NLoader imageWithURL:link_thumb
                  completeHandler:^(UIImage *img) { [self setImageThumb:img]; }
                            cache:nil];
    if(image)
    {
        [self setImageThumb:image];
    }
    
    [self.thumb setContentMode:UIViewContentModeScaleAspectFill];
    [self.thumb.layer setOpaque:YES];
    self.thumb.layer.cornerRadius = 2;
    self.thumb.layer.masksToBounds = YES;
    
    if(Cell_bg == nil)
    {
        Cell_bg = [UIImage imageNamed:@"list_cate_cell_bg"];
    }
    if(Cell_bgHover == nil)
    {
        Cell_bgHover = [UIImage imageNamed:@"list_cate_cell_bg_active"];
    }
    [self setBackgroundView:[[UIImageView alloc] initWithImage:Cell_bg]];
    [self setSelectedBackgroundView:[[UIImageView alloc] initWithImage:Cell_bgHover]];
}

- (void) setImageThumb:(UIImage*)img
{
    self.thumb.alpha = 0;
    [self.thumb setImage:img];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [UIView setAnimationDelay:0];
    
    self.thumb.alpha = 1;
    
    [UIView commitAnimations];
}

@end
