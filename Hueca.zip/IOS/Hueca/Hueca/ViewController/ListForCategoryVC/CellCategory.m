//
//  CellCategory.m
//  Hueca
//
//  Created by NhiepPhong on 5/2/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "CellCategory.h"

@implementation CellCategory

- (void)awakeFromNib
{
    
}

- (void) setData:(NSDictionary *)dt
{
    self.title.font = [UIFont rw_FontRegularWithSize:14];
    self.title.text = [dt valueForKey:@"name"];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

- (float) getHeight
{
    return 33.0f;
}
@end
