//
//  ListForCategoryCell.m
//  Hueca
//
//  Created by NhiepPhong on 4/23/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "ListForCategoryCell.h"
#import "NLoader.h"

@implementation ListForCategoryCell

static UIImage* Cell_bg = nil;
static UIImage* Cell_bgHover = nil;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
    
    }
    return self;
}

- (void) setData:(NSDictionary*)dt
{
    self.count_comment.font = [UIFont rw_FontBoldWithSize:8];
    self.count_like.font = [UIFont rw_FontBoldWithSize:8];
    self.count_view.font = [UIFont rw_FontBoldWithSize:8];
    
    self.count_comment.text = [NSString stringWithFormat:@"%@", [dt valueForKey:@"count_comment"]];
    self.count_like.text = [NSString stringWithFormat:@"%@", [dt valueForKey:@"count_like"]];
    self.count_view.text = [NSString stringWithFormat:@"%@", [dt valueForKey:@"count_view"]];
    
    NSString *link_thumb = [dt valueForKey:@"thumb"];
    UIImage *image = nil;
    image = [NLoader imageWithURL:link_thumb
                  completeHandler:^(UIImage *img) { [self setImageThumb:img]; }
                            cache:nil];
    if(image)
    {
        [self setImageThumb:image];
    }
    
    [self.thumb setContentMode:UIViewContentModeScaleAspectFill];
    [self.thumb.layer setOpaque:YES];
    self.thumb.layer.cornerRadius = 2;
    self.thumb.layer.masksToBounds = YES;
    
    if(Cell_bg == nil)
    {
        Cell_bg = [UIImage imageNamed:@"list_cate_cell_bg"];
    }
    if(Cell_bgHover == nil)
    {
        Cell_bgHover = [UIImage imageNamed:@"list_cate_cell_bg_active"];
    }
    [self setBackgroundView:[[UIImageView alloc] initWithImage:Cell_bg]];
    [self setSelectedBackgroundView:[[UIImageView alloc] initWithImage:Cell_bgHover]];
}

- (void) setImageThumb:(UIImage*)img
{
    self.thumb.alpha = 0;
    [self.thumb setImage:img];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [UIView setAnimationDelay:0];
    
    self.thumb.alpha = 1;
    
    [UIView commitAnimations];
}

- (void) setSelected:(BOOL)selected
{
    [super setSelected:selected];
}

@end
