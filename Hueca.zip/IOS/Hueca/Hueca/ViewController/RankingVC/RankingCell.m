//
//  RankingCell.m
//  Hueca
//
//  Created by NhiepPhong on 5/24/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "RankingCell.h"
#import "NLoader.h"

static UIImage* Cell_bg = nil;
static UIImage* Cell_bgHover = nil;

@implementation RankingCell

- (void)awakeFromNib
{

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

- (void) addData:(NSDictionary *)dt
{
    UIImage *image = nil;
    image = [NLoader imageWithURL:[dt valueForKey:@"image"]
                  completeHandler:^(UIImage *img) { [self.thumb setImage:img]; }
                            cache:nil];
    if(image)
    {
        [self.thumb setImage:image];
    }
    [self.thumb setContentMode:UIViewContentModeScaleAspectFill];
    
    self.txtName.text = [NSString stringWithFormat:@"%@", [dt valueForKey:@"full_name"]];
    self.txtPoint.text = [NSString stringWithFormat:@"%@", [dt valueForKey:@"point"]];
    self.txtRank.text = [NSString stringWithFormat:@"%@", [dt valueForKey:@"ranking"]];
    
    self.txtName.font = [UIFont rw_FontBoldWithSize:11];
    self.txtPoint.font = [UIFont rw_FontBoldWithSize:11];
    self.txtRank.font = [UIFont rw_FontBoldWithSize:11];

    [self.txtName sizeToFit];
    [self.txtPoint sizeToFit];
    
    CGRect framePoint = self.txtPoint.frame;
    framePoint.origin.x = self.txtName.frame.origin.x + self.txtName.frame.size.width + 5;
    self.txtPoint.frame = framePoint;
    
    if(Cell_bg == nil)
    {
        Cell_bg = [UIImage imageNamed:@"ranking_cell_bg"];
    }
    if(Cell_bgHover == nil)
    {
        Cell_bgHover = [UIImage imageNamed:@"ranking_cell_bg_active"];
    }
    [self setBackgroundView:[[UIImageView alloc] initWithImage:Cell_bg]];
    [self setSelectedBackgroundView:[[UIImageView alloc] initWithImage:Cell_bgHover]];
}

- (float) getHeight
{
    return self.frame.size.height;
}
@end
