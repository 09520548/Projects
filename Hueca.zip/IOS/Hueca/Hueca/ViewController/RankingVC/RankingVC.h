//
//  RankingVC.h
//  Hueca
//
//  Created by NhiepPhong on 5/24/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CategorySelectBox.h"
#import "ViewHeader.h"
#import "RankingCell.h"
#import "CustomIOS7AlertView.h"

@interface RankingVC : UIViewController<CategorySelectBoxDelegate, UITableViewDataSource, UITableViewDelegate, CustomIOS7AlertViewDelegate>
{
    CustomIOS7AlertView *popupLoading;
    ViewHeader *viewHeader;
    NSString *idCity;
    BOOL isLoading;
    BOOL isCanLoadMore;
    NSMutableArray *data;
}
@property (weak, nonatomic) IBOutlet UIImageView *bg;
@property (weak, nonatomic) IBOutlet UITableView *table;
@property (weak, nonatomic) IBOutlet UIButton *btnSelectCate;
@property (weak, nonatomic) IBOutlet CategorySelectBox *viewSelectBox;

- (IBAction)onOpenSelectCate:(UIButton *)sender;

@end
