//
//  RankingCell.h
//  Hueca
//
//  Created by NhiepPhong on 5/24/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RankingCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *thumb;
@property (weak, nonatomic) IBOutlet UILabel *txtName;
@property (weak, nonatomic) IBOutlet UILabel *txtPoint;
@property (weak, nonatomic) IBOutlet UILabel *txtRank;

- (void) addData:(NSDictionary *)dt;
- (float) getHeight;

@end
