//
//  RankingVC.m
//  Hueca
//
//  Created by NhiepPhong on 5/24/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "RankingVC.h"
#import "NDevice.h"
#import "GlobalData.h"
#import "NLoader.h"
#import "MyProfileVC.h"

@interface RankingVC ()

@end

@implementation RankingVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        data = [NSMutableArray new];
    }
    return self;
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    viewHeader = [[ViewHeader alloc] initWithFrame:CGRectMake(0, 0, 320, 46)];
    [self.view addSubview:viewHeader];
    
    [viewHeader setVC:self];
    [viewHeader setTitlePage:@"Rankings Usuarios"];
    
    NSString *imgName = @"bg";
    
    if([NDevice screenType] == NDeviceScreenIPHONE5)
    {
        imgName = @"bg-568h";
    }
    
    self.bg.image = [UIImage imageNamed:imgName];
    self.bg.frame = CGRectMake(0, 0, [NDevice getWidth], [NDevice getHeight]);
    
    self.btnSelectCate.titleLabel.font = [UIFont rw_FontBoldWithSize:16];
    
    [self.view addSubview:self.viewSelectBox];
    
    [self.viewSelectBox initView:self.view.frame];
    
    [self.btnSelectCate setTitle:@"Ciudad" forState:UIControlStateNormal];
    
    self.table.frame = CGRectMake(0, 80, 320, self.view.frame.size.height - 80);
    
    isCanLoadMore = TRUE;
    isLoading = FALSE;
    idCity = @"";
    data = [NSMutableArray new];
    [self.table reloadData];
    
    [self loadData];
}

- (void) loadData
{
    if(!isLoading)
    {
        if(data.count == 0)
        {
            [self showLoading];
        }
        isLoading = TRUE;
        dispatch_async(kBgQueue, ^{
            
            NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
            [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"email"] forKey:@"email"];
            [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"key"] forKey:@"key"];
            [params setObject:idCity forKey:@"city"];
            [params setObject:[NSString stringWithFormat:@"%d", data.count] forKey:@"start"];
            
            NSDictionary *response = [NLoader jsonDataOfURL:LINK_GET_RANKING params:params];
            
            [self performSelectorOnMainThread:@selector(getDataComplete:) withObject:response waitUntilDone:NO];
        });
    }
}

- (void) getDataComplete:(NSDictionary *)result
{
    isLoading = FALSE;
    isCanLoadMore = FALSE;
    [popupLoading close];
    
    if(result == nil)
    {
        [[GlobalData shareGlobalData] showAlert:@"Network error. Please check your connectivity." Title:@"Alert"];
    }
    else
    {
        if([[result valueForKey:@"status"] boolValue])
        {
            NSArray *dt = [result objectForKey:@"data"];
            [data addObjectsFromArray:dt];
            
            if(dt.count > 0)
            {
                isCanLoadMore = TRUE;
            }
            
            [self.table reloadData];
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (IBAction)onOpenSelectCate:(UIButton *)sender
{
    [self.viewSelectBox show];
}

- (void)onSelectCategory:(NSDictionary *)dt
{
    [self.btnSelectCate setTitle:[dt valueForKey:@"name"] forState:UIControlStateNormal];
    idCity = [NSString stringWithFormat:@"%@", [dt valueForKey:@"id"]];
    data = [NSMutableArray new];
    [self.table reloadData];
    [self loadData];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return data.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    RankingCell *cell = (RankingCell *)[tableView dequeueReusableCellWithIdentifier:@"RankingCell"];
    if(cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"RankingCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    [cell addData:[data objectAtIndex:indexPath.row]];
    
    return cell;
}

-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 41.0f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [[tableView cellForRowAtIndexPath:indexPath] setSelected:NO animated:YES];
    
    NSDictionary *dt = [data objectAtIndex:indexPath.row];
    MyProfileVC *vc = [[MyProfileVC alloc] initWithNibName:@"MyProfileVC" bundle:nil];
    [vc setUserID:[NSString stringWithFormat:@"%@", [dt valueForKey:@"id"]]];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)tableView:(UITableView *)tableView didEndEditingRowAtIndexPath:(NSIndexPath *)indexPath
{
	[tableView reloadData];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    float yOffset = scrollView.contentOffset.y;
    
    if(yOffset >= (scrollView.contentSize.height - scrollView.frame.size.height)-10)
    {
        if(isCanLoadMore && !isLoading)
        {
            [self loadData];
        }
    }
}

- (void) showLoading
{
    popupLoading = [[CustomIOS7AlertView alloc] init];
    
    [popupLoading setContainerView:[[GlobalData shareGlobalData] createViewLoading]];
    
    [popupLoading setButtonTitles:nil];
    [popupLoading setDelegate:self];
    
    [popupLoading setUseMotionEffects:true];
    [popupLoading show];
    
}
- (void)customIOS7dialogButtonTouchUpInside: (CustomIOS7AlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    [alertView close];
}
@end
