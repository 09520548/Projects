//
//  RegisterVC.h
//  Hueca
//
//  Created by NhiepPhong on 4/29/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomIOS7AlertView.h"
#import "GlobalData.h"
#import "NLoader.h"
#import "ViewHeader.h"

@interface RegisterVC : UIViewController<UITextFieldDelegate, UIAlertViewDelegate, CustomIOS7AlertViewDelegate>
{
    CustomIOS7AlertView *popupLoading;
    ViewHeader *viewHeader;
}

@property (weak, nonatomic) IBOutlet UIScrollView *scroll;
@property (weak, nonatomic) IBOutlet UIImageView *bg;
@property (weak, nonatomic) IBOutlet UITextField *input_full_name;
@property (weak, nonatomic) IBOutlet UITextField *input_email;
@property (weak, nonatomic) IBOutlet UITextField *input_pass;
@property (weak, nonatomic) IBOutlet UITextField *input_repass;
- (IBAction)onRegister:(UIButton *)sender;
@end
