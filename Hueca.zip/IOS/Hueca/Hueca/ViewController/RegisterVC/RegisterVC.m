//
//  RegisterVC.m
//  Hueca
//
//  Created by NhiepPhong on 4/29/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "RegisterVC.h"
#import "NDevice.h"
#import "AdvertisementVC.h"

@interface RegisterVC ()

@end

@implementation RegisterVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTapScroll:)];
        tapGesture.numberOfTapsRequired = 1;
        [self.view addGestureRecognizer:tapGesture];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    CGRect frameScroll = self.scroll.frame;
    frameScroll.size.height = self.view.frame.size.height;
    self.scroll.frame = frameScroll;
    [self.scroll setContentSize:CGSizeMake(1, 500)];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
    
    NSString *imgName = @"bg";
    
    if([NDevice screenType] == NDeviceScreenIPHONE5)
    {
        imgName = @"bg-568h";
    }
    
    viewHeader = [[ViewHeader alloc] initWithFrame:CGRectMake(0, 0, 320, 46)];
    [self.view addSubview:viewHeader];
    [viewHeader setVC:self];
    [viewHeader setTitlePage:@"Register"];
    [viewHeader.btnMenu setHidden:YES];
    
    self.bg.image = [UIImage imageNamed:imgName];
    self.bg.frame = CGRectMake(0, 0, [NDevice getWidth], [NDevice getHeight]);
    
    self.input_email.font = [UIFont rw_FontRegularWithSize:12];
    self.input_pass.font = [UIFont rw_FontRegularWithSize:12];
    self.input_repass.font = [UIFont rw_FontRegularWithSize:12];
}

- (void) viewWillDisappear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    
    [super viewWillDisappear:animated];
}

-(void) keyboardWillShow:(NSNotification *)notif
{
    NSDictionary* info = [notif userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    CGPoint pointFocusInput = CGPointMake(0, self.input_full_name.frame.origin.y - 50);
    [self.scroll setContentSize:CGSizeMake(1, 500 + kbSize.height)];
    [self.scroll setContentOffset:pointFocusInput animated:YES];
    
}

-(void) keyboardWillHide:(NSNotification *)notif
{
    [self.scroll setContentSize:CGSizeMake(1, 500)];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (IBAction)onRegister:(UIButton *)sender
{
    [self onTapScroll:nil];
    if([self.input_full_name.text isEqual:@""])
    {
        [[GlobalData shareGlobalData] showAlert:@"Please input your Name." Title:@"Register error!"];
    }
    else if([self.input_email.text isEqual:@""])
    {
        [[GlobalData shareGlobalData] showAlert:@"Please input your E-mail." Title:@"Register error!"];
    }
    else if([self.input_pass.text isEqual:@""])
    {
        [[GlobalData shareGlobalData] showAlert:@"Please input your password." Title:@"Register error!"];
    }
    else if(self.input_pass.text.length < 6)
    {
        [[GlobalData shareGlobalData] showAlert:@"Your password should be at least 6 characters." Title:@"Register error!"];
    }
    else if(![self.input_pass.text isEqualToString:self.input_repass.text])
    {
        [[GlobalData shareGlobalData] showAlert:@"Your password don't match." Title:@"Register error!"];
    }
    else
    {
        [self showLoading];
        dispatch_async(kBgQueue, ^{
            NSMutableDictionary * params = [[NSMutableDictionary alloc] init];
            [params setObject:self.input_email.text forKey:@"email"];
            [params setObject:self.input_pass.text forKey:@"password"];
            [params setObject:self.input_full_name.text forKey:@"full_name"];
            [params setObject:[GlobalData shareGlobalData].tokenDevice forKey:@"token"];
            [params setObject:[GlobalData shareGlobalData].deviceModel forKey:@"device"];
            [params setObject:@"ios" forKey:@"device_type"];
            
            NSDictionary *response = [NLoader jsonDataOfURL:LINK_REGISTER params:params];
            
            [self performSelectorOnMainThread:@selector(postDataComplete:) withObject:response waitUntilDone:NO];
        });
    }
}

- (void) postDataComplete:(NSDictionary *)result
{
    NSLog(@"postDataComplete %@", result);
    [popupLoading close];
    if(result == nil)
    {
        [[GlobalData shareGlobalData] showAlert:@"Network error. Please check your connectivity." Title:@"Register error!"];
    }
    else
    {
        id status = [result objectForKey:@"status"];
        
        if(status && [status boolValue])
        {
            [[GlobalData shareGlobalData] saveUserInfo:[result objectForKey:@"info"]];
            [GlobalData shareGlobalData].advertisement = [result objectForKey:@"advertisement"];
            
            [self gotoMainVC];
        }
        else
        {
            [[GlobalData shareGlobalData] showAlert:[result objectForKey:@"message"] Title:@"Register error!"];
        }
    }
}

- (void) gotoMainVC
{
    AdvertisementVC *vc = [[AdvertisementVC alloc] initWithNibName:@"AdvertisementVC" bundle:nil];
    [self.navigationController pushViewController:vc animated:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)theTextField
{
    if(theTextField == self.input_full_name)
    {
        [self.input_email becomeFirstResponder];
    }
    else if(theTextField == self.input_email)
    {
        [self.input_pass becomeFirstResponder];
    }
    else if(theTextField == self.input_pass)
    {
        [self.input_repass becomeFirstResponder];
    }
    else
    {
        [self onRegister:nil];
    }
    
    return YES;
}

- (void) onTapScroll:(id) sender
{
    [self.input_email resignFirstResponder];
    [self.input_pass resignFirstResponder];
    [self.input_repass resignFirstResponder];
    [self.input_full_name resignFirstResponder];
}

- (void) showLoading
{
    popupLoading = [[CustomIOS7AlertView alloc] init];
    
    [popupLoading setContainerView:[[GlobalData shareGlobalData] createViewLoading]];
    
    [popupLoading setButtonTitles:nil];
    [popupLoading setDelegate:self];
    
    [popupLoading setUseMotionEffects:true];
    [popupLoading show];
    
}
- (void)customIOS7dialogButtonTouchUpInside: (CustomIOS7AlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    [alertView close];
}

@end
