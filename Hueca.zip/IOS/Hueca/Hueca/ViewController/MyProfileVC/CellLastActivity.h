//
//  CellLastActivity.h
//  Hueca
//
//  Created by NhiepPhong on 4/29/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellLastActivity : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *thumb;
@property (weak, nonatomic) IBOutlet UILabel *txtContent;
@property (weak, nonatomic) IBOutlet UILabel *txtTime;

- (void) addData:(NSDictionary *)dt;

- (float) getHeight;

@end
