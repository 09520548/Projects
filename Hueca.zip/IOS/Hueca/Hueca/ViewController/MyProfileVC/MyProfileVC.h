//
//  MyProfileVC.h
//  Hueca
//
//  Created by NhiepPhong on 4/23/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewHeader.h"
#import "CellLastActivity.h"
#import "CustomIOS7AlertView.h"

@interface MyProfileVC : UIViewController<CustomIOS7AlertViewDelegate>
{
    ViewHeader *viewHeader;
    CellLastActivity *_stubCell;
    CustomIOS7AlertView *popupLoading;
    NSArray *dataAchievement;
    NSDictionary *dataUser;
    NSMutableArray *dataActivity;
    NSString *user_id;
    
    BOOL isLoading;
    BOOL isCanLoadMore;
    BOOL isLoadingUser;
}
@property (weak, nonatomic) IBOutlet UIImageView *bg;
@property (weak, nonatomic) IBOutlet UITableView *table;
@property (strong, nonatomic) IBOutlet UIView *viewInfo;
@property (weak, nonatomic) IBOutlet UIImageView *avatar;
@property (weak, nonatomic) IBOutlet UILabel *address;
@property (weak, nonatomic) IBOutlet UILabel *txt_current_rank;
@property (weak, nonatomic) IBOutlet UILabel *txt_rank;
@property (weak, nonatomic) IBOutlet UILabel *txt_points;
@property (weak, nonatomic) IBOutlet UILabel *txt_followers;
@property (weak, nonatomic) IBOutlet UILabel *txt_follower_val;
@property (weak, nonatomic) IBOutlet UILabel *txt_reviews;
@property (weak, nonatomic) IBOutlet UILabel *txt_reviews_val;
@property (weak, nonatomic) IBOutlet UILabel *txt_checkins;
@property (weak, nonatomic) IBOutlet UILabel *txt_checkins_val;
@property (weak, nonatomic) IBOutlet UIButton *btn_follower;
@property (weak, nonatomic) IBOutlet UIButton *btn_unfollower;
@property (weak, nonatomic) IBOutlet UILabel *txt_achievements;
@property (weak, nonatomic) IBOutlet UILabel *txt_last_qctivity;
@property (weak, nonatomic) IBOutlet UIScrollView *scroll_achievements;
@property (weak, nonatomic) IBOutlet UIImageView *badge_1;
@property (weak, nonatomic) IBOutlet UIImageView *badge_2;
@property (weak, nonatomic) IBOutlet UIImageView *badge_3;

- (IBAction)onFollower:(UIButton *)sender;
- (void) setUserID:(NSString *)user;

@end
