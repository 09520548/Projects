//
//  MyProfileVC.m
//  Hueca
//
//  Created by NhiepPhong on 4/23/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "MyProfileVC.h"
#import "NDevice.h"
#import "AchievementsView.h"
#import "GlobalData.h"
#import "NLoader.h"
#import "NPConstants.h"
#import "RestaurantProfileVC.h"

@interface MyProfileVC ()
{
    
}

@end

@implementation MyProfileVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        user_id = @"";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    NSString *imgName = @"bg";
    
    if([NDevice screenType] == NDeviceScreenIPHONE5)
    {
        imgName = @"bg-568h";
    }
    
    self.bg.image = [UIImage imageNamed:imgName];
    self.bg.frame = CGRectMake(0, 0, [NDevice getWidth], [NDevice getHeight]);
    
    viewHeader = [[ViewHeader alloc] initWithFrame:CGRectMake(0, 0, 320, 46)];
    [self.view addSubview:viewHeader];
    [viewHeader setVC:self];
    
    self.address.font = [UIFont rw_FontBoldWithSize:14];
    self.txt_current_rank.font = [UIFont rw_FontBoldWithSize:14];
    self.txt_rank.font = [UIFont rw_FontBoldWithSize:30];
    self.txt_points.font = [UIFont rw_FontBoldWithSize:14];
    self.txt_followers.font = [UIFont rw_FontBoldWithSize:12];
    self.txt_follower_val.font = [UIFont rw_FontRegularWithSize:15];
    self.txt_checkins.font = [UIFont rw_FontBoldWithSize:12];
    self.txt_checkins_val.font = [UIFont rw_FontRegularWithSize:15];
    self.txt_reviews.font = [UIFont rw_FontBoldWithSize:12];
    self.txt_reviews_val.font = [UIFont rw_FontRegularWithSize:15];
    
    self.txt_achievements.font = [UIFont rw_FontBoldWithSize:16];
    self.txt_last_qctivity.font = [UIFont rw_FontBoldWithSize:16];
    
    self.table.frame = CGRectMake(0, 46, 320, self.view.frame.size.height - 46);
    
    self.table.tableHeaderView = self.viewInfo;
    
    UINib *cellNib = [UINib nibWithNibName:@"CellLastActivity" bundle:nil];
    [self.table registerNib:cellNib forCellReuseIdentifier:@"CellLastActivity"];
    _stubCell = [cellNib instantiateWithOwner:nil options:nil][0];
    
    [viewHeader setTitlePage:@"Loading ..."];
    dataActivity = [NSMutableArray new];
    
    isLoading = FALSE;
    isCanLoadMore = TRUE;
    isLoadingUser = FALSE;
    
    [self.badge_1 setImage:nil];
    [self.badge_2 setImage:nil];
    [self.badge_3 setImage:nil];
    
    [self.avatar setImage:nil];
    
    [self loadData];
}

- (void) setUserID:(NSString *)user
{
    user_id = user;
}

- (void) loadData
{
    if(!isLoadingUser)
    {
        isLoadingUser = TRUE;
        [self showLoading];
        
        if([user_id isEqualToString:@""])
        {
            user_id = [[GlobalData shareGlobalData].userInfo valueForKey:@"id"];
        }
        
        dispatch_async(kBgQueue, ^{
            NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
            [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"email"] forKey:@"email"];
            [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"key"] forKey:@"key"];
            [params setObject:user_id forKey:@"user_id"];
            
            NSDictionary *response = [NLoader jsonDataOfURL:LINK_GET_PROFILE params:params];
            
            [self performSelectorOnMainThread:@selector(getProfileComplete:) withObject:response waitUntilDone:NO];
        });
    }
}

- (void) getProfileComplete:(NSDictionary *)result
{
    isLoadingUser = FALSE;
    [popupLoading close];
    if(result == nil)
    {
        [[GlobalData shareGlobalData] showAlert:@"Network error. Please check your connectivity." Title:@"Alert"];
    }
    else
    {
        dataUser = [result objectForKey:@"info"];
        dataAchievement = [result objectForKey:@"achievement"];
        
        [viewHeader setTitlePage:[dataUser valueForKey:@"full_name"]];
        
        [self.avatar setContentMode:UIViewContentModeScaleAspectFill];
        self.avatar.layer.masksToBounds = TRUE;
        
        UIImage *image = nil;
        image = [NLoader imageWithURL:[dataUser valueForKey:@"avatar"]
                      completeHandler:^(UIImage *img) { [self.avatar setImage:img]; }
                                cache:nil];
        if(image)
        {
            [self.avatar setImage:image];
        }
    
        
        int cityId = [[dataUser valueForKey:@"city"] intValue];
        NSArray *citys = [GlobalData shareGlobalData].dataCity;
        NSString *city = @"";
        
        for(int i = 0; i < citys.count; i++)
        {
            if([[[citys objectAtIndex:i] valueForKey:@"id"] intValue] == cityId)
            {
                city = [[citys objectAtIndex:i] valueForKey:@"name"];
                break;
            }
        }
        self.address.text = [NSString stringWithFormat:@"Quito, %@", city];
        self.txt_rank.text = [NSString stringWithFormat:@"%@", [dataUser valueForKey:@"ranking"]];
        self.txt_points.text = [NSString stringWithFormat:@"%@ Puntos", [dataUser valueForKey:@"point"]];
        self.txt_follower_val.text = [NSString stringWithFormat:@"%@", [dataUser valueForKey:@"followers"]];
        self.txt_checkins_val.text = [NSString stringWithFormat:@"%@", [dataUser valueForKey:@"pins"]];
        self.txt_reviews_val.text = [NSString stringWithFormat:@"%@", [dataUser valueForKey:@"reviews"]];
        
        if([[dataUser valueForKey:@"is_follow"] boolValue])
        {
            [self.btn_unfollower setHidden:NO];
            [self.btn_follower setHidden:YES];
        }
        else
        {
            [self.btn_unfollower setHidden:YES];
            [self.btn_follower setHidden:NO];
        }
        
        if([[dataUser valueForKey:@"id"] intValue] == [[[GlobalData shareGlobalData].userInfo valueForKey:@"id"] intValue])
        {
            [self.btn_unfollower setHidden:YES];
            [self.btn_follower setHidden:YES];
        }
        
        int x = 10;
        
        for(int i = 0; i < dataAchievement.count; i++)
        {
            AchievementsView *item = [[AchievementsView alloc] initWithFrame:CGRectMake(x, 0, 43, 43)];
            [item setData:[dataAchievement objectAtIndex:i]];
            x += 43 + 5;
            [self.scroll_achievements addSubview:item];
        }
        
        x += 5;
        
        [self.scroll_achievements setContentSize:CGSizeMake(x, 1)];
        
        NSArray *badges = [result objectForKey:@"badges"];
        
        if(badges.count >= 1)
        {
            UIImage *image_1 = nil;
            image_1 = [NLoader imageWithURL:[badges objectAtIndex:0]
                            completeHandler:^(UIImage *img) { [self.badge_1 setImage:img]; }
                                      cache:nil];
            if(image_1)
            {
                [self.badge_1 setImage:image_1];
            }
        }
        if(badges.count >= 2)
        {
            UIImage *image_2 = nil;
            image_2 = [NLoader imageWithURL:[badges objectAtIndex:1]
                            completeHandler:^(UIImage *img) { [self.badge_2 setImage:img]; }
                                      cache:nil];
            if(image_2)
            {
                [self.badge_2 setImage:image_2];
            }
        }
        if(badges.count >= 3)
        {
            UIImage *image_3 = nil;
            image_3 = [NLoader imageWithURL:[badges objectAtIndex:1]
                            completeHandler:^(UIImage *img) { [self.badge_3 setImage:img]; }
                                      cache:nil];
            if(image_3)
            {
                [self.badge_3 setImage:image_3];
            }
        }
        
        [self.table reloadData];
        [self loadActivity];
    }
}

- (void) loadActivity
{
    if(!isLoading)
    {
        NSLog(@"loadActivity");
        isLoading = TRUE;
        [self showLoading];
        
        if([user_id isEqualToString:@""])
        {
            user_id = [[GlobalData shareGlobalData].userInfo valueForKey:@"id"];
        }
        
        dispatch_async(kBgQueue, ^{
            NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
            [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"email"] forKey:@"email"];
            [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"key"] forKey:@"key"];
            [params setObject:user_id forKey:@"user_id"];
            [params setObject:[NSString stringWithFormat:@"%d", dataActivity.count] forKey:@"start"];
            
            NSDictionary *response = [NLoader jsonDataOfURL:LINK_GET_ACTIVITY params:params];
            
            [self performSelectorOnMainThread:@selector(getActivityComplete:) withObject:response waitUntilDone:NO];
        });
    }
}

- (void) getActivityComplete:(NSArray *)result
{
    NSLog(@"getActivityComplete %@", result);
    [popupLoading close];
    if(result == nil)
    {
        [[GlobalData shareGlobalData] showAlert:@"Network error. Please check your connectivity." Title:@"Alert"];
    }
    else
    {
        isCanLoadMore = FALSE;
        if(result.count > 0)
        {
            isCanLoadMore = TRUE;
            [dataActivity addObjectsFromArray:result];
            [self.table reloadData];
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (IBAction)onFollower:(UIButton *)sender
{
    if(sender.tag == 0) //Follower
    {
        [self.btn_unfollower setHidden:NO];
        [self.btn_follower setHidden:YES];
    }
    else // UnFollower
    {
        [self.btn_unfollower setHidden:YES];
        [self.btn_follower setHidden:NO];
    }
}

#pragma mark - Table

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [dataActivity count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellLastActivity *cell = (CellLastActivity *)[tableView dequeueReusableCellWithIdentifier:@"CellLastActivity"];
    if(cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"CellLastActivity" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    [self configureCell:cell atIndexPath:indexPath];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self configureCell:_stubCell atIndexPath:indexPath];
    CGFloat height = [_stubCell getHeight];
    return height;
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 47.f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [[tableView cellForRowAtIndexPath:indexPath] setSelected:NO animated:YES];
    
    NSDictionary *dt = [dataActivity objectAtIndex:indexPath.row];

    if([[dt valueForKey:@"obj"] intValue] == 0)
    {
        
    }
    else
    {
        RestaurantProfileVC *vc = [[RestaurantProfileVC alloc] initWithNibName:@"RestaurantProfileVC" bundle:nil];
        [vc setIdRestaurant:[[dt valueForKey:@"id"] intValue]];
        [self.navigationController pushViewController:vc animated:YES];
    }
}

- (void)configureCell:(CellLastActivity *)cell atIndexPath:(NSIndexPath *)indexPath
{
    [cell addData:[dataActivity objectAtIndex:indexPath.row]];
}

- (void) showLoading
{
    popupLoading = [[CustomIOS7AlertView alloc] init];
    
    [popupLoading setContainerView:[[GlobalData shareGlobalData] createViewLoading]];
    
    [popupLoading setButtonTitles:nil];
    [popupLoading setDelegate:self];
    
    [popupLoading setUseMotionEffects:true];
    [popupLoading show];
    
}
- (void)customIOS7dialogButtonTouchUpInside: (CustomIOS7AlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    [alertView close];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    float yOffset = scrollView.contentOffset.y;
    
    if(yOffset >= (scrollView.contentSize.height - scrollView.frame.size.height)-10)
    {
        if(isCanLoadMore && !isLoading)
        {
            [self loadData];
        }
    }
}
@end
