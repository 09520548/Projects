//
//  AchievementsView.h
//  Hueca
//
//  Created by NhiepPhong on 4/29/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AchievementsView : UIView
{
    UIImageView *bg;
    UIImageView *thumb;
}
- (void) setData:(NSString *)link;

@end
