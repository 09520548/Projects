//
//  AchievementsView.m
//  Hueca
//
//  Created by NhiepPhong on 4/29/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "AchievementsView.h"
#import "NLoader.h"

@implementation AchievementsView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
    
    }
    
    bg = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 43, 43)];
    [self addSubview:bg];
    bg.image = [UIImage imageNamed:@"profile_achievements_bg"];
    
    thumb = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 43, 43)];
    [self addSubview:thumb];
    
    [thumb setContentMode:UIViewContentModeScaleAspectFill];
    thumb.layer.masksToBounds = TRUE;
    
    return self;
}

- (void) setData:(NSString *)link
{
    UIImage *image = nil;
    image = [NLoader imageWithURL:link
                  completeHandler:^(UIImage *img) { [thumb setImage:img]; }
                            cache:nil];
    if(image)
    {
        [thumb setImage:image];
    }
    
}
@end
