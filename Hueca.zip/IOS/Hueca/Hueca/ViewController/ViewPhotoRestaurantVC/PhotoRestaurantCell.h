//
//  PhotoRestaurantCell.h
//  Hueca
//
//  Created by NhiepPhong on 5/7/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotoRestaurantCell : UITableViewCell
{
    UIImageView *animationImageView;
}

@property (weak, nonatomic) IBOutlet UIImageView *photo;
@property (weak, nonatomic) IBOutlet UIImageView *thumb;
@property (weak, nonatomic) IBOutlet UILabel *txtName;
@property (weak, nonatomic) IBOutlet UILabel *txtTime;
@property (weak, nonatomic) IBOutlet UIView *viewContent;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *loading;

- (void) addData:(NSDictionary *)dt;
- (float) getHeight;


@end
