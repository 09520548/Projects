//
//  PhotoRestaurantCell.m
//  Hueca
//
//  Created by NhiepPhong on 5/7/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "PhotoRestaurantCell.h"
#import "NLoader.h"

@implementation PhotoRestaurantCell

- (void)awakeFromNib
{
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

- (void) addData:(NSDictionary *)dt
{
    
    self.thumb.layer.borderColor = [[UIColor whiteColor] CGColor];
    self.thumb.layer.borderWidth = 1;
    self.txtName.font = [UIFont rw_FontBoldWithSize:11];
    self.txtTime.font = [UIFont rw_FontBoldWithSize:9];
    self.txtName.text = [dt valueForKey:@"name"];
    self.txtTime.text = [dt valueForKey:@"time"];
    
    int w = [[dt valueForKey:@"w"] intValue];
    int h = [[dt valueForKey:@"h"] intValue];
    float scale = 320.0f/w;
    float hNew = h * scale;
    
    CGRect frame = self.frame;
    frame.size.height = hNew;
    self.frame = frame;
    
    CGRect frameThumb = self.photo.frame;
    frameThumb.size.height = hNew;
    self.photo.frame = frameThumb;
    
    CGRect frameContent = self.viewContent.frame;
    frameContent.origin.y = self.frame.size.height - frameContent.size.height - 10;
    self.viewContent.frame = frameContent;
    
//    CGRect frameLoading = self.loading.frame;
//    frameLoading.origin.x = (320 - frameLoading.size.width)/2;
//    frameLoading.origin.y = (self.frame.size.height - frameLoading.size.height)/2;
//    self.loading.frame = frameLoading;
    
    NSArray *imageNames = @[@"logo_hueca_0.png", @"logo_hueca_1.png", @"logo_hueca_2.png", @"logo_hueca_3.png",
                            @"logo_hueca_4.png", @"logo_hueca_5.png", @"logo_hueca_6.png", @"logo_hueca_7.png",
                            @"logo_hueca_8.png", @"logo_hueca_9.png", @"logo_hueca_10.png", @"logo_hueca_11.png",
                            @"logo_hueca_12.png", @"logo_hueca_13.png", @"logo_hueca_14.png", @"logo_hueca_15.png", @"logo_hueca_16.png", @"logo_hueca_17.png", @"logo_hueca_18.png",
                            @"logo_hueca_19.png", @"logo_hueca_20.png", @"logo_hueca_21.png", @"logo_hueca_22.png", @"logo_hueca_23.png", @"logo_hueca_24.png"];
    
    NSMutableArray *images = [[NSMutableArray alloc] init];
    for (int i = 0; i < imageNames.count; i++) {
        [images addObject:[UIImage imageNamed:[imageNames objectAtIndex:i]]];
    }
    
    // Normal Animation
    animationImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 75, 45)];
    animationImageView.animationImages = images;
    animationImageView.animationDuration = 1;
    animationImageView.center = self.loading.center;
    CGRect frameLoading = animationImageView.frame;
    frameLoading.origin.x = (320 - frameLoading.size.width)/2;
    frameLoading.origin.y = (self.frame.size.height - frameLoading.size.height)/2;
    animationImageView.frame = frameLoading;
    
    
    [self.thumb setContentMode:UIViewContentModeScaleAspectFill];
    UIImage *image = nil;
    image = [NLoader imageWithURL:[dt valueForKey:@"avatar"]
                  completeHandler:^(UIImage *img) { [self.thumb setImage:img]; }
                            cache:nil];
    if(image)
    {
        [self.thumb setImage:image];
    }
    
    [self.photo setContentMode:UIViewContentModeScaleAspectFit];
    UIImage *photo = nil;
    [self.photo setImage:photo];
//    [self.loading startAnimating];
    [animationImageView startAnimating];
    
    photo = [NLoader imageWithURL:[dt valueForKey:@"img"]
                  completeHandler:^(UIImage *img) { [self setPhotoView:img]; }
                            cache:nil];
    if(photo)
    {
        [self setPhotoView:photo];
    }
}

- (void) setPhotoView:(UIImage *)img
{
//    [self.loading stopAnimating];
    [animationImageView stopAnimating];
    
    self.photo.alpha = 0;
    [self.photo setImage:img];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.2];
    [UIView setAnimationDelay:0];
    
    self.photo.alpha = 1;
    
    [UIView commitAnimations];
    
}

- (float) getHeight
{
    return self.frame.size.height;
}
@end
