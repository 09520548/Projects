//
//  ViewPhotoRestaurantVC.h
//  Hueca
//
//  Created by NhiepPhong on 5/7/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewHeader.h"
#import "PhotoRestaurantCell.h"
#import "CustomIOS7AlertView.h"

@interface ViewPhotoRestaurantVC : UIViewController<UITableViewDataSource, UITableViewDelegate, CustomIOS7AlertViewDelegate>
{
    NSDictionary *dataRestaurant;
    NSMutableArray *data;
    ViewHeader *viewHeader;
    PhotoRestaurantCell *_stubCell;
    CustomIOS7AlertView *popupLoading;
}

@property (weak, nonatomic) IBOutlet UIImageView *bg;
@property (weak, nonatomic) IBOutlet UITableView *table;

- (void) addRestaurant:(NSDictionary *)dt;


@end
