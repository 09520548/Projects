//
//  CalloutView.m
//  MCoupon
//
//  Created by NhiepPhong on 5/4/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "CalloutView.h"
#import "NLoader.h"

@implementation CalloutView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        UIView* xibView = [[[NSBundle mainBundle] loadNibNamed:@"CalloutView" owner:self options:nil] objectAtIndex:0];
        [xibView setFrame:[self bounds]];
        [self addSubview:xibView];
    }
    return self;
}


- (void) show:(NSDictionary *)dt
{
    data = dt;
    
    [self.thumb setContentMode:UIViewContentModeScaleAspectFill];
    self.thumb.layer.cornerRadius = 2;
    [self.thumb.layer setOpaque:YES];
    self.thumb.layer.masksToBounds = YES;
    
    self.title.font = [UIFont rw_FontBoldWithSize:16];
    self.ranking.font = [UIFont rw_FontBoldWithSize:19];
    
    self.title.text = [dt valueForKey:@"name"];
    self.ranking.text = [NSString stringWithFormat:@"%@", [dt valueForKey:@"ranking"]];
    
    [self setImageThumb:[UIImage imageNamed:@"location_default.jpg"]];
    
    UIImage *image = nil;
    image = [NLoader imageWithURL:[dt valueForKey:@"thumb"]
                  completeHandler:^(UIImage *img) { [self setImageThumb:img]; }
                            cache:nil];
    if(image)
    {
        [self setImageThumb:image];
    }
    
}

- (NSDictionary *)getData
{
    return data;
}


- (void) setImageThumb:(UIImage *)img
{
    self.thumb.alpha = 0;
    self.thumb.image = img;
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.2];
    [UIView setAnimationDelay:0];
    
    self.thumb.alpha = 1;
    
    [UIView commitAnimations];
}

@end
