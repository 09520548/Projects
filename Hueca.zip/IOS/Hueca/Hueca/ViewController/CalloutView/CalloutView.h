//
//  CalloutView.h
//  MCoupon
//
//  Created by NhiepPhong on 5/4/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CalloutView : UIView
{
    NSDictionary *data;
}
@property (weak, nonatomic) IBOutlet UIImageView *thumb;
@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UILabel *ranking;

- (void) show:(NSDictionary *)dt;
- (NSDictionary *)getData;


@end
