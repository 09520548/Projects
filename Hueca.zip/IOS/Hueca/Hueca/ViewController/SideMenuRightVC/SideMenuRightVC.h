//
//  SideMenuRightVC.h
//  Hueca
//
//  Created by NhiepPhong on 5/5/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIViewController+MMDrawerController.h"
#import <MessageUI/MessageUI.h>

@interface SideMenuRightVC : UIViewController<MFMailComposeViewControllerDelegate>

@property (weak, nonatomic) IBOutlet UIImageView *bg;
@property (weak, nonatomic) IBOutlet UIImageView *avatar;
@property (weak, nonatomic) IBOutlet UILabel *txt_name;
@property (weak, nonatomic) IBOutlet UILabel *txt_address;
@property (weak, nonatomic) IBOutlet UITableView *table;
@property (weak, nonatomic) IBOutlet UIView *viewContent;

- (IBAction)onOpenEditProfile:(UIButton *)sender;
@end
