//
//  MenuCell.h
//  Hueca
//
//  Created by NhiepPhong on 5/5/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *thumb;
@property (weak, nonatomic) IBOutlet UILabel *title;

- (void) addData:(NSDictionary *)dt;

@end
