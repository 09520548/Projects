//
//  SideMenuRightVC.m
//  Hueca
//
//  Created by NhiepPhong on 5/5/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "SideMenuRightVC.h"
#import "NDevice.h"
#import "MenuCell.h"
#import "AppDelegate.h"
#import "GlobalData.h"
#import "SlashAppVC.h"
#import "ListForCategoryVC.h"
#import "FeedVC.h"
#import "HomeVC.h"
#import "MyProfileVC.h"
#import "NLoader.h"
#import "EditProfileVC.h"
#import "RankingVC.h"

@interface SideMenuRightVC ()
{
    NSMutableArray *dataMenu;
}
@end

@implementation SideMenuRightVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
    
    }
    return self;
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    NSString *imgName = @"menu_right_bg";
    
    if([NDevice screenType] == NDeviceScreenIPHONE5)
    {
        imgName = @"menu_right_bg-568h";
    }
    
    self.bg.image = [UIImage imageNamed:imgName];
    self.bg.frame = CGRectMake(0, 0, [NDevice getWidth], [NDevice getHeight]);
    
    CGRect frameContent = self.viewContent.frame;
    frameContent.origin.y = 10;
    if([NDevice screenType] == NDeviceScreenIPHONE5)
    {
        frameContent.origin.y = 80;
    }
    
    frameContent.size.height = self.view.frame.size.height - frameContent.origin.y;
    self.viewContent.frame = frameContent;
    
    [self.avatar setContentMode:UIViewContentModeScaleAspectFill];
    self.avatar.layer.cornerRadius = 52;
    [self.avatar.layer setOpaque:YES];
    self.avatar.layer.masksToBounds = YES;
    self.avatar.layer.borderWidth = 4.0f;
    self.avatar.layer.borderColor = [[UIColor colorFromHexString:@"#464c5b"] CGColor];
    
    self.txt_name.font = [UIFont rw_FontRegularWithSize:15];
    self.txt_address.font = [UIFont rw_FontRegularWithSize:12];
    
    CGRect frameTable = self.table.frame;
    frameTable.size.height = self.viewContent.frame.size.height - frameTable.origin.y;
    self.table.frame = frameTable;
    
    dataMenu = [NSMutableArray new];
    [dataMenu addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"Perfil", @"title", @"perfil", @"thumb", nil]];
    [dataMenu addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"Mapa", @"title", @"mapa", @"thumb", nil]];
    [dataMenu addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"Rankings", @"title", @"rankings", @"thumb", nil]];
    [dataMenu addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"Feed", @"title", @"feed", @"thumb", nil]];
    [dataMenu addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"Huecas", @"title", @"huecas", @"thumb", nil]];
    [dataMenu addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"Reportar Error", @"title", @"reportar", @"thumb", nil]];
    
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 227, 95)];
    UIView *footerLine = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 227, 1)];
    footerLine.backgroundColor = [UIColor colorFromHexString:@"#454b5a"];
    [footerView addSubview:footerLine];
    
    UIButton *btnLogout = [UIButton buttonWithType:UIButtonTypeCustom];
    [btnLogout setImage:[UIImage imageNamed:@"btn_logout"] forState:UIControlStateNormal];
    btnLogout.frame = CGRectMake(0, 36, 227, 29);
    [btnLogout addTarget:self action:@selector(onLogout) forControlEvents:UIControlEventTouchUpInside];
    [footerView addSubview:btnLogout];
    
    self.table.tableFooterView = footerView;
    
    [self.table reloadData];
    
    [self addDataUser];
}

- (void) addDataUser
{
    NSDictionary *user = [GlobalData shareGlobalData].userInfo;
    
    self.txt_name.text = [user valueForKey:@"full_name"];
    
    int cityId = [[user valueForKey:@"city"] intValue];
    NSArray *citys = [GlobalData shareGlobalData].dataCity;
    NSString *city = @"";
    
    for(int i = 0; i < citys.count; i++)
    {
        if([[[citys objectAtIndex:i] valueForKey:@"id"] intValue] == cityId)
        {
            city = [[citys objectAtIndex:i] valueForKey:@"name"];
            break;
        }
    }
    
    self.txt_address.text = [NSString stringWithFormat:@"Quito, %@", city];
    
    UIImage *image = nil;
    image = [NLoader imageWithURL:[user valueForKey:@"avatar"]
                  completeHandler:^(UIImage *img) { [self.avatar setImage:img]; }
                            cache:nil];
    if(image)
    {
        [self.avatar setImage:image];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void) onLogout
{
    [[GlobalData shareGlobalData] clearUserInfo];
    
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    UINavigationController *navi = (UINavigationController  *)appDelegate.window.rootViewController;
    [navi dismissViewControllerAnimated:YES completion:nil];
    
    SlashAppVC *vc = [[SlashAppVC alloc] initWithNibName:@"SlashAppVC" bundle:nil];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    [nav.navigationBar setHidden:YES];
    
    appDelegate.window.rootViewController = nav;
}

#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return dataMenu.count;
}

-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 45;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MenuCell *cell = (MenuCell *)[tableView dequeueReusableCellWithIdentifier:@"MenuCell"];
    if(cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MenuCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    [cell addData:[dataMenu objectAtIndex:indexPath.row]];
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [[tableView cellForRowAtIndexPath:indexPath] setSelected:NO animated:YES];
    
    NSDictionary *dt = [dataMenu objectAtIndex:indexPath.row];
    if([[dt valueForKey:@"thumb"] isEqualToString:@"perfil"])
    {
        [self onGoProfile];
    }
    else if ([[dt valueForKey:@"thumb"] isEqualToString:@"mapa"])
    {
        [self onGoHome];
    }
    else if ([[dt valueForKey:@"thumb"] isEqualToString:@"rankings"])
    {
        [self onGoRanking];
    }
    else if ([[dt valueForKey:@"thumb"] isEqualToString:@"feed"])
    {
        [self onGoFeed];
    }
    else if ([[dt valueForKey:@"thumb"] isEqualToString:@"huecas"])
    {
        [self onGoList];
    }
    else if ([[dt valueForKey:@"thumb"] isEqualToString:@"reportar"])
    {
        if ([MFMailComposeViewController canSendMail])
        {
            MFMailComposeViewController *mailer = [[MFMailComposeViewController alloc] init];
            
            mailer.mailComposeDelegate = self;
            
            [mailer setSubject:@"A Message from MobileTuts+"];
            
            NSArray *toRecipients = [NSArray arrayWithObjects:@"fisrtMail@example.com", @"secondMail@example.com", nil];
            [mailer setToRecipients:toRecipients];
            
            UIImage *myImage = [UIImage imageNamed:@"logo.png"];
            NSData *imageData = UIImagePNGRepresentation(myImage);
            [mailer addAttachmentData:imageData mimeType:@"image/png" fileName:@"logo"];
            
            NSString *emailBody = @"Have you seen the MobileTuts+ web site?";
            [mailer setMessageBody:emailBody isHTML:NO];
            
            [self presentViewController:mailer animated:YES completion:nil];
        }
        else
        {
            [[GlobalData shareGlobalData] showAlert:@"Your device doesn't support the composer sheet." Title:@"Failure"];
        }
    }
}

- (void)tableView:(UITableView *)tableView didEndEditingRowAtIndexPath:(NSIndexPath *)indexPath
{
	[tableView reloadData];
}

- (void) onGoList
{
    ListForCategoryVC *vc = [[ListForCategoryVC alloc] initWithNibName:@"ListForCategoryVC" bundle:nil];
    UINavigationController *navigationController = (UINavigationController*)self.mm_drawerController.centerViewController;
    [navigationController pushViewController:vc animated:NO];
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideRight animated:YES completion:nil];
}

- (void) onGoFeed
{
    FeedVC *vc = [[FeedVC alloc] initWithNibName:@"FeedVC" bundle:nil];
    UINavigationController *navigationController = (UINavigationController*)self.mm_drawerController.centerViewController;
    [navigationController pushViewController:vc animated:NO];
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideRight animated:YES completion:nil];
}

- (void) onGoRanking
{
    RankingVC *vc = [[RankingVC alloc] initWithNibName:@"RankingVC" bundle:nil];
    UINavigationController *navigationController = (UINavigationController*)self.mm_drawerController.centerViewController;
    [navigationController pushViewController:vc animated:NO];
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideRight animated:YES completion:nil];
}

- (void) onGoHome
{
    HomeVC *vc = [[HomeVC alloc] initWithNibName:@"HomeVC" bundle:nil];
    UINavigationController *navigationController = (UINavigationController*)self.mm_drawerController.centerViewController;
    [navigationController pushViewController:vc animated:NO];
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideRight animated:YES completion:nil];
}

- (void) onGoProfile
{
    MyProfileVC *vc = [[MyProfileVC alloc] initWithNibName:@"MyProfileVC" bundle:nil];
    UINavigationController *navigationController = (UINavigationController*)self.mm_drawerController.centerViewController;
    [navigationController pushViewController:vc animated:NO];
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideRight animated:YES completion:nil];
}
- (IBAction)onOpenEditProfile:(UIButton *)sender
{
    EditProfileVC *vc = [[EditProfileVC alloc] initWithNibName:@"EditProfileVC" bundle:nil];
    UINavigationController *navigationController = (UINavigationController*)self.mm_drawerController.centerViewController;
    [navigationController pushViewController:vc animated:NO];
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideRight animated:YES completion:nil];
}

- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    switch (result)
    {
        case MFMailComposeResultCancelled:
            NSLog(@"Mail cancelled: you cancelled the operation and no email message was queued.");
            break;
        case MFMailComposeResultSaved:
            NSLog(@"Mail saved: you saved the email message in the drafts folder.");
            break;
        case MFMailComposeResultSent:
            NSLog(@"Mail send: the email message is queued in the outbox. It is ready to send.");
            break;
        case MFMailComposeResultFailed:
            NSLog(@"Mail failed: the email message was not saved or queued, possibly due to an error.");
            break;
        default:
            NSLog(@"Mail not sent.");
            break;
    }
    
    // Remove the mail view
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
