//
//  MenuCell.m
//  Hueca
//
//  Created by NhiepPhong on 5/5/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "MenuCell.h"

@implementation MenuCell

static UIImage* Cell_bg = nil;
static UIImage* Cell_bgHover = nil;

- (void)awakeFromNib
{
    
}

- (void) addData:(NSDictionary *)dt
{
    self.title.text = [dt valueForKey:@"title"];
    
    [self.thumb setContentMode:UIViewContentModeScaleAspectFit];
    self.thumb.image = [UIImage imageNamed:[dt valueForKey:@"thumb"]];
    
    if(Cell_bg == nil)
    {
        Cell_bg = [UIImage imageNamed:@"menu_right_cell_bg"];
    }
    if(Cell_bgHover == nil)
    {
        Cell_bgHover = [UIImage imageNamed:@"menu_right_cell_bg_active"];
    }
    [self setBackgroundView:[[UIImageView alloc] initWithImage:Cell_bg]];
    [self setSelectedBackgroundView:[[UIImageView alloc] initWithImage:Cell_bgHover]];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

@end
