//
//  ViewHeader.h
//  Hueca
//
//  Created by NhiepPhong on 4/29/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewHeader : UIView
{
    UIViewController *viewCurrent;
}
@property (weak, nonatomic) IBOutlet UILabel *title_page;
@property (weak, nonatomic) IBOutlet UIButton *btnMenu;
- (void) setVC:(UIViewController *)vc;
- (void) setTitlePage:(NSString *)title;

- (IBAction)onBack:(UIButton *)sender;
- (IBAction)openMenu:(UIButton *)sender;
@end
