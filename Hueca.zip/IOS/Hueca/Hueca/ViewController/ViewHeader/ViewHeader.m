//
//  ViewHeader.m
//  Hueca
//
//  Created by NhiepPhong on 4/29/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "ViewHeader.h"
#import "UIViewController+MMDrawerController.h"

@implementation ViewHeader

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        UIView* xibView = [[[NSBundle mainBundle] loadNibNamed:@"ViewHeader" owner:self options:nil] objectAtIndex:0];
        [xibView setFrame:[self bounds]];
        [self addSubview:xibView];
    }
    return self;
}

- (void) setVC:(UIViewController *)vc
{
    viewCurrent = vc;
}
- (void) setTitlePage:(NSString *)title
{
    self.title_page.font = [UIFont rw_FontBoldWithSize:16];
    self.title_page.text = title;
}

- (IBAction)onBack:(UIButton *)sender
{
    [viewCurrent.navigationController popViewControllerAnimated:YES];
}

- (IBAction)openMenu:(UIButton *)sender
{
    [viewCurrent.mm_drawerController toggleDrawerSide:MMDrawerSideRight animated:YES completion:nil];
}
@end
