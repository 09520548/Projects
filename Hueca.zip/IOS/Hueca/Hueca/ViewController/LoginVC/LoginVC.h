//
//  LoginVC.h
//  Hueca
//
//  Created by NhiepPhong on 4/22/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomIOS7AlertView.h"
#import "AppDelegate.h"
#import "GlobalData.h"
#import "NLoader.h"

@interface LoginVC : UIViewController<UITextFieldDelegate, UIAlertViewDelegate, CustomIOS7AlertViewDelegate>
{
    CustomIOS7AlertView *popupLoading;
    NSArray *permissions;
    AppDelegate *appDelegate;
}
@property (weak, nonatomic) IBOutlet UIImageView *bg;
@property (weak, nonatomic) IBOutlet UITextField *input_email;
@property (weak, nonatomic) IBOutlet UITextField *input_pass;
@property (weak, nonatomic) IBOutlet UIButton *btn_login;
@property (weak, nonatomic) IBOutlet UIButton *btn_login_fb;
- (IBAction)onLogin:(UIButton *)sender;
- (IBAction)onLoginFB:(UIButton *)sender;
- (IBAction)onRegister:(UIButton *)sender;

@end
