//
//  LoginVC.m
//  Hueca
//
//  Created by NhiepPhong on 4/22/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "LoginVC.h"
#import "NDevice.h"
#import "AdvertisementVC.h"
#import "RegisterVC.h"

@interface LoginVC ()

@end

@implementation LoginVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTapScroll:)];
        tapGesture.numberOfTapsRequired = 1;
        [self.view addGestureRecognizer:tapGesture];
    }
    return self;
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
    
    NSString *imgName = @"bg";
    
    if([NDevice screenType] == NDeviceScreenIPHONE5)
    {
        imgName = @"bg-568h";
    }
    
    self.bg.image = [UIImage imageNamed:imgName];
    self.bg.frame = CGRectMake(0, 0, [NDevice getWidth], [NDevice getHeight]);
    
    self.input_email.font = [UIFont rw_FontRegularWithSize:12];
    self.input_pass.font = [UIFont rw_FontRegularWithSize:12];
}

- (void)viewDidLoad
{
    permissions = @[
                    @"public_profile",
                    @"user_about_me",
                    @"user_birthday",
                    @"email",
                    @"user_likes"];
    appDelegate = [[UIApplication sharedApplication]delegate];
    
    [super viewDidLoad];
}

- (void) viewWillDisappear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    
    [super viewWillDisappear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

-(void) keyboardWillShow:(NSNotification *)note
{
    NSNumber *duration = [note.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    NSNumber *curve = [note.userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey];
    
	CGRect containerFrame = self.view.frame;
    containerFrame.origin.y = -150;
    
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:[duration doubleValue]];
    [UIView setAnimationCurve:[curve intValue]];
	self.view.frame = containerFrame;
    
	[UIView commitAnimations];
}

-(void) keyboardWillHide:(NSNotification *)note
{
    NSNumber *duration = [note.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    NSNumber *curve = [note.userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey];

	CGRect containerFrame = self.view.frame;
    containerFrame.origin.y = 0;
    
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:[duration doubleValue]];
    [UIView setAnimationCurve:[curve intValue]];
    
	self.view.frame = containerFrame;
    
	[UIView commitAnimations];
}

- (IBAction)onLogin:(UIButton *)sender
{
    [self onTapScroll:nil];
    
    if([self.input_email.text isEqual:@""])
    {
        [[GlobalData shareGlobalData] showAlert:@"Please input your E-mail." Title:@"Login error!"];
    }
    else if([self.input_pass.text isEqual:@""])
    {
        [[GlobalData shareGlobalData] showAlert:@"Please input your password." Title:@"Login error!"];
    }
//    else if(self.input_pass.text.length < 6)
//    {
//        [[GlobalData shareGlobalData] showAlert:@"Your password should be at least 6 characters." Title:@"Login error!"];
//    }
    else
    {
        [self showLoading];
        dispatch_async(kBgQueue, ^{
            NSMutableDictionary * params = [[NSMutableDictionary alloc] init];
            [params setObject:@"web" forKey:@"type"];
            [params setObject:self.input_email.text forKey:@"email"];
            [params setObject:self.input_pass.text forKey:@"password"];
            [params setObject:[GlobalData shareGlobalData].tokenDevice forKey:@"token"];
            [params setObject:[GlobalData shareGlobalData].deviceModel forKey:@"device"];
            [params setObject:@"ios" forKey:@"device_type"];
            
            NSDictionary *response = [NLoader jsonDataOfURL:LINK_LOGIN params:params];
            
            [self performSelectorOnMainThread:@selector(postDataComplete:) withObject:response waitUntilDone:NO];
        });
    }
}

- (void) postDataComplete:(NSDictionary *)result
{
    [popupLoading close];
    if(result == nil)
    {
        [[GlobalData shareGlobalData] showAlert:@"Network error. Please check your connectivity." Title:@"Login error!"];
    }
    else
    {
        id status = [result objectForKey:@"status"];
        
        if(status && [status boolValue])
        {
            [[GlobalData shareGlobalData] saveUserInfo:[result objectForKey:@"info"]];
            [GlobalData shareGlobalData].advertisement = [result objectForKey:@"advertisement"];
            
            [self gotoMainVC];
        }
        else
        {
            [[GlobalData shareGlobalData] showAlert:[result objectForKey:@"message"] Title:@"Login error!"];
        }
    }
}

- (void) gotoMainVC
{
    AdvertisementVC *vc = [[AdvertisementVC alloc] initWithNibName:@"AdvertisementVC" bundle:nil];
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)onLoginFB:(UIButton *)sender
{
    if (appDelegate.session.isOpen)
    {
        //[appDelegate.session closeAndClearTokenInformation];
        [self onGetDataFacebook];
        
    }
    else
    {
        appDelegate.session = [[FBSession alloc] initWithPermissions:permissions];
        
        [appDelegate.session openWithCompletionHandler:^(FBSession *session,
                                                         FBSessionState status,
                                                         NSError *error) {
            [self onGetDataFacebook];
        }];
        
    }
}

- (IBAction)onRegister:(UIButton *)sender
{
    RegisterVC *vc = [[RegisterVC alloc] initWithNibName:@"RegisterVC" bundle:nil];
    [self.navigationController pushViewController:vc animated:YES];
}

-(void) onGetDataFacebook
{
    if(appDelegate.session.accessTokenData.accessToken != nil)
    {
        [self showLoading];
        
        NSString *link_get_info_fb = [NSString stringWithFormat:@"https://graph.facebook.com/me?access_token=%@", appDelegate.session.accessTokenData.accessToken];
        dispatch_async(kBgQueue, ^{
            
            NSDictionary *response = [NLoader jsonDataOfURL:link_get_info_fb];
            
            [self performSelectorOnMainThread:@selector(getInfoFBComplete:) withObject:response waitUntilDone:NO];
        });
    }
}

- (void)getInfoFBComplete:(NSDictionary *)result
{
    if (result)
    {
        NSLog(@"getInfoFBComplete: %@", result);
        dispatch_async(kBgQueue, ^{
            
            NSMutableDictionary * params = [[NSMutableDictionary alloc] init];
            [params setObject:@"fb" forKey:@"type"];
            [params setObject:[result objectForKey:@"email"] forKey:@"email"];
            [params setObject:[result objectForKey:@"name"] forKey:@"full_name"];
            [params setObject:[result objectForKey:@"id"] forKey:@"fb_id"];
            [params setObject:[GlobalData shareGlobalData].tokenDevice forKey:@"token"];
            [params setObject:[GlobalData shareGlobalData].deviceModel forKey:@"device"];
            [params setObject:@"ios" forKey:@"device_type"];
            NSString *avatar = [NSString stringWithFormat:@"https://graph.facebook.com/%@/picture", [result objectForKey:@"id"]];
            [params setObject:avatar forKey:@"avatar"];

            NSDictionary *response = [NLoader jsonDataOfURL:LINK_LOGIN params:params];
            
            [self performSelectorOnMainThread:@selector(postDataComplete:) withObject:response waitUntilDone:NO];
        });
    }
    else
    {
        [popupLoading close];
        [[GlobalData shareGlobalData] showAlert:@"Unable to reach Facebook. Please register with your E-mail." Title:@"Login error!"];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)theTextField
{
    if(theTextField.tag == 0)
    {
        [self.input_pass becomeFirstResponder];
    }
    else
    {
        [self onLogin:nil];
    }
    
    return YES;
}

- (void) onTapScroll:(id) sender
{
    [self.input_email resignFirstResponder];
    [self.input_pass resignFirstResponder];
}

- (void) showLoading
{
    popupLoading = [[CustomIOS7AlertView alloc] init];
    
    [popupLoading setContainerView:[[GlobalData shareGlobalData] createViewLoading]];
    
    [popupLoading setButtonTitles:nil];
    [popupLoading setDelegate:self];
    
    [popupLoading setUseMotionEffects:true];
    [popupLoading show];
    
}
- (void)customIOS7dialogButtonTouchUpInside: (CustomIOS7AlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    [alertView close];
}

@end
