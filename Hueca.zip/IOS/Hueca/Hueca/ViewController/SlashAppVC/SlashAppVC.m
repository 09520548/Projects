//
//  SlashAppVC.m
//  Hueca
//
//  Created by NhiepPhong on 4/22/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "SlashAppVC.h"
#import "NDevice.h"
#import "NLoader.h"
#import "GlobalData.h"
#import "LoginVC.h"
#import "AdvertisementVC.h"

@interface SlashAppVC ()

@end

@implementation SlashAppVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
    
    }
    return self;
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    NSString *imgName = @"Default";
    
    if([NDevice screenType] == NDeviceScreenIPHONE5)
    {
        imgName = @"Default-568h";
    }
    
    self.bg.image = [UIImage imageNamed:imgName];
    self.bg.frame = CGRectMake(0, 0, [NDevice getWidth], [NDevice getHeight]);
    
    [NSTimer scheduledTimerWithTimeInterval: 1.0
                                     target: self
                                   selector:@selector(onGoApps:)
                                   userInfo: nil repeats:NO];
    
}

-(void)onGoApps:(NSTimer *)timer
{
    [self loadCity];
}

- (void) loadCity
{
    dispatch_async(kBgQueue, ^{
        NSDictionary *response = [NLoader jsonDataOfURL:LINK_GET_CITY params:nil];
        [self performSelectorOnMainThread:@selector(getCityComplete:) withObject:response waitUntilDone:NO];
    });
}

- (void) getCityComplete:(NSArray *)result
{
    if(result == nil)
    {
        [self showAlertPopup:@"Network error. Please check your connectivity." andTitle:@"Alert"];
    }
    else
    {
        [GlobalData shareGlobalData].dataCity = [[NSArray alloc] initWithArray:result];
        
        [self loadPlace];
    }
}

- (void) loadPlace
{
    dispatch_async(kBgQueue, ^{
        NSDictionary *response = [NLoader jsonDataOfURL:LINK_GET_PLACE params:nil];
        [self performSelectorOnMainThread:@selector(getPlaceComplete:) withObject:response waitUntilDone:NO];
    });
}

- (void) getPlaceComplete:(NSArray *)result
{
    if(result == nil)
    {
        [self showAlertPopup:@"Network error. Please check your connectivity." andTitle:@"Alert"];
    }
    else
    {
        [GlobalData shareGlobalData].dataPlace = [[NSArray alloc] initWithArray:result];
        
        [self loadDishes];
    }
}

- (void) loadDishes
{
    dispatch_async(kBgQueue, ^{
        NSDictionary *response = [NLoader jsonDataOfURL:LINK_GET_DISHES params:nil];
        [self performSelectorOnMainThread:@selector(getDishesComplete:) withObject:response waitUntilDone:NO];
    });
}

- (void) getDishesComplete:(NSArray *)result
{
    if(result == nil)
    {
        [self showAlertPopup:@"Network error. Please check your connectivity." andTitle:@"Alert"];
    }
    else
    {
        [GlobalData shareGlobalData].dataDishes = [[NSArray alloc] initWithArray:result];
        
        [[GlobalData shareGlobalData] getUserInfo];
        
        if([GlobalData shareGlobalData].userInfo == nil)
        {
            [self gotoLogin];
        }
        else
        {
            [self checkUser];
        }
    }
}

- (void) checkUser
{
    dispatch_async(kBgQueue, ^{
        NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:[[GlobalData shareGlobalData].userInfo valueForKey:@"email"], @"email", [[GlobalData shareGlobalData].userInfo valueForKey:@"key"], @"key", nil];
        NSDictionary *response = [NLoader jsonDataOfURL:LINK_GET_USER params:params];
        
        [self performSelectorOnMainThread:@selector(getUserInfoComplete:) withObject:response waitUntilDone:NO];
    });
}

- (void) getUserInfoComplete:(NSDictionary *)result
{
    if(result == nil)
    {
        [self showAlertPopup:@"Network error. Please check your connectivity." andTitle:@"Alert"];
    }
    else
    {
        id status = [result objectForKey:@"status"];
        
        if(status && [status boolValue])
        {
            NSDictionary *data = [result objectForKey:@"info"];
            
            [[GlobalData shareGlobalData] saveUserInfo:data];
            [GlobalData shareGlobalData].advertisement = [result objectForKey:@"advertisement"];
            
            [self gotoHome];
        }
        else
        {
            [self gotoLogin];
        }
    }
}

- (void) gotoLogin
{
    [self.loading stopAnimating];
    LoginVC *vc = [[LoginVC alloc] initWithNibName:@"LoginVC" bundle:nil];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void) gotoHome
{
    [self.loading stopAnimating];
    AdvertisementVC *vc = [[AdvertisementVC alloc] initWithNibName:@"AdvertisementVC" bundle:nil];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void) showAlertPopup:(NSString *)txt andTitle:(NSString *)title
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
                                                        message:txt
                                                       delegate:self
                                              cancelButtonTitle:@"Exit App"
                                              otherButtonTitles:@"Try Again", nil];
    [alertView show];
}

- (void) alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 0)
    {
        exit(0);
    }
    else
    {
        [self checkUser];
    }
}
@end
