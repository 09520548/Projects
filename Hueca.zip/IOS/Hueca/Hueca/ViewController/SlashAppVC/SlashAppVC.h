//
//  SlashAppVC.h
//  Hueca
//
//  Created by NhiepPhong on 4/22/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SlashAppVC : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *bg;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *loading;

@end
