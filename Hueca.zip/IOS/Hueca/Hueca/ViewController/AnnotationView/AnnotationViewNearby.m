//
//  AnnotationView.m
//  MCoupon
//
//  Created by NhiepPhong on 5/4/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "AnnotationViewNearby.h"

@implementation AnnotationViewNearby

- (void) addData:(NSDictionary *)dtLocation
{
    dataLocation = dtLocation;
    float latitude = [[dataLocation valueForKey:@"latitude"] floatValue];
    float longitude = [[dataLocation valueForKey:@"longitude"] floatValue];
    self.image = [UIImage imageNamed:@"location_default.jpg"];
    self.title = [dataLocation valueForKey:@"name"];
    self.subtitle = [NSString stringWithFormat:@"%@",[dataLocation valueForKey:@"ranking"]];
    self.coordinate = CLLocationCoordinate2DMake(latitude, longitude);
}
@end
