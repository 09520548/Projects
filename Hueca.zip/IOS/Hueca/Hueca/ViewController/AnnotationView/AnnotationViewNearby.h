//
//  AnnotationViewNearby.h
//  MCoupon
//
//  Created by NhiepPhong on 5/4/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>

@interface AnnotationViewNearby : NSObject
{
    NSDictionary *dataLocation;
}
@property (nonatomic, assign) int tag;
@property (nonatomic, strong) UIImage *image;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *subtitle;
@property (nonatomic, assign) CLLocationCoordinate2D coordinate;

- (void) addData:(NSDictionary *)dtLocation;
@end
