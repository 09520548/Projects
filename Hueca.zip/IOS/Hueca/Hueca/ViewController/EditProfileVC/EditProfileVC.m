//
//  EditProfileVC.m
//  Hueca
//
//  Created by NhiepPhong on 5/15/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "EditProfileVC.h"

@interface EditProfileVC ()
{
    BOOL isLoading;
    NSString *idCity;
}
@end

@implementation EditProfileVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        dtCitySelect = nil;
    }
    return self;
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
    
    tapGestureKeyboard = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTapHideKeyboard:)];
    tapGestureKeyboard.numberOfTapsRequired = 1;
    
    viewHeader = [[ViewHeader alloc] initWithFrame:CGRectMake(0, 0, 320, 46)];
    [self.view addSubview:viewHeader];
    
    [viewHeader setVC:self];
    [viewHeader setTitlePage:@"Calificar [restaurant name]"];
    
    NSString *imgName = @"bg";
    
    if([NDevice screenType] == NDeviceScreenIPHONE5)
    {
        imgName = @"bg-568h";
    }
    
    self.bg.image = [UIImage imageNamed:imgName];
    self.bg.frame = CGRectMake(0, 0, [NDevice getWidth], [NDevice getHeight]);
    
    [self.view addSubview:self.scroll];
    
    CGRect frameScroll = self.scroll.frame;
    frameScroll.origin.y = 46;
    frameScroll.size.height = self.view.frame.size.height - 46;
    self.scroll.frame = frameScroll;
    self.scroll.backgroundColor = [UIColor clearColor];
    [self.scroll setContentSize:CGSizeMake(1, 605)];
    
    self.avatar.layer.borderColor = [UIColor colorFromHexString:@"#050505"].CGColor;
    self.avatar.layer.borderWidth = 0.5f;
    self.avatar.layer.cornerRadius = 2;
    self.avatar.layer.masksToBounds = YES;
    [self.avatar setContentMode:UIViewContentModeScaleAspectFill];
    
    [self.viewSelectBox initView:self.view.frame];
    
    [self.view addSubview:self.viewSelectBox];
    
    isLoading = FALSE;
    
    [self addData];
}

- (void) addData
{
    NSDictionary *user = [GlobalData shareGlobalData].userInfo;
    [viewHeader setTitlePage:[user valueForKey:@"full_name"]];
    self.txt_name.text = [user valueForKey:@"full_name"];
    self.txt_email.text = [user valueForKey:@"email"];
    
    int city_id = [[user valueForKey:@"city"] intValue];
    NSArray *citys = [GlobalData shareGlobalData].dataCity;
    NSString *city = @"Quito";
    
    idCity = [NSString stringWithFormat:@"%d", city_id];
    
    for(int i = 0; i < citys.count; i++)
    {
        if([[[citys objectAtIndex:i] valueForKey:@"id"] intValue] == city_id)
        {
            city = [[citys objectAtIndex:i] valueForKey:@"name"];
            break;
        }
    }
    
    [self.btnCity setTitle:city forState:UIControlStateNormal];
    
    UIImage *image = nil;
    image = [NLoader imageWithURL:[user valueForKey:@"avatar"]
                  completeHandler:^(UIImage *img) { [self.avatar setImage:img]; }
                            cache:nil];
    if(image)
    {
        [self.avatar setImage:image];
    }
}

- (void) viewWillDisappear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    
    [super viewWillDisappear:animated];
}

- (BOOL) textFieldShouldReturn:(UITextField *)textField
{
    if(textField == self.txt_current_password)
    {
        [self.txt_new_password becomeFirstResponder];
    }
    else if(textField == self.txt_new_password)
    {
        [self.txt_re_new_password becomeFirstResponder];
    }
    else if(textField == self.txt_re_new_password)
    {
        [self.txt_name becomeFirstResponder];
    }
    else if(textField == self.txt_name)
    {
        [self onSubmit:nil];
    }
    return NO;
}

- (void) onTapHideKeyboard:(id)sender
{
    [self.txt_current_password resignFirstResponder];
    [self.txt_new_password resignFirstResponder];
    [self.txt_re_new_password resignFirstResponder];
    [self.txt_name resignFirstResponder];
    [self.txt_email resignFirstResponder];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (IBAction)onChangeAvatar:(UIButton *)sender
{
    pickerUpload = [[UIImagePickerController alloc] init];
    [pickerUpload setDelegate:self];
    [pickerUpload setAllowsEditing:NO];
    [pickerUpload setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    [self presentViewController:pickerUpload animated:YES completion:nil];
}

#pragma mark - UIImagePickerControllerDelegate


- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    [self dismissViewControllerAnimated:YES completion:nil];
    
    thumb = [info objectForKey:UIImagePickerControllerOriginalImage];
    
    [self.avatar setImage:thumb];
    
}

- (IBAction)onOpenCity:(id)sender
{
    [self.viewSelectBox show];
    [self.view removeGestureRecognizer:tapGestureKeyboard];
}

- (IBAction)onSubmit:(UIButton *)sender
{
    [self onTapHideKeyboard:nil];
    
    BOOL isSubmit = FALSE;
    
    if([self.txt_name.text isEqual:@""])
    {
        [[GlobalData shareGlobalData] showAlert:@"Please input your Name." Title:@"Update Profile error!"];
    }
    else if(![self.txt_current_password.text isEqual:@""])
    {
        
        if(self.txt_new_password.text.length < 6)
        {
            [[GlobalData shareGlobalData] showAlert:@"Your password should be at least 6 characters." Title:@"Update Profile error!"];
        }
        else if(![self.txt_new_password.text isEqualToString:self.txt_re_new_password.text])
        {
            [[GlobalData shareGlobalData] showAlert:@"Your password don't match." Title:@"Update Profile error!"];
        }
        else
        {
            isSubmit = TRUE;
        }
    }
    else
    {
        isSubmit = TRUE;
    }
    
    if(isSubmit)
    {
        if(!isLoading)
        {
            isLoading = TRUE;
            dispatch_async(kBgQueue, ^{
                
                NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
                [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"email"] forKey:@"email"];
                [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"key"] forKey:@"key"];
                [params setObject:idCity forKey:@"city"];
                if(![self.txt_current_password.text isEqualToString:@""])
                {
                    [params setObject:self.txt_current_password.text forKey:@"current_password"];
                    [params setObject:self.txt_new_password.text forKey:@"new_password"];
                }
                [params setObject:self.txt_name.text forKey:@"full_name"];
                
                NSDictionary *response = nil;
                
                if(thumb != nil)
                {
                    NSData *data = UIImageJPEGRepresentation(thumb, 1.0f);
                    response = [NLoader jsonWithURL:LINK_UPDATE_PROFILE params:params fileData:data];
                }
                else
                {
                    response = [NLoader jsonDataOfURL:LINK_UPDATE_PROFILE params:params];
                }
                
                [self performSelectorOnMainThread:@selector(getDataComplete:) withObject:response waitUntilDone:NO];
            });
        }
    }
}

- (void) getDataComplete:(NSDictionary *)result
{
    isLoading = FALSE;
    if(result == nil)
    {
        [[GlobalData shareGlobalData] showAlert:@"Network error. Please check your connectivity." Title:@"Alert"];
    }
    else
    {
        if([[result valueForKey:@"status"] boolValue])
        {
            [[GlobalData shareGlobalData] saveUserInfo:[result objectForKey:@"info"]];
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Update Succeed!"
                                                                message:[result objectForKey:@"message"]
                                                               delegate:self
                                                      cancelButtonTitle:@"OK"
                                                      otherButtonTitles:nil];
            [alertView show];
//            [self.navigationController popViewControllerAnimated:YES];
        }
        else
        {
            [[GlobalData shareGlobalData] showAlert:[result objectForKey:@"message"] Title:@"Update Profile error!"];
        }
    }
}

- (void)onSelectCategory:(NSDictionary *)dt
{
    dtCitySelect = [[NSDictionary alloc] initWithDictionary:dt];
    idCity = [NSString stringWithFormat:@"%@", [dtCitySelect valueForKey:@"id"]];
    
    [self.btnCity setTitle:[dt valueForKeyPath:@"name"] forState:UIControlStateNormal];
    [self.view addGestureRecognizer:tapGestureKeyboard];
}

- (void) onClosePopupCategorySelect
{
    [self.view addGestureRecognizer:tapGestureKeyboard];
}

- (void) showLoading
{
    popupLoading = [[CustomIOS7AlertView alloc] init];
    
    [popupLoading setContainerView:[[GlobalData shareGlobalData] createViewLoading]];
    
    [popupLoading setButtonTitles:nil];
    [popupLoading setDelegate:self];
    
    [popupLoading setUseMotionEffects:true];
    [popupLoading show];
    
}
- (void)customIOS7dialogButtonTouchUpInside: (CustomIOS7AlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    [alertView close];
}

-(void) keyboardWillShow:(NSNotification *)notif
{
    [self.view addGestureRecognizer:tapGestureKeyboard];
    NSDictionary* info = [notif userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    [self.scroll setContentSize:CGSizeMake(1, 605 + kbSize.height)];
}

-(void) keyboardWillHide:(NSNotification *)notif
{
    [self.view removeGestureRecognizer:tapGestureKeyboard];
    [self.scroll setContentSize:CGSizeMake(1, 605)];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [self.navigationController popViewControllerAnimated:YES];
}
@end
