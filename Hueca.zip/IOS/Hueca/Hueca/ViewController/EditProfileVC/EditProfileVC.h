//
//  EditProfileVC.h
//  Hueca
//
//  Created by NhiepPhong on 5/15/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomIOS7AlertView.h"
#import "ViewHeader.h"
#import "NDevice.h"
#import "GlobalData.h"
#import "NPConstants.h"
#import "NLoader.h"
#import "CategorySelectBox.h"

@interface EditProfileVC : UIViewController<UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, CustomIOS7AlertViewDelegate, CategorySelectBoxDelegate, UIAlertViewDelegate>
{
    ViewHeader *viewHeader;
    CustomIOS7AlertView *popupLoading;
    UITapGestureRecognizer *tapGestureKeyboard;
    UIImage *thumb;
    UIImagePickerController *pickerUpload;
    NSDictionary *dtCitySelect;
}

@property (weak, nonatomic) IBOutlet UIImageView *bg;
@property (strong, nonatomic) IBOutlet UIScrollView *scroll;
@property (weak, nonatomic) IBOutlet UITextField *txt_current_password;
@property (weak, nonatomic) IBOutlet UITextField *txt_new_password;
@property (weak, nonatomic) IBOutlet UITextField *txt_re_new_password;
@property (weak, nonatomic) IBOutlet UIImageView *avatar;
@property (weak, nonatomic) IBOutlet UITextField *txt_name;
@property (weak, nonatomic) IBOutlet UITextField *txt_email;
@property (weak, nonatomic) IBOutlet UIButton *btnCity;
@property (weak, nonatomic) IBOutlet CategorySelectBox *viewSelectBox;

- (IBAction)onChangeAvatar:(UIButton *)sender;
- (IBAction)onOpenCity:(id)sender;
- (IBAction)onSubmit:(UIButton *)sender;
@end
