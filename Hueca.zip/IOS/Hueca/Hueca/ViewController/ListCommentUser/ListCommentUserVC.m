//
//  ListCommentUserVC.m
//  Hueca
//
//  Created by NhiepPhong on 5/3/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "ListCommentUserVC.h"
#import "NDevice.h"
#import "NLoader.h"
#import "NPConstants.h"
#import "GlobalData.h"
#import "MyProfileVC.h"

@interface ListCommentUserVC ()

@end

@implementation ListCommentUserVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        data = [NSMutableArray new];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    UINib *cellNib = [UINib nibWithNibName:@"CellCommentUser" bundle:nil];
    [self.table registerNib:cellNib forCellReuseIdentifier:@"CellCommentUser"];
    _stubCell = [cellNib instantiateWithOwner:nil options:nil][0];
    
    viewHeader = [[ViewHeader alloc] initWithFrame:CGRectMake(0, 0, 320, 46)];
    [self.view addSubview:viewHeader];
    
    [viewHeader setVC:self];
    [viewHeader setTitlePage:@"Comentarios"];
    
    NSString *imgName = @"bg";
    
    if([NDevice screenType] == NDeviceScreenIPHONE5)
    {
        imgName = @"bg-568h";
    }
    
    self.bg.image = [UIImage imageNamed:imgName];
    self.bg.frame = CGRectMake(0, 0, [NDevice getWidth], [NDevice getHeight]);
    
    self.table.frame = CGRectMake(0, 46, 320, self.view.frame.size.height - 46);
    
    UIView *viewHeaderTable = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 20)];
    viewHeaderTable.backgroundColor = [UIColor clearColor];
    self.table.tableHeaderView = viewHeaderTable;
    
    [self loadData];
}

- (void) addRestaurant:(NSDictionary *)dt
{
    dataRestaurant = dt;
}

- (void) loadData
{
    [self showLoading];
    dispatch_async(kBgQueue, ^{
        NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
        [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"email"] forKey:@"email"];
        [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"key"] forKey:@"key"];
        [params setObject:[NSString stringWithFormat:@"%@", [dataRestaurant valueForKey:@"id"]] forKey:@"id"];
        
        NSDictionary *response = [NLoader jsonDataOfURL:LINK_GET_COMMENT params:params];
        
        [self performSelectorOnMainThread:@selector(getDataComplete:) withObject:response waitUntilDone:NO];
    });
}

- (void) getDataComplete:(NSArray *)result
{
    [popupLoading close];
    if(result == nil)
    {
        [[GlobalData shareGlobalData] showAlert:@"Network error. Please check your connectivity." Title:@"Alert"];
    }
    else
    {
        if(result.count > 0)
        {
            data = [[NSMutableArray alloc] initWithArray:result];
            [self.table reloadData];
        }
    }
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return data.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellCommentUser *cell = (CellCommentUser *)[tableView dequeueReusableCellWithIdentifier:@"CellCommentUser"];
    if(cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"CellCommentUser" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    [self configureCell:cell atIndexPath:indexPath];
    return cell;
}

-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self configureCell:_stubCell atIndexPath:indexPath];
    CGFloat height = [_stubCell getHeight];
    return height;
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 33.f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [[tableView cellForRowAtIndexPath:indexPath] setSelected:NO animated:YES];
    
    NSDictionary *dt = [data objectAtIndex:indexPath.row];
    MyProfileVC *vc = [[MyProfileVC alloc] initWithNibName:@"MyProfileVC" bundle:nil];
    [vc setUserID:[NSString stringWithFormat:@"%@", [dt valueForKey:@"id"]]];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)tableView:(UITableView *)tableView didEndEditingRowAtIndexPath:(NSIndexPath *)indexPath
{
	[tableView reloadData];
}

- (void)configureCell:(CellCommentUser *)cell atIndexPath:(NSIndexPath *)indexPath
{
    [cell addData:[data objectAtIndex:indexPath.row]];
}
- (void) showLoading
{
    popupLoading = [[CustomIOS7AlertView alloc] init];
    
    [popupLoading setContainerView:[[GlobalData shareGlobalData] createViewLoading]];
    
    [popupLoading setButtonTitles:nil];
    [popupLoading setDelegate:self];
    
    [popupLoading setUseMotionEffects:true];
    [popupLoading show];
    
}
- (void)customIOS7dialogButtonTouchUpInside: (CustomIOS7AlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    [alertView close];
}
@end
