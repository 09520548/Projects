//
//  CellCommentUser.h
//  Hueca
//
//  Created by NhiepPhong on 5/3/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellCommentUser : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *thumb;
@property (weak, nonatomic) IBOutlet UILabel *txtContent;

- (void) addData:(NSDictionary *)dt;
- (float) getHeight;

@end
