//
//  ListCommentUserVC.h
//  Hueca
//
//  Created by NhiepPhong on 5/3/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewHeader.h"
#import "CellCommentUser.h"
#import "CustomIOS7AlertView.h"

@interface ListCommentUserVC : UIViewController<UITableViewDataSource, UITableViewDelegate, CustomIOS7AlertViewDelegate>
{
    ViewHeader *viewHeader;
    NSMutableArray *data;
    CellCommentUser *_stubCell;
    NSDictionary *dataRestaurant;
    CustomIOS7AlertView *popupLoading;
}
@property (weak, nonatomic) IBOutlet UIImageView *bg;
@property (weak, nonatomic) IBOutlet UITableView *table;

- (void) addRestaurant:(NSDictionary *)dt;

@end
