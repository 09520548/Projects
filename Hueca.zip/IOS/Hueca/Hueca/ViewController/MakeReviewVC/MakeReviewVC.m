//
//  MakeReviewVC.m
//  Hueca
//
//  Created by NhiepPhong on 5/5/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "MakeReviewVC.h"
#import "NDevice.h"
#import "GlobalData.h"
#import "NPConstants.h"
#import "NLoader.h"

@interface MakeReviewVC ()
{
    UIImage *thumb;
    UIImagePickerController *pickerUpload;
    NSDictionary *dataRestaurant;
    UITapGestureRecognizer *tapGestureKeyboard;
}
@end

@implementation MakeReviewVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        thumb = nil;
    }
    return self;
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
    
    tapGestureKeyboard = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTapHideKeyboard:)];
    tapGestureKeyboard.numberOfTapsRequired = 1;
    
    viewHeader = [[ViewHeader alloc] initWithFrame:CGRectMake(0, 0, 320, 46)];
    [self.view addSubview:viewHeader];
    
    [viewHeader setVC:self];
    [viewHeader setTitlePage:[NSString stringWithFormat:@"Calificar %@", [dataRestaurant valueForKey:@"name"]]];
    
    NSString *imgName = @"bg";
    
    if([NDevice screenType] == NDeviceScreenIPHONE5)
    {
        imgName = @"bg-568h";
    }
    
    self.bg.image = [UIImage imageNamed:imgName];
    self.bg.frame = CGRectMake(0, 0, [NDevice getWidth], [NDevice getHeight]);
    
    
    
    
    CGRect frameScroll = self.scroll.frame;
    frameScroll.origin.y = 46;
    frameScroll.size.height = self.view.frame.size.height - 46;
    self.scroll.frame = frameScroll;
    [self.view addSubview:self.scroll];
    self.scroll.backgroundColor = [UIColor clearColor];
    [self.scroll setContentSize:CGSizeMake(1, 576)];
    
    UIImage *maximumPrecio = [UIImage imageNamed:@"slider_maximum_precio"];
    UIImage *maximumCalidad = [UIImage imageNamed:@"slider_maximum_calidad"];
    UIImage *maximumCantidad = [UIImage imageNamed:@"slider_maximum_cantidad"];

    [self.sliderPrecio initWithBackground:maximumPrecio];
    self.sliderPrecio.delegate = self;
    [self.sliderCalidad initWithBackground:maximumCalidad];
    self.sliderCalidad.delegate = self;
    [self.sliderCantidad initWithBackground:maximumCantidad];
    self.sliderCantidad.delegate = self;
    
    self.title_calidad.font = [UIFont rw_FontBoldWithSize:14];
    self.title_cantidad.font = [UIFont rw_FontBoldWithSize:14];
    self.title_precio.font = [UIFont rw_FontBoldWithSize:14];
    
    self.txt_comment.layer.borderColor = [UIColor colorFromHexString:@"#074f7b"].CGColor;
    self.txt_comment.layer.borderWidth = 0.5;
    self.txt_comment.layer.cornerRadius = 4;
    self.txt_comment.textColor = [UIColor colorFromHexString:@"#51788f"];
    self.txt_comment.font = [UIFont rw_FontBoldWithSize:12];
    
    [self.photo_review setContentMode:UIViewContentModeScaleAspectFill];
    self.photo_review.layer.borderColor = [[UIColor colorFromHexString:@"#6a97b3"] CGColor];
    self.photo_review.layer.borderWidth = 0.5f;
    self.photo_review.layer.cornerRadius = 3;
    [self.photo_review setOpaque:TRUE];
    self.photo_review.layer.masksToBounds = YES;
    
    CGRect frameViewPopupPhoto = self.viewPopupSelectPhoto.frame;
    frameViewPopupPhoto.size.height = self.view.frame.size.height;
    self.viewPopupSelectPhoto.frame = frameViewPopupPhoto;
    
    CGRect frameContentPopupPhoto = self.viewContentSelectPhoto.frame;
    frameContentPopupPhoto.origin.y = (self.viewPopupSelectPhoto.frame.size.height - frameContentPopupPhoto.size.height)/2;
    self.viewContentSelectPhoto.frame = frameContentPopupPhoto;
    
    [self.view addSubview:self.viewPopupSelectPhoto];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTapHidePopup)];
    tapGesture.numberOfTapsRequired = 1;
    [self.viewPopupSelectPhoto addGestureRecognizer:tapGesture];
    [self.viewPopupSelectPhoto setHidden:YES];
    
    [self checkStatusThumb];
    
    NSLog(@" DT %@", dataRestaurant);
    if([[dataRestaurant valueForKey:@"is_review"] boolValue])
    {
        [self.sliderCalidad setEnabled:NO];
        [self.sliderCantidad setEnabled:NO];
        [self.sliderPrecio setEnabled:NO];
    }
    else
    {
        [self.sliderCalidad setEnabled:YES];
        [self.sliderCantidad setEnabled:YES];
        [self.sliderPrecio setEnabled:YES];
    }
    
    self.viewPopup.frame = CGRectMake(0, 0, 320, self.view.frame.size.height);
    self.viewPopupContent.frame = CGRectMake(0, (self.viewPopup.frame.size.height - self.viewPopupContent.frame.size.height)/2, self.viewPopupContent.frame.size.width, self.viewPopupContent.frame.size.height);
    [self.view addSubview:self.viewPopup];
    
    [self.viewPopup setHidden:YES];
}

- (void) addRestaurant:(NSDictionary *)dt
{
    dataRestaurant = dt;
}

- (void) onTapHidePopup
{
    [self.viewPopupSelectPhoto setHidden:YES];
}


- (void) onChangeValue:(SliderReview *)sender
{
    
}

- (void) viewWillDisappear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    
    [super viewWillDisappear:animated];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (IBAction)onShowGallery:(UIButton *)sender
{
    [self onShowLibarary];
}

- (IBAction)onShowCamera:(UIButton *)sender
{
    [self onShowCamera];
}

- (IBAction)onChoosePhoto:(UIButton *)sender
{
    [self.viewPopupSelectPhoto setHidden:NO];
}

- (IBAction)onSubmit:(UIButton *)sender
{
    [self showLoading];
    
    NSDictionary *user = [GlobalData shareGlobalData].userInfo;
    dispatch_async(kBgQueue, ^{
        NSMutableDictionary * params = [[NSMutableDictionary alloc] init];
        [params setObject:self.txt_comment.text forKey:@"comment"];
        if(![[dataRestaurant valueForKey:@"is_review"] boolValue])
        {
            [params setObject:[NSString stringWithFormat:@"%d", [self.sliderPrecio getValue]] forKey:@"precio"];
            [params setObject:[NSString stringWithFormat:@"%d", [self.sliderCalidad getValue]] forKey:@"calidad"];
            [params setObject:[NSString stringWithFormat:@"%d", [self.sliderCantidad getValue]] forKey:@"cantidad"];
        }
        [params setObject:[NSString stringWithFormat:@"%@", [dataRestaurant valueForKey:@"id"]] forKey:@"id"];
        [params setObject:[user valueForKey:@"email"] forKey:@"email"];
        [params setObject:[user valueForKey:@"key"] forKey:@"key"];
        NSLog(@"params %@", params);
        NSDictionary *response = nil;
        
        if(thumb != nil)
        {
            NSData *data = UIImageJPEGRepresentation(thumb, 1.0f);
            response = [NLoader jsonWithURL:LINK_ADD_MAKE_REVIEW params:params fileData:data];
        }
        else
        {
            response = [NLoader jsonDataOfURL:LINK_ADD_MAKE_REVIEW params:params];
        }
        
        [self performSelectorOnMainThread:@selector(postDataComplete:) withObject:response waitUntilDone:NO];
    });
}

- (void) postDataComplete:(NSDictionary *)result
{
    [popupLoading close];
    if(result == nil)
    {
        [[GlobalData shareGlobalData] showAlert:@"Network error. Please check your connectivity." Title:@"Review error!"];
    }
    else
    {
        id status = [result objectForKey:@"status"];
        
        if(status && [status boolValue])
        {
//            [[GlobalData shareGlobalData] showAlert:[result objectForKey:@"message"] Title:@"Calificar!"];
            [self showPopup];
        }
        else
        {
            [[GlobalData shareGlobalData] showAlert:[result objectForKey:@"message"] Title:@"Calificar error!"];
        }
    }
}

- (IBAction)onCancel:(UIButton *)sender
{
    [self.photo_review setImage:nil];
    thumb = nil;
    [self checkStatusThumb];
}

- (IBAction)dismissPopup:(id)sender {
    [self hidePopup];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void) checkStatusThumb
{
    CGRect frameBtnSubmit = self.btn_submit.frame;
    int h = 0;
    
    if(thumb == nil)
    {
        [self.viewPhoto setHidden:YES];
        [self.btn_take_photo setHidden:NO];
        frameBtnSubmit.origin.y = 511;
        h = 576;
    }
    else
    {
        [self.viewPhoto setHidden:NO];
        [self.btn_take_photo setHidden:YES];
        frameBtnSubmit.origin.y = 610;
        h = 687;
    }
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    [UIView setAnimationDelay:0];
    
    self.btn_submit.frame = frameBtnSubmit;
    
    [UIView commitAnimations];
    
    [self.scroll setContentSize:CGSizeMake(1, h)];
}

#pragma mark - Show Library
- (void) onShowLibarary
{
    pickerUpload = [[UIImagePickerController alloc] init];
    [pickerUpload setDelegate:self];
    [pickerUpload setAllowsEditing:NO];
    [pickerUpload setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    [self presentViewController:pickerUpload animated:YES completion:nil];
}

#pragma mark - Show Camera
- (void)onShowCamera
{
    pickerUpload = [[UIImagePickerController alloc] init];
    [pickerUpload setDelegate:self];
    [pickerUpload setAllowsEditing:NO];
    
    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        [pickerUpload setSourceType:UIImagePickerControllerSourceTypeCamera];
    }
    else if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary])
    {
        [pickerUpload setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    }
    
    [self presentViewController:pickerUpload animated:YES completion:nil];
}

#pragma mark - UIImagePickerControllerDelegate


- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    [self dismissViewControllerAnimated:YES completion:nil];
    
    thumb = [info objectForKey:UIImagePickerControllerOriginalImage];
    
    [self.photo_review setImage:thumb];
    
    [self onTapHidePopup];
    
    [self checkStatusThumb];
    
}

- (void) onTapHideKeyboard:(id) sender
{
    [self.txt_comment resignFirstResponder];
}

- (void) showLoading
{
    popupLoading = [[CustomIOS7AlertView alloc] init];
    
    [popupLoading setContainerView:[[GlobalData shareGlobalData] createViewLoading]];
    
    [popupLoading setButtonTitles:nil];
    [popupLoading setDelegate:self];
    
    [popupLoading setUseMotionEffects:true];
    [popupLoading show];
    
}
- (void)customIOS7dialogButtonTouchUpInside: (CustomIOS7AlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    [alertView close];
}

-(void) keyboardWillShow:(NSNotification *)note
{
    [self.view addGestureRecognizer:tapGestureKeyboard];
}

-(void) keyboardWillHide:(NSNotification *)note
{
    [self.view removeGestureRecognizer:tapGestureKeyboard];
}

#pragma mark - SHOW AND HIDE POPUP
- (void) showPopup
{
    
    [self.viewPopup setHidden:NO];
    self.viewPopupContent.alpha = 0;
    CGRect frame = self.viewPopupContent.frame;
    frame.origin.y = (self.viewPopup.frame.size.height - self.viewPopupContent.frame.size.height)/2 + 50;
    self.viewPopupContent.frame = frame;
    frame.origin.y = (self.viewPopup.frame.size.height - self.viewPopupContent.frame.size.height)/2;
    
    [UIView animateWithDuration:0.3
                          delay:0.0
                        options:UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         self.viewPopupContent.frame = frame;
                         self.viewPopupContent.alpha = 1;
                     } completion:^(BOOL finished) {
                     }];
}
- (void) hidePopup
{
    CGRect frame = self.viewPopupContent.frame;
    frame.origin.y = (self.viewPopup.frame.size.height - self.viewPopupContent.frame.size.height)/2 + 50;
    
    [UIView animateWithDuration:0.2
                          delay:0.0
                        options:UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         self.viewPopupContent.frame = frame;
                         self.viewPopupContent.alpha = 0;
                     } completion:^(BOOL finished) {
                         [self.viewPopup setHidden:YES];
                     }];
}
@end
