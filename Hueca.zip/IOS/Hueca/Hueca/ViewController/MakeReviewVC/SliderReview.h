//
//  SliderReview.h
//  Hueca
//
//  Created by NhiepPhong on 5/5/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SliderReviewDelegate;

@interface SliderReview : UISlider

@property id<SliderReviewDelegate>delegate;

- (void) initWithBackground:(UIImage *)img;
- (int) getValue;

@end

@protocol SliderReviewDelegate <NSObject>

- (void) onChangeValue:(SliderReview *)sender;
@end
