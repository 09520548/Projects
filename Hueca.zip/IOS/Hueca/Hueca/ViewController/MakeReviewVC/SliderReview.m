//
//  SliderReview.m
//  Hueca
//
//  Created by NhiepPhong on 5/5/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "SliderReview.h"

@implementation SliderReview

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        
    }
    return self;
}

- (void) initWithBackground:(UIImage *)img
{
    UIImage *thumb = [UIImage imageNamed:@"slider_seeker_bg"];
    UIImage *tmp = [UIImage imageNamed:@"slider_clear_color"];
    UIImage *empty = [UIImage imageNamed:@"slider_empty"];
    
    [self setThumbImage:thumb forState:UIControlStateNormal];
    [self setThumbImage:thumb forState:UIControlStateHighlighted];
    
    [self setMaximumTrackImage:empty forState:UIControlStateNormal];
    [self setMaximumTrackImage:empty forState:UIControlStateHighlighted];
    
    [self setMinimumTrackImage:tmp forState:UIControlStateNormal];
    [self setMinimumTrackImage:tmp forState:UIControlStateHighlighted];
    
    [self setBackgroundColor:[UIColor colorWithPatternImage:img]];
    
    [self setMinimumValue:0.0f];
    [self setMaximumValue:100.0f];
    
    [self addTarget:self
                  action:@selector(sliderDidEndSliding:)
        forControlEvents:(UIControlEventTouchUpInside | UIControlEventTouchUpOutside)];
    [self setValue:33.0f];
}

- (void)sliderDidEndSliding:(NSNotification *)notification
{
    if(self.value < 33 - (33/2))
    {
        [self setValue:0 animated:YES];
    }
    else if(self.value > 33 - (33/2) && self.value < 65 - (65-33)/2)
    {
        [self setValue:33 animated:YES];
    }
    else if(self.value >= 65 - (65-33)/2 && self.value < 100 - (100-65)/2)
    {
        [self setValue:65 animated:YES];
    }
    else
    {
        [self setValue:100 animated:YES];
    }
    
    [self.delegate onChangeValue:self];
}

- (int) getValue
{
    if(self.value < 33 - (33/2))
    {
        return 1;
    }
    else if(self.value > 33 - (33/2) && self.value < 65 - (65-33)/2)
    {
        return 2;
    }
    else if(self.value >= 65 - (65-33)/2 && self.value < 100 - (100-65)/2)
    {
        return 3;
    }
    else
    {
        return 4;
    }
}

@end
