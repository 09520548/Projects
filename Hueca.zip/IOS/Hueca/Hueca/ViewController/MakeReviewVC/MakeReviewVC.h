//
//  MakeReviewVC.h
//  Hueca
//
//  Created by NhiepPhong on 5/5/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewHeader.h"
#import "SliderReview.h"
#import "CustomIOS7AlertView.h"

@interface MakeReviewVC : UIViewController<SliderReviewDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, CustomIOS7AlertViewDelegate>
{
    ViewHeader *viewHeader;
    CustomIOS7AlertView *popupLoading;
}

@property (weak, nonatomic) IBOutlet UIImageView *bg;
@property (weak, nonatomic) IBOutlet SliderReview *sliderPrecio;
@property (weak, nonatomic) IBOutlet SliderReview *sliderCantidad;
@property (weak, nonatomic) IBOutlet SliderReview *sliderCalidad;
@property (strong, nonatomic) IBOutlet UIScrollView *scroll;
@property (weak, nonatomic) IBOutlet UILabel *title_precio;
@property (weak, nonatomic) IBOutlet UILabel *title_calidad;
@property (weak, nonatomic) IBOutlet UILabel *title_cantidad;
@property (weak, nonatomic) IBOutlet UITextView *txt_comment;
@property (weak, nonatomic) IBOutlet UIButton *btn_take_photo;
@property (weak, nonatomic) IBOutlet UIButton *btn_submit;
@property (weak, nonatomic) IBOutlet UIView *viewPhoto;
@property (weak, nonatomic) IBOutlet UIImageView *photo_review;
@property (strong, nonatomic) IBOutlet UIView *viewPopupSelectPhoto;
@property (weak, nonatomic) IBOutlet UIView *viewContentSelectPhoto;
@property (strong, nonatomic) IBOutlet UIView *viewPopup;
@property (weak, nonatomic) IBOutlet UIView *viewPopupContent;

- (IBAction)onShowGallery:(UIButton *)sender;
- (IBAction)onShowCamera:(UIButton *)sender;

- (void) addRestaurant:(NSDictionary *)dt;

- (IBAction)onChoosePhoto:(UIButton *)sender;
- (IBAction)onSubmit:(UIButton *)sender;
- (IBAction)onCancel:(UIButton *)sender;
- (IBAction)dismissPopup:(id)sender;

@end
