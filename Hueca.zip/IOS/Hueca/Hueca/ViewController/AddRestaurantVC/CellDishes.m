//
//  CellDishes.m
//  Hueca
//
//  Created by NhiepPhong on 5/2/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "CellDishes.h"

@implementation CellDishes

static UIImage* Cell_bg = nil;
static UIImage* Cell_bgHover = nil;

- (void)awakeFromNib
{
    
}

- (void) setData:(NSDictionary *)dt
{
    self.title.font = [UIFont rw_FontRegularWithSize:14];
    self.title.text = [dt valueForKey:@"name"];
    
    if(Cell_bg == nil)
    {
        Cell_bg = [UIImage imageNamed:@"dishes_cell_bg"];
    }
    if(Cell_bgHover == nil)
    {
        Cell_bgHover = [UIImage imageNamed:@"dishes_cell_bg_active"];
    }
    [self setBackgroundView:[[UIImageView alloc] initWithImage:Cell_bg]];
    [self setSelectedBackgroundView:[[UIImageView alloc] initWithImage:Cell_bgHover]];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

- (float) getHeight
{
    return 33.0f;
}
@end
