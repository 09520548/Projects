//
//  AddRestaurantVC.h
//  Hueca
//
//  Created by NhiepPhong on 5/7/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewHeader.h"
#import "NFormat.h"
#import "CustomIOS7AlertView.h"
#import "CategorySelectBox.h"
#import "CellDishes.h"
#import <Social/Social.h>
#import <CoreLocation/CoreLocation.h>
#import "MakeReviewVC.h"

@interface AddRestaurantVC : UIViewController<UITextViewDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, CustomIOS7AlertViewDelegate, CategorySelectBoxDelegate, UITableViewDataSource, UITableViewDelegate, CLLocationManagerDelegate>
{
    ViewHeader *viewHeader;
    UIImage *thumb;
    UIImagePickerController *pickerUpload;
    UIDatePicker *pickerOpen;
    UIDatePicker *pickerClose;
    UIToolbar *inputAccessoryView;
    CustomIOS7AlertView *popupLoading;
    NSDictionary *dtCitySelect;
    NSDictionary *dtPlaceSelect;
    NSMutableArray *dtDishesSelect;
    NSDictionary *restaurantSelect;
}

@property (weak, nonatomic) IBOutlet UIImageView *bg;
@property (strong, nonatomic) IBOutlet UIScrollView *scroll;
@property (weak, nonatomic) IBOutlet UIButton *btn_take_photo;
@property (weak, nonatomic) IBOutlet UIButton *btn_submit;
@property (weak, nonatomic) IBOutlet UIView *viewPhoto;
@property (weak, nonatomic) IBOutlet UIImageView *photo_review;
@property (strong, nonatomic) IBOutlet UIView *viewPopupSelectPhoto;
@property (weak, nonatomic) IBOutlet UIView *viewContentSelectPhoto;
@property (weak, nonatomic) IBOutlet UITextField *txt_name;
@property (weak, nonatomic) IBOutlet UITextField *txt_time_open;
@property (weak, nonatomic) IBOutlet UITextField *txt_time_close;
@property (weak, nonatomic) IBOutlet UITextView *txt_content;
@property (weak, nonatomic) IBOutlet UITextField *txt_temporal;
@property (weak, nonatomic) IBOutlet UISwitch *switch_temporal;
@property (weak, nonatomic) IBOutlet UIButton *btnCity;
@property (weak, nonatomic) IBOutlet UITableView *tableDishes;
@property (weak, nonatomic) IBOutlet UIView *viewTemporal;
@property (weak, nonatomic) IBOutlet UITextField *txt_date_temporal;
@property (weak, nonatomic) IBOutlet UIButton *btnPlace;

@property (weak, nonatomic) IBOutlet CategorySelectBox *viewSelectBox;
@property (weak, nonatomic) IBOutlet CategorySelectBox *viewSelectBoxPlace;
@property (strong, nonatomic) IBOutlet UIView *viewPopup;
@property (weak, nonatomic) IBOutlet UIView *viewPopupContent;

- (IBAction)onShowGallery:(UIButton *)sender;
- (IBAction)onShowCamera:(UIButton *)sender;
- (IBAction)onChoosePhoto:(UIButton *)sender;
- (IBAction)onSubmit:(UIButton *)sender;
- (IBAction)onCancel:(UIButton *)sender;

- (IBAction)onOpenSelectCate:(UIButton *)sender;
- (IBAction)onOpenSelectPlace:(UIButton *)sender;
- (IBAction)onChangeTemporal:(UISwitch *)sender;

- (IBAction)onTouchPopup:(id)sender;
@end
