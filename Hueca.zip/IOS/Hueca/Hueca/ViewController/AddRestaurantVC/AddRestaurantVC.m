//
//  AddRestaurantVC.m
//  Hueca
//
//  Created by NhiepPhong on 5/7/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "AddRestaurantVC.h"
#import "NDevice.h"
#import "GlobalData.h"
#import "NPConstants.h"
#import "NLoader.h"

@interface AddRestaurantVC ()
{
    UITapGestureRecognizer *tapGestureKeyboard;
    BOOL isShowCate;
    CLLocationManager *locationManager;
    SLComposeViewController *slcComposeViewShareFB;
    BOOL pushNotification;
    NSString *textShare;
}
@end

@implementation AddRestaurantVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        dtCitySelect = nil;
        dtDishesSelect = [NSMutableArray new];
    }
    return self;
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    restaurantSelect = nil;
    
    tapGestureKeyboard = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTapHideKeyboard:)];
    tapGestureKeyboard.numberOfTapsRequired = 1;
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
    
    viewHeader = [[ViewHeader alloc] initWithFrame:CGRectMake(0, 0, 320, 46)];
    [self.view addSubview:viewHeader];
    
    [viewHeader setVC:self];
    [viewHeader setTitlePage:@"Agregar Hueca"];
    
    NSString *imgName = @"bg";
    
    if([NDevice screenType] == NDeviceScreenIPHONE5)
    {
        imgName = @"bg-568h";
    }
    
    slcComposeViewShareFB = nil;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(sharingStatusFB) name:@"share_fb_status" object:nil];
    
    self.bg.image = [UIImage imageNamed:imgName];
    self.bg.frame = CGRectMake(0, 0, [NDevice getWidth], [NDevice getHeight]);
    
    CGRect frameScroll = self.scroll.frame;
    frameScroll.origin.y = 46;
    frameScroll.size.height = self.view.frame.size.height - 46;
    self.scroll.frame = frameScroll;
    [self.view addSubview:self.scroll];
    self.scroll.backgroundColor = [UIColor clearColor];
    [self.scroll setContentSize:CGSizeMake(1, 608)];
    
    [self setStyleInput:self.txt_name];
    
    [self setStyleInput:self.txt_time_close];
    
    [self setStyleInput:self.txt_time_open];

    [self setStyleInput:self.txt_temporal];
    
    pickerClose = [[UIDatePicker alloc] init];
    [pickerClose setDate:[NFormat dateFromString:@"01:01" format:@"HH:mm"]];
    [pickerClose setDatePickerMode:UIDatePickerModeTime];
    [pickerClose addTarget:self action:@selector(tfCloseChanged) forControlEvents:UIControlEventValueChanged];
    [self.txt_time_close setInputView:pickerClose];
    [self.txt_time_close setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [self.txt_time_close setKeyboardType:UIKeyboardTypeNumbersAndPunctuation];
    
    pickerOpen = [[UIDatePicker alloc] init];
    [pickerOpen setDate:[NFormat dateFromString:@"01:01" format:@"HH:mm"]];
    [pickerOpen setDatePickerMode:UIDatePickerModeTime];
    [pickerOpen addTarget:self action:@selector(tfOpenChanged) forControlEvents:UIControlEventValueChanged];
    [self.txt_time_open setInputView:pickerOpen];
    [self.txt_time_open setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [self.txt_time_open setKeyboardType:UIKeyboardTypeNumbersAndPunctuation];

    [self setStyleButton:self.btnCity];
    
    [self setStyleButton:self.btnPlace];
    
    self.txt_content.layer.borderColor = [UIColor colorFromHexString:@"#074f7b"].CGColor;
    self.txt_content.backgroundColor = [UIColor colorWithRed:237/255.0f green:248/255.0f blue:255/255 alpha:0.8];
    self.txt_content.layer.borderWidth = 0.5;
    self.txt_content.layer.cornerRadius = 4;
    self.txt_content.textColor = [UIColor colorFromHexString:@"#51788f"];
    self.txt_content.font = [UIFont rw_FontBoldWithSize:12];
    
    [self.photo_review setContentMode:UIViewContentModeScaleAspectFill];
    self.photo_review.layer.borderColor = [[UIColor colorFromHexString:@"#6a97b3"] CGColor];
    self.photo_review.layer.borderWidth = 0.5f;
    self.photo_review.layer.cornerRadius = 3;
    [self.photo_review setOpaque:TRUE];
    self.photo_review.layer.masksToBounds = YES;
    
    CGRect frameViewPopupPhoto = self.viewPopupSelectPhoto.frame;
    frameViewPopupPhoto.size.height = self.view.frame.size.height;
    self.viewPopupSelectPhoto.frame = frameViewPopupPhoto;
    
    CGRect frameContentPopupPhoto = self.viewContentSelectPhoto.frame;
    frameContentPopupPhoto.origin.y = (self.viewPopupSelectPhoto.frame.size.height - frameContentPopupPhoto.size.height)/2;
    self.viewContentSelectPhoto.frame = frameContentPopupPhoto;
    
    [self.view addSubview:self.viewPopupSelectPhoto];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTapHidePopup)];
    tapGesture.numberOfTapsRequired = 1;
    [self.viewPopupSelectPhoto addGestureRecognizer:tapGesture];
    [self.viewPopupSelectPhoto setHidden:YES];
    
    [self.viewSelectBox initView:self.view.frame];
    [self.view addSubview:self.viewSelectBox];
    
    [self.viewSelectBoxPlace initView:self.view.frame];
    [self.viewSelectBoxPlace addDataList:[GlobalData shareGlobalData].dataPlace];
    self.viewSelectBoxPlace.titlePage.text = @"Place";
    [self.view addSubview:self.viewSelectBoxPlace];
    
    self.tableDishes.backgroundColor = [UIColor colorFromHexString:@"#c2e0f3"];
    self.tableDishes.layer.cornerRadius = 3;
    self.tableDishes.layer.masksToBounds = TRUE;
    
    [self.tableDishes reloadData];
    
    [self onChangeTemporal:nil];
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.distanceFilter = kCLDistanceFilterNone; // whenever we move
    locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters; // 100 m
    locationManager.delegate = self;
    [locationManager startUpdatingLocation];
    
    self.viewPopup.frame = CGRectMake(0, 0, 320, self.view.frame.size.height);
    self.viewPopupContent.frame = CGRectMake(0, (self.viewPopup.frame.size.height - self.viewPopupContent.frame.size.height)/2, self.viewPopupContent.frame.size.width, self.viewPopupContent.frame.size.height);
    [self.view addSubview:self.viewPopup];
    
    [self.viewPopup setHidden:YES];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    [locationManager stopUpdatingLocation];
}

-(void) setStyleButton:(UIButton *)btn
{
    btn.titleLabel.font = [UIFont rw_FontBoldWithSize:12];
    btn.backgroundColor = [UIColor colorWithRed:237/255.0f green:248/255.0f blue:255/255 alpha:0.8];
    btn.layer.borderColor = [UIColor colorFromHexString:@"#074f7b"].CGColor;
    btn.layer.borderWidth = 0.5;
    btn.layer.cornerRadius = 2;
}

-(void) setStyleInput:(UITextField *)lb
{
    lb.font = [UIFont rw_FontBoldWithSize:12];
    lb.backgroundColor = [UIColor colorWithRed:237/255.0f green:248/255.0f blue:255/255 alpha:0.8];
    lb.layer.borderColor = [UIColor colorFromHexString:@"#074f7b"].CGColor;
    lb.layer.borderWidth = 0.5;
    lb.layer.cornerRadius = 2;
    UIView *fieldHeaderOpen = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 10)];
    [lb setLeftViewMode:UITextFieldViewModeAlways];
    [lb setLeftView:fieldHeaderOpen];
}

- (void) viewWillDisappear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    
    [super viewWillDisappear:animated];
}

-(void) keyboardWillShow:(NSNotification *)notif
{
    [self addGestureKeyboard];
    
    [self onChangeTemporal:nil];
    
    NSDictionary* info = [notif userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    CGRect frameBtnSubmit = self.btn_submit.frame;
    int h = frameBtnSubmit.origin.y + frameBtnSubmit.size.height + 20;
    
    h = h + kbSize.height;
    
    [self.scroll setContentSize:CGSizeMake(1, h)];
}

-(void) keyboardWillHide:(NSNotification *)notif
{
    [self removeGestureKeyboard];
    
    [self onChangeTemporal:nil];
}

- (void) addGestureKeyboard
{
    [self.view addGestureRecognizer:tapGestureKeyboard];
}

- (void) removeGestureKeyboard
{
    [self.view removeGestureRecognizer:tapGestureKeyboard];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void) onTapHidePopup
{
    [self.viewPopupSelectPhoto setHidden:YES];
}

- (IBAction)onShowGallery:(UIButton *)sender
{
    [self onShowLibarary];
}

- (IBAction)onShowCamera:(UIButton *)sender
{
    [self onShowCamera];
}

- (IBAction)onChoosePhoto:(UIButton *)sender
{
    [self.viewPopupSelectPhoto setHidden:NO];
}

- (IBAction)onSubmit:(UIButton *)sender
{
    NSMutableString *listIDDishes = [NSMutableString stringWithString:@""];
    if(dtDishesSelect.count > 0)
    {
        for(int i = 0; i < dtDishesSelect.count; i++)
        {
            NSDictionary *dt = [dtDishesSelect objectAtIndex:i];
            if(i < dtDishesSelect.count -1)
            {
                [listIDDishes appendString:[NSString stringWithFormat:@"%@,", [dt valueForKey:@"id"]]];
            }
            else
            {
                [listIDDishes appendString:[NSString stringWithFormat:@"%@", [dt valueForKey:@"id"]]];
            }
        }
    }
    if([self.txt_name.text isEqualToString:@""])
    {
        [[GlobalData shareGlobalData] showAlert:@"Please Enter Name" Title:@"Add Restaurant"];
    }
    else if([self.txt_time_open.text isEqualToString:@""])
    {
        [[GlobalData shareGlobalData] showAlert:@"Please Enter Time Open" Title:@"Add Restaurant"];
    }
    else if([self.txt_time_close.text isEqualToString:@""])
    {
        [[GlobalData shareGlobalData] showAlert:@"Please Enter Time Close" Title:@"Add Restaurant"];
    }
    else if([self.txt_content.text isEqualToString:@""])
    {
        [[GlobalData shareGlobalData] showAlert:@"Please Enter Content" Title:@"Add Restaurant"];
    }
    else if(dtCitySelect == nil)
    {
        [[GlobalData shareGlobalData] showAlert:@"Please Enter City" Title:@"Add Restaurant"];
    }
    else if(dtPlaceSelect == nil)
    {
        [[GlobalData shareGlobalData] showAlert:@"Please Enter Place" Title:@"Add Restaurant"];
    }
    else
    {
        [self onTapHideKeyboard:nil];
        
        [self showLoading];
    
        NSDictionary *user = [GlobalData shareGlobalData].userInfo;
        dispatch_async(kBgQueue, ^{
            NSMutableDictionary * params = [[NSMutableDictionary alloc] init];
            [params setObject:self.txt_name.text forKey:@"name"];
            [params setObject:self.txt_time_open.text forKey:@"time_open"];
            [params setObject:self.txt_time_close.text forKey:@"time_close"];
            [params setObject:self.txt_content.text forKey:@"description"];
            [params setObject:[NSString stringWithFormat:@"%d", self.switch_temporal.isOn] forKey:@"temporal"];
            [params setObject:[NSString stringWithFormat:@"%@", [dtCitySelect valueForKeyPath:@"id"]] forKey:@"pid"];
            [params setObject:[NSString stringWithFormat:@"%@", [dtPlaceSelect valueForKeyPath:@"id"]] forKey:@"place_id"];
            [params setObject:listIDDishes forKey:@"dishes_id"];
            [params setObject:[user valueForKey:@"email"] forKey:@"email"];
            [params setObject:[user valueForKey:@"key"] forKey:@"key"];
            [params setObject:[NSString stringWithFormat:@"%@", self.txt_date_temporal.text] forKey:@"date_temporal"];
            [params setObject:[NSString stringWithFormat:@"%f",locationManager.location.coordinate.latitude] forKey:@"latitude"];
            [params setObject:[NSString stringWithFormat:@"%f",locationManager.location.coordinate.longitude] forKey:@"longitude"];
            
            NSDictionary *response = nil;
            
            if(thumb != nil)
            {
                NSData *data = UIImageJPEGRepresentation(thumb, 1.0f);
                response = [NLoader jsonWithURL:LINK_ADD_RESTAURANT params:params fileData:data];
            }
            else
            {
                response = [NLoader jsonDataOfURL:LINK_ADD_RESTAURANT params:params];
            }

            [self performSelectorOnMainThread:@selector(postDataComplete:) withObject:response waitUntilDone:NO];
        });
        
    }
}

- (void) postDataComplete:(NSDictionary *)result
{
    [popupLoading close];
    if(result == nil)
    {
        [[GlobalData shareGlobalData] showAlert:@"Network error. Please check your connectivity." Title:@"Add Restaurant!"];
    }
    else
    {
        id status = [result objectForKey:@"status"];
        
        if(status && [status boolValue])
        {
//            [[GlobalData shareGlobalData] showAlert:[result objectForKey:@"message"] Title:@"Add Restaurant!"];
            restaurantSelect = [result objectForKey:@"detailRest"];
            [self showPopup];
        
        }
        else
        {
            [[GlobalData shareGlobalData] showAlert:[result objectForKey:@"message"] Title:@"Add Restaurant!"];
        }
    }
}

- (IBAction)onCancel:(UIButton *)sender
{
    [self.photo_review setImage:nil];
    thumb = nil;
    [self checkStatusThumb];
}

- (void) checkStatusThumb
{
    CGRect frameBtnSubmit = self.btn_submit.frame;
    CGRect frameViewPhoto = self.viewPhoto.frame;
    CGRect frameTakePhoto = self.btn_take_photo.frame;
    int h = 0;
    int yy = self.viewTemporal.frame.origin.y + 10;
    if(self.switch_temporal.isOn)
    {
        yy = self.viewTemporal.frame.origin.y + self.viewTemporal.frame.size.height + 10;
    }
    
    frameViewPhoto.origin.y = yy;
    
    frameTakePhoto.origin.y = frameViewPhoto.origin.y;
    
    if(thumb == nil)
    {
        [self.viewPhoto setHidden:YES];
        [self.btn_take_photo setHidden:NO];
        frameBtnSubmit.origin.y = frameTakePhoto.origin.y + frameTakePhoto.size.height + 10;
    }
    else
    {
        [self.viewPhoto setHidden:NO];
        [self.btn_take_photo setHidden:YES];
    
        frameBtnSubmit.origin.y = frameViewPhoto.origin.y + frameViewPhoto.size.height + 10;
    }
    
    h = frameBtnSubmit.origin.y + frameBtnSubmit.size.height + 20;
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    [UIView setAnimationDelay:0];
    
    self.btn_submit.frame = frameBtnSubmit;
    self.viewPhoto.frame = frameViewPhoto;
    self.btn_take_photo.frame = frameTakePhoto;
    
    [UIView commitAnimations];
    
    [self.scroll setContentSize:CGSizeMake(1, h)];
}

#pragma mark - Show Library
- (void) onShowLibarary
{
    pickerUpload = [[UIImagePickerController alloc] init];
    [pickerUpload setDelegate:self];
    [pickerUpload setAllowsEditing:NO];
    [pickerUpload setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    [self presentViewController:pickerUpload animated:YES completion:nil];
}

#pragma mark - Show Camera
- (void)onShowCamera
{
    pickerUpload = [[UIImagePickerController alloc] init];
    [pickerUpload setDelegate:self];
    [pickerUpload setAllowsEditing:NO];
    
    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        [pickerUpload setSourceType:UIImagePickerControllerSourceTypeCamera];
    }
    else if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary])
    {
        [pickerUpload setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    }
    
    [self presentViewController:pickerUpload animated:YES completion:nil];
}

#pragma mark - UIImagePickerControllerDelegate


- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    [self dismissViewControllerAnimated:YES completion:nil];
    
    thumb = [info objectForKey:UIImagePickerControllerOriginalImage];
    
    [self.photo_review setImage:thumb];
    
    [self onTapHidePopup];
    
    [self checkStatusThumb];
    
}

- (void)tfOpenChanged
{
    UIDatePicker *picker = (UIDatePicker*)self.txt_time_open.inputView;
    
    [self.txt_time_open setText:[NFormat stringFromDate:picker.date format:@"HH:mm"]];
}

- (void)tfCloseChanged
{
    UIDatePicker *picker = (UIDatePicker*)self.txt_time_close.inputView;
    
    [self.txt_time_close setText:[NFormat stringFromDate:picker.date format:@"HH:mm"]];
}

- (UIView *)inputAccessoryView {
    if (!inputAccessoryView) {
        inputAccessoryView = [[UIToolbar alloc] init];
        inputAccessoryView.barStyle = UIBarStyleBlackTranslucent;
        inputAccessoryView.autoresizingMask = UIViewAutoresizingFlexibleHeight;
        [inputAccessoryView sizeToFit];
        CGRect frame = inputAccessoryView.frame;
        frame.size.height = 44.0f;
        inputAccessoryView.frame = frame;
        
        UIBarButtonItem *doneBtn =[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(onTapHideKeyboard:)];
        UIBarButtonItem *flexibleSpaceLeft = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        
        NSArray *array = [NSArray arrayWithObjects:flexibleSpaceLeft, doneBtn, nil];
        [inputAccessoryView setItems:array];
    }
    
    return inputAccessoryView;
}

- (void) onTapHideKeyboard:(id) sender
{
    [self.txt_name resignFirstResponder];
    [self.txt_content resignFirstResponder];
    [self.txt_temporal resignFirstResponder];
    [self.txt_time_close resignFirstResponder];
    [self.txt_time_open resignFirstResponder];
    [self.txt_date_temporal resignFirstResponder];
}

- (void) showLoading
{
    popupLoading = [[CustomIOS7AlertView alloc] init];
    
    [popupLoading setContainerView:[[GlobalData shareGlobalData] createViewLoading]];
    
    [popupLoading setButtonTitles:nil];
    [popupLoading setDelegate:self];
    
    [popupLoading setUseMotionEffects:true];
    [popupLoading show];
    
}
- (void)customIOS7dialogButtonTouchUpInside: (CustomIOS7AlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    [alertView close];
}

- (IBAction)onOpenSelectCate:(UIButton *)sender
{
    isShowCate = TRUE;
    [self.viewSelectBox show];
    [self removeGestureKeyboard];
}

- (IBAction)onOpenSelectPlace:(UIButton *)sender
{
    isShowCate = FALSE;
    [self.viewSelectBoxPlace show];
    [self removeGestureKeyboard];
}

- (IBAction)onChangeTemporal:(UISwitch *)sender
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    [UIView setAnimationDelay:0];
    
    if(self.switch_temporal.isOn)
    {
        [self.viewTemporal setHidden:NO];
        self.viewTemporal.alpha = 1;
    }
    else
    {
        [self.viewTemporal setHidden:YES];
        self.viewTemporal.alpha = 0;
    }
    
    [UIView commitAnimations];
    
    [self checkStatusThumb];
}

- (IBAction)onTouchPopup:(id)sender {
    [self hidePopup];
    if([sender tag] == 1)
    {
        NSLog(@"share facebook");
        [self onShareFB];
    }
    else if([sender tag] == 2)
    {
//        [self.navigationController popViewControllerAnimated:YES];
        MakeReviewVC *vc = [[MakeReviewVC alloc] initWithNibName:@"MakeReviewVC" bundle:nil];
        [vc addRestaurant:restaurantSelect];
        [self.navigationController pushViewController:vc animated:YES];
    }
}

- (void)onSelectCategory:(NSDictionary *)dt
{
    if(!isShowCate)
    {
        dtPlaceSelect = [[NSDictionary alloc] initWithDictionary:dt];
        [self.btnPlace setTitle:[dt valueForKeyPath:@"name"] forState:UIControlStateNormal];
    }
    else
    {
        dtCitySelect = [[NSDictionary alloc] initWithDictionary:dt];
        [self.btnCity setTitle:[dt valueForKeyPath:@"name"] forState:UIControlStateNormal];
    }
}

- (void) onClosePopupCategorySelect
{

}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [GlobalData shareGlobalData].dataDishes.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellDishes *cell = (CellDishes *)[tableView dequeueReusableCellWithIdentifier:@"CellDishes"];
    if(cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"CellDishes" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    [cell setData:[[GlobalData shareGlobalData].dataDishes objectAtIndex:indexPath.row]];
    return cell;
}

-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 33.0f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dt = [[GlobalData shareGlobalData].dataDishes objectAtIndex:indexPath.row];
    [dtDishesSelect addObject:dt];
}

- (void) tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dt = [[GlobalData shareGlobalData].dataDishes objectAtIndex:indexPath.row];
    [dtDishesSelect removeObject:dt];
}

- (void)tableView:(UITableView *)tableView didEndEditingRowAtIndexPath:(NSIndexPath *)indexPath
{
	[tableView reloadData];
}

- (BOOL)textViewShouldBeginEditing:(UITextView *)aTextView
{
    if(aTextView == self.txt_content)
    {
        NSLog(@"Has Focus");
        if([self.txt_content.text isEqualToString:@"Escribe una descripcion de este lugar y su comida!"])
        {
            self.txt_content.text = @"";
        }
    }
    return YES;
}

-(BOOL)textViewShouldEndEditing:(UITextView *)textView
{
    if(textView == self.txt_content)
    {
        if([self.txt_content.text isEqualToString:@""])
        {
            self.txt_content.text = @"Escribe una descripcion de este lugar y su comida!";
        }
    }
    return YES;
}

#pragma mark - SHOW POPUP
- (void) showPopup
{
    
    [self.viewPopup setHidden:NO];
    self.viewPopupContent.alpha = 0;
    CGRect frame = self.viewPopupContent.frame;
    frame.origin.y = (self.viewPopup.frame.size.height - self.viewPopupContent.frame.size.height)/2 + 50;
    self.viewPopupContent.frame = frame;
    frame.origin.y = (self.viewPopup.frame.size.height - self.viewPopupContent.frame.size.height)/2;
    
    [UIView animateWithDuration:0.3
                          delay:0.0
                        options:UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         self.viewPopupContent.frame = frame;
                         self.viewPopupContent.alpha = 1;
                     } completion:^(BOOL finished) {
                     }];
}
- (void) hidePopup
{
    CGRect frame = self.viewPopupContent.frame;
    frame.origin.y = (self.viewPopup.frame.size.height - self.viewPopupContent.frame.size.height)/2 + 50;
    
    [UIView animateWithDuration:0.2
                          delay:0.0
                        options:UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         self.viewPopupContent.frame = frame;
                         self.viewPopupContent.alpha = 0;
                     } completion:^(BOOL finished) {
                         [self.viewPopup setHidden:YES];
                     }];
}

#pragma mark - SHARE FACEBOOK
- (void) sharingStatusFB
{
    NSLog(@"sharingStatusFB");
    if(pushNotification)
    {
        pushNotification = FALSE;
        
//        [self postShare];
    }
}

- (void) onShareFB
{
    
    if([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook])
    {
        pushNotification = TRUE;
        slcComposeViewShareFB = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
        [slcComposeViewShareFB addImage:[UIImage imageNamed:@"logo.png"]];
        [slcComposeViewShareFB setTitle:@"Share Facebook"];
        [slcComposeViewShareFB addURL:[NSURL URLWithString:@"https://www.facebook.com"]];
        [slcComposeViewShareFB setInitialText:textShare];
        [slcComposeViewShareFB setCompletionHandler:^(SLComposeViewControllerResult result){
            [[NSNotificationCenter defaultCenter] postNotificationName:@"share_fb_status" object:nil userInfo:nil];
        }];
        
        [self presentViewController:slcComposeViewShareFB animated:YES completion:NULL];
    }
    else
    {
        [[GlobalData shareGlobalData] showAlert:@"Không thể kết nối được Facebook. Vui lòng thử lại sau." Title:@"Alert"];
    }
}
@end
