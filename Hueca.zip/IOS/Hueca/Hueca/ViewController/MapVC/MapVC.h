//
//  MapVC.h
//  Hueca
//
//  Created by NhiepPhong on 4/23/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "ViewHeader.h"

@interface MapVC : UIViewController<MKMapViewDelegate>
{
    ViewHeader *viewHeader;
}
@property (weak, nonatomic) IBOutlet UIImageView *bg;
@property (weak, nonatomic) IBOutlet MKMapView *map;
@property (weak, nonatomic) IBOutlet UIButton *btnHotSpots;
@property (weak, nonatomic) IBOutlet UIButton *btnCheckIn;
@property (weak, nonatomic) IBOutlet UIButton *btnFoodType;
@property (weak, nonatomic) IBOutlet UIButton *btnOpen;

- (IBAction)onChangeTab:(UIButton *)sender;

@end
