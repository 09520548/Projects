//
//  MapVC.m
//  Hueca
//
//  Created by NhiepPhong on 4/23/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "MapVC.h"
#import "NDevice.h"

@interface MapVC ()

@end

@implementation MapVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        
    }
    return self;
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    viewHeader = [[ViewHeader alloc] initWithFrame:CGRectMake(0, 0, 320, 46)];
    [self.view addSubview:viewHeader];
    
    NSString *imgName = @"bg";
    
    if([NDevice screenType] == NDeviceScreenIPHONE5)
    {
        imgName = @"bg-568h";
    }
    
    self.bg.image = [UIImage imageNamed:imgName];
    self.bg.frame = CGRectMake(0, 0, [NDevice getWidth], [NDevice getHeight]);
    
    self.map.frame = CGRectMake(0, 0, [NDevice getWidth], [NDevice getHeight]);
    
    [viewHeader setVC:self];
    [viewHeader setTitlePage:@"Restaurants"];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onShowMenu:(UIButton *)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)onChangeTab:(UIButton *)sender
{
    [self.btnHotSpots setSelected:NO];
    [self.btnCheckIn setSelected:NO];
    [self.btnFoodType setSelected:NO];
    [self.btnOpen setSelected:NO];
    
    [sender setSelected:YES];
}

@end
