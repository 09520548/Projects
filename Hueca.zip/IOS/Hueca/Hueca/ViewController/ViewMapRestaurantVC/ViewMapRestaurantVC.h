//
//  ViewMapRestaurantVC.h
//  Hueca
//
//  Created by NhiepPhong on 5/21/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>
#import "ViewHeader.h"

@interface ViewMapRestaurantVC : UIViewController<CLLocationManagerDelegate, MKMapViewDelegate>
{
    ViewHeader *viewHeader;
    NSDictionary *dataRestaurant;
    CLLocationManager *locationManager;
}
@property (weak, nonatomic) IBOutlet MKMapView *map;

- (void) setRestaurant:(NSDictionary *)data;

@end
