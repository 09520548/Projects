//
//  ViewMapRestaurantVC.m
//  Hueca
//
//  Created by NhiepPhong on 5/21/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "ViewMapRestaurantVC.h"
#import "CalloutView.h"
#import "AnnotationViewNearby.h"

@interface ViewMapRestaurantVC ()

@end

@implementation ViewMapRestaurantVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
    
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];

    viewHeader = [[ViewHeader alloc] initWithFrame:CGRectMake(0, 0, 320, 46)];
    [self.view addSubview:viewHeader];
    
    [viewHeader setVC:self];
    
    self.map.frame = CGRectMake(0, 0, 320, self.view.frame.size.height);
    self.map.delegate = self;
    self.map.mapType = MKMapTypeStandard;
    self.map.userTrackingMode = MKUserTrackingModeFollow;
    
    NSMutableArray *dataCouponInMap = [[NSMutableArray alloc] init];
    
    AnnotationViewNearby *item = [[AnnotationViewNearby alloc] init];
    [item addData:dataRestaurant];
    item.tag = 1;
    [dataCouponInMap addObject:item];
    
    [self.map removeAnnotations:self.map.annotations];
    [self.map addAnnotations:dataCouponInMap];
    
    CLLocation *location = [[CLLocation alloc] initWithLatitude:[[dataRestaurant valueForKey:@"latitude"] floatValue] longitude:[[dataRestaurant valueForKey:@"longitude"] floatValue]];
    MKCoordinateRegion viewRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, METERS_PER_MILE, METERS_PER_MILE);
    [self.map setRegion:viewRegion animated:YES];
    [self.map setShowsUserLocation:YES];
    
}

- (void) setRestaurant:(NSDictionary *)data
{
    dataRestaurant = data;
    NSLog(@"dataRestaurant %@", dataRestaurant);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - MKMapViewDelegate
- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation {
    if([annotation isKindOfClass:[MKUserLocation class]])
    {
        return nil;
    }
    NSString *identifier = [NSString stringWithFormat:@"viewMap"];
    MKAnnotationView * annotationView = (MKAnnotationView *)[self.map dequeueReusableAnnotationViewWithIdentifier:identifier];
    if (!annotationView)
    {
        annotationView = [[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:identifier];
        NSString *pinName = @"home-all-0";
        annotationView.image = [UIImage imageNamed:pinName];
    }
    else
    {
        annotationView.annotation = annotation;
    }
    annotationView.userInteractionEnabled = TRUE;
    
    return annotationView;
}

- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view {
    
    if([view.annotation isKindOfClass:[AnnotationViewNearby class]])
    {
        CalloutView *calloutView = [[CalloutView alloc] initWithFrame:CGRectMake(0.0, 0.0, 200, 40)];
        [calloutView show:dataRestaurant];
        calloutView.userInteractionEnabled = TRUE;
        calloutView.center = CGPointMake(CGRectGetWidth(view.bounds) / 2.0 - 6, -CGRectGetWidth(view.bounds));
        [view addSubview:calloutView];
    }
}

- (void)mapView:(MKMapView *)mapView didDeselectAnnotationView:(MKAnnotationView *)view {
    for (UIView *subview in view.subviews) {
		if (![subview isKindOfClass:[CalloutView class]]) {
			continue;
		}
		
		[subview removeFromSuperview];
	}
}

@end
