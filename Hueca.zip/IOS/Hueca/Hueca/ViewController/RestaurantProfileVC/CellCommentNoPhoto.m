//
//  CellCommentNoPhoto.m
//  Hueca
//
//  Created by Mobiz on 6/18/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "CellCommentNoPhoto.h"
#import "NLoader.h"

@implementation CellCommentNoPhoto

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void) addData:(NSDictionary *)dt
{
    UIImage *image = nil;
    image = [NLoader imageWithURL:[dt valueForKey:@"avatar"]
                  completeHandler:^(UIImage *img) { [self.thumb setImage:img]; }
                            cache:nil];
    if(image)
    {
        [self.thumb setImage:image];
    }
    self.txtContent.text = [dt valueForKey:@"content"];
    
    [self.thumb setContentMode:UIViewContentModeScaleAspectFill];
    self.thumb.layer.masksToBounds = TRUE;
    self.thumb.layer.borderColor = [[UIColor whiteColor] CGColor];
    self.thumb.layer.borderWidth = 1;
    self.txtContent.font = [UIFont rw_FontRegularWithSize:10];
    self.txtContent.numberOfLines = 0;
    
    CGSize maximumLabelSize = CGSizeMake(215, 200);
    
//    CGSize expectedLabelSize = [self.txtContent.text sizeWithFont:self.txtContent.font constrainedToSize:maximumLabelSize lineBreakMode:self.txtContent.lineBreakMode];
    
    CGSize expectedLabelSize = [self.txtContent.text sizeWithFont:self.txtContent.font constrainedToSize:maximumLabelSize lineBreakMode:NSLineBreakByWordWrapping];

    
    CGRect newFrame = self.txtContent.frame;
    newFrame.size.height = expectedLabelSize.height;
    self.txtContent.frame = newFrame;
    
    CGRect frameView = self.frame;
    frameView.size.height = 57;
    if(self.txtContent.frame.origin.y + self.txtContent.frame.size.height > 47)
    {
        frameView.size.height = self.txtContent.frame.origin.y + self.txtContent.frame.size.height + 25;
    }
    
//    self.frame = frameView;
    
    CGRect frameBg = self.frame;
    frameBg.size.height = frameBg.size.height - 10;
    frameBg.size.width = 300;
    frameBg.origin.x = 10;
    frameBg.origin.y = 0;
//    UIView *viewBg = [[UIView alloc] initWithFrame:self.frame];
//    UIView *viewBgContent = [[UIView alloc] initWithFrame:frameBg];
//    viewBgContent.backgroundColor = [UIColor colorFromHexString:@"#d7ebf7"];
//    viewBgContent.layer.borderWidth = 1;
//    viewBgContent.layer.borderColor = [[UIColor colorFromHexString:@"#096094"] CGColor];
//    [viewBg addSubview:viewBgContent];
    
//    self.backgroundColor = [UIColor colorFromHexString:@"0076c0"];
    
    UIView *viewBgHover = [[UIView alloc] initWithFrame:self.frame];
    UIView *viewBgHoverContent = [[UIView alloc] initWithFrame:self.frame];
    viewBgHoverContent.backgroundColor = [UIColor colorFromHexString:@"#baefaa"];
    viewBgHoverContent.layer.borderWidth = 1;
    viewBgHoverContent.layer.borderColor = [[UIColor colorFromHexString:@"#096094"] CGColor];
    [viewBgHover addSubview:viewBgHoverContent];
    
    
//    [self setBackgroundView:viewBg];
//    [self setSelectedBackgroundView:viewBgHover];
}

- (float) getHeight
{
    return self.frame.size.height;
}

@end
