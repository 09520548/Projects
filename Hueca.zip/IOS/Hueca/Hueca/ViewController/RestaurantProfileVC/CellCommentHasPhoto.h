//
//  CellCommentHasPhoto.h
//  Hueca
//
//  Created by Mobiz on 6/18/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellCommentHasPhoto : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgThumb;
@property (weak, nonatomic) IBOutlet UIView *viewComment;
@property (weak, nonatomic) IBOutlet UIImageView *avatar;
@property (weak, nonatomic) IBOutlet UILabel *contentComment;
@property (weak, nonatomic) IBOutlet UILabel *txtDate;

- (void) addData:(NSDictionary *)dt;
- (float) getHeight;

@end
