//
//  RestaurantProfileVC.m
//  Hueca
//
//  Created by NhiepPhong on 4/29/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "RestaurantProfileVC.h"
#import "NDevice.h"
#import "GlobalData.h"
#import "NPConstants.h"
#import "NLoader.h"
#import "MyProfileVC.h"
#import "ListCommentUserVC.h"
#import "ViewMapRestaurantVC.h"
#import "TagForItem.h"
#import "ListCommentVC.h"

@interface RestaurantProfileVC ()

@end

@implementation RestaurantProfileVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        dataPhoto = [NSMutableArray new];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    UINib *cellNib = [UINib nibWithNibName:@"PhotoRestaurantCell" bundle:nil];
    [self.table registerNib:cellNib forCellReuseIdentifier:@"PhotoRestaurantCell"];
    _stubCell = [cellNib instantiateWithOwner:nil options:nil][0];
    
    self.table.frame = CGRectMake(0, 0, 320, self.view.frame.size.height);
    
    self.table.tableHeaderView = self.viewHeaderTable;
    dataPhoto = [NSMutableArray new];
    [self.table reloadData];
    
    viewHeader = [[ViewHeader alloc] initWithFrame:CGRectMake(0, 0, 320, 46)];
    [self.view addSubview:viewHeader];
    
    NSString *imgName = @"bg";
    
    if([NDevice screenType] == NDeviceScreenIPHONE5)
    {
        imgName = @"bg-568h";
    }
    
    self.bg.image = [UIImage imageNamed:imgName];
    self.bg.frame = CGRectMake(0, 0, [NDevice getWidth], [NDevice getHeight]);
    
    [self.image setContentMode:UIViewContentModeScaleAspectFill];
    self.image.layer.masksToBounds = YES;
    [self.btnChangeMap setContentMode:UIViewContentModeScaleAspectFill];
    self.btnChangeMap.layer.masksToBounds = YES;
    
    [viewHeader setVC:self];
    
    self.count_favourite.font = [UIFont rw_FontBoldWithSize:12];
    self.txt_time_open.font = [UIFont rw_FontBoldWithSize:18];
    [self.txt_time_open setDrawOutline:YES];
    [self.txt_time_open setOutlineColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:0.5]];
    
    
    self.txt_place.font = [UIFont rw_FontBoldWithSize:18];
    [self.txt_place setDrawOutline:YES];
    [self.txt_place setOutlineColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:0.5]];
    
    self.priceCircle.font = [UIFont rw_FontBoldWithSize:27];
    self.priceTxt.font = [UIFont rw_FontRegularWithSize:8];
    
    self.priceCircle.progressLabelVCBlock = ^(KAProgressLabel *label, CGFloat progress) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [label setText:[NSString stringWithFormat:@"%.0f", (progress*10)]];
        });
    };
    
    [self.priceCircle setBorderWidth: 10.0];
    [self.priceCircle setColorTable: @{
                NSStringFromProgressLabelColorTableKey(ProgressLabelTrackColor):[UIColor whiteColor],
                NSStringFromProgressLabelColorTableKey(ProgressLabelProgressColor):[UIColor colorFromHexString:@"#61ed50"]
                                  }];
    
    
    self.quantityCircle.font = [UIFont rw_FontBoldWithSize:27];
    self.quantityTxt.font = [UIFont rw_FontRegularWithSize:8];
    
    self.quantityCircle.progressLabelVCBlock = ^(KAProgressLabel *label, CGFloat progress) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [label setText:[NSString stringWithFormat:@"%.0f", (progress*10)]];
        });
    };
    
    [self.quantityCircle setBorderWidth: 10.0];
    [self.quantityCircle setColorTable: @{
                                       NSStringFromProgressLabelColorTableKey(ProgressLabelTrackColor):[UIColor whiteColor],
                                       NSStringFromProgressLabelColorTableKey(ProgressLabelProgressColor):[UIColor colorFromHexString:@"#c6ef5e"]
                                       }];
    
    self.qualityCircle.font = [UIFont rw_FontBoldWithSize:27];
    self.qualityTxt.font = [UIFont rw_FontRegularWithSize:8];
    
    self.qualityCircle.progressLabelVCBlock = ^(KAProgressLabel *label, CGFloat progress) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [label setText:[NSString stringWithFormat:@"%.0f", (progress*10)]];
        });
    };
    
    [self.qualityCircle setBorderWidth: 10.0];
    [self.qualityCircle setColorTable: @{
                                         NSStringFromProgressLabelColorTableKey(ProgressLabelTrackColor):[UIColor whiteColor],
                                         NSStringFromProgressLabelColorTableKey(ProgressLabelProgressColor):[UIColor colorFromHexString:@"#edb64f"]
                                         }];
    
    self.labelDescription.font = [UIFont rw_FontBoldWithSize:12];
    self.txtDescription.font = [UIFont rw_FontRegularWithSize:12];
    self.txtTips.font = [UIFont rw_FontBoldWithSize:12];
    
    self.labelComment.font = [UIFont rw_FontBoldWithSize:12];
    
    self.avatarComment.layer.borderColor = [[UIColor whiteColor] CGColor];
    self.avatarComment.layer.borderWidth = 1;
    self.txtComment.font = [UIFont rw_FontBoldWithSize:11];
    
    [self initData];
    [self loadData];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void) setIdRestaurant:(int)id
{
    idRestaurant = id;
}

- (void) loadData
{
    [self showLoading];
    dispatch_async(kBgQueue, ^{
        NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
        [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"email"] forKey:@"email"];
        [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"key"] forKey:@"key"];
        [params setObject:[NSString stringWithFormat:@"%d", idRestaurant] forKey:@"id"];
        
        NSDictionary *response = [NLoader jsonDataOfURL:LINK_GET_DETAIL_RESTAURANT params:params];
        
        [self performSelectorOnMainThread:@selector(getRestaurantComplete:) withObject:response waitUntilDone:NO];
    });
}

- (void) getRestaurantComplete:(NSDictionary *)result
{
    [popupLoading close];
    if(result == nil)
    {
        [[GlobalData shareGlobalData] showAlert:@"Network error. Please check your connectivity." Title:@"Alert"];
    }
    else
    {
        data = [[NSDictionary alloc] initWithDictionary:result];
        [self addData];
    }
}

- (void) initData
{
    [viewHeader setTitlePage:@""];
    self.txtDescription.text = @"";
    [self.txtDescription sizeToFit];
    self.txtDescription.textColor = [UIColor colorFromHexString:@"#bce6ff"];
    
    self.txt_place.text = @"";
    
    self.count_favourite.text = @"0 FAVORITES";
    
    // Last Comment
    self.txtComment.text = @"";
    self.txtComment.textColor = [UIColor colorFromHexString:@"#bce6ff"];
    [self.txtComment sizeToFit];
    [self.avatarComment setImage:[UIImage imageNamed:@"avatar"]];
    [self.viewComment setHidden:YES];
    
    CGRect frameViewComment = self.viewComment.frame;
    frameViewComment.origin.y = self.txtDescription.frame.size.height + self.txtDescription.frame.origin.y;
    frameViewComment.size.height = 32 + (self.txtComment.frame.size.height > 25 ? self.txtComment.frame.size.height : 25);
    self.viewComment.frame = frameViewComment;
    
    [self.priceCircle setProgress:0.01
                           timing:TPPropertyAnimationTimingEaseOut
                         duration:1.0
                            delay:0.0];
    
    [self.quantityCircle setProgress:0.01
                              timing:TPPropertyAnimationTimingEaseOut
                            duration:1.0
                               delay:0.0];
    
    [self.qualityCircle setProgress:0.01
                             timing:TPPropertyAnimationTimingEaseOut
                           duration:1.0
                              delay:0.0];
    
    [self.badge_1 setImage:nil];
    [self.badge_2 setImage:nil];
    [self.badge_3 setImage:nil];
    
    [self clearAllTag];
    [self reSizeListTag];
}

- (void) addData
{
//    NSLog(@"data %@", data);
    if ([[data objectForKey:@"is_sponsor"] integerValue] == 1) {
        self.imgIconHuecaSponsored.hidden = NO;
    }
    else {
        self.imgIconHuecaSponsored.hidden = YES;
    }
    
    [viewHeader setTitlePage:[data valueForKey:@"name"]];
    self.txtDescription.frame = CGRectMake(15, 434, 290, 128);
    self.txtDescription.text = [data valueForKey:@"description"];
    [self.txtDescription sizeToFit];
    self.txtDescription.textColor = [UIColor colorFromHexString:@"#bce6ff"];
    
    self.count_favourite.text = [NSString stringWithFormat:@"%@ FAVORITES", [data valueForKey:@"count_favourite"]];
    [self.img_rank setImage:[UIImage imageNamed:[NSString stringWithFormat:@"restaurant_bage_rank_%@", [data valueForKey:@"rank"]]]];
    
    self.txt_time_open.text = [NSString stringWithFormat:@"%@ to %@", [data valueForKey:@"time_open"], [data valueForKey:@"time_close"]];
    
    self.txt_place.text = [NSString stringWithFormat:@"%@", [data valueForKey:@"place_id"]];
    
    UIImage *imageRe = nil;
    imageRe = [NLoader imageWithURL:[data valueForKey:@"image"]
                  completeHandler:^(UIImage *img) {
//                      [self.image setImage:img];
                      [self.btnChangeMap setImage:img forState:UIControlStateNormal];
                  }
                            cache:nil];
    if(imageRe)
    {
//        [self.image setImage:imageRe];
        [self.btnChangeMap setImage:imageRe forState:UIControlStateNormal];
    }
    
    [self.btnFavorito setSelected:FALSE];
    if([[data valueForKey:@"favorite"] boolValue])
    {
        [self.btnFavorito setSelected:YES];
    }
    
    [self clearAllTag];
    
    NSArray *tags = [data objectForKey:@"dishes_id"];
    if(tags.count > 0)
    {
        for(NSString *tag in tags)
        {
            TagForItem *item = [[TagForItem alloc] initWithFrame:CGRectMake(5, 0, 10, 13)andData:tag];
            [self.view_tag addSubview:item];
        }
    }
    
    [self reSizeListTag];
    
    CGRect frameViewTips = self.viewTips.frame;
    frameViewTips.origin.y = self.txtDescription.frame.size.height + self.txtDescription.frame.origin.y;
    self.viewTips.frame = frameViewTips;
    
    CGRect frameViewComment = self.viewComment.frame;
    frameViewComment.origin.y = frameViewTips.size.height + frameViewTips.origin.y;
    
//    // Last Comment
//    NSDictionary *comment = [data objectForKey:@"last_comment"];
//    if([comment count] > 0)
//    {
//        [self.viewComment setHidden:NO];
//        self.txtComment.frame = CGRectMake(49, 21, 219, 128);
//        self.txtComment.text = [comment valueForKey:@"comment"];
//        self.txtComment.textColor = [UIColor colorFromHexString:@"#bce6ff"];
//        [self.txtComment sizeToFit];
//        [self.avatarComment setImage:[UIImage imageNamed:@"avatar"]];
//
//        UIImage *image = nil;
//        image = [NLoader imageWithURL:[comment valueForKey:@"avatar"]
//                      completeHandler:^(UIImage *img) { [self.avatarComment setImage:img]; }
//                                cache:nil];
//        if(image)
//        {
//            [self.avatarComment setImage:image];
//        }
//        
//        frameViewComment.size.height = 32 + (self.txtComment.frame.size.height > 25 ? self.txtComment.frame.size.height : 25);
//    }
//    else
//    {
//        frameViewComment.size.height = 10;
//    }
//    
//    self.viewComment.frame = frameViewComment;
    
    float precio = [[data valueForKey:@"precio"] intValue] > 0 ? [[data valueForKey:@"precio"] intValue]/10.0f : 0;
    float cantidad = [[data valueForKey:@"cantidad"] intValue] > 0 ? [[data valueForKey:@"cantidad"] intValue]/10.0f : 0;
    float calidad = [[data valueForKey:@"calidad"] intValue] > 0 ? [[data valueForKey:@"calidad"] intValue]/10.0f : 0;
    
    [self.priceCircle setProgress:precio
                           timing:TPPropertyAnimationTimingEaseOut
                         duration:1.0
                            delay:0.0];
    
    [self.quantityCircle setProgress:cantidad
                              timing:TPPropertyAnimationTimingEaseOut
                            duration:1.0
                               delay:0.0];
    
    [self.qualityCircle setProgress:calidad
                             timing:TPPropertyAnimationTimingEaseOut
                           duration:1.0
                              delay:0.0];
    
    NSArray *badges = [data objectForKey:@"badges"];
    
    if(badges.count >= 1)
    {
        UIImage *image_1 = nil;
        image_1 = [NLoader imageWithURL:[badges objectAtIndex:0]
                      completeHandler:^(UIImage *img) { [self.badge_1 setImage:img]; }
                                cache:nil];
        if(image_1)
        {
            [self.badge_1 setImage:image_1];
        }
    }
    if(badges.count >= 2)
    {
        UIImage *image_2 = nil;
        image_2 = [NLoader imageWithURL:[badges objectAtIndex:1]
                        completeHandler:^(UIImage *img) { [self.badge_2 setImage:img]; }
                                  cache:nil];
        if(image_2)
        {
            [self.badge_2 setImage:image_2];
        }
    }
    if(badges.count >= 3)
    {
        UIImage *image_3 = nil;
        image_3 = [NLoader imageWithURL:[badges objectAtIndex:1]
                        completeHandler:^(UIImage *img) { [self.badge_3 setImage:img]; }
                                  cache:nil];
        if(image_3)
        {
            [self.badge_3 setImage:image_3];
        }
    }
    
    CGRect frameViewHeader = self.viewHeaderTable.frame;
    frameViewHeader.size.height = frameViewComment.origin.y + frameViewComment.size.height + 10;
    self.viewHeaderTable.frame = frameViewHeader;
    
    self.table.tableHeaderView = self.viewHeaderTable;
    
//    [self loadDataPhoto];
}

- (void) clearAllTag
{
    for(UIView *subview in [self.view_tag subviews]) {
        [subview removeFromSuperview];
    }
}

- (void) reSizeListTag
{
    CGFloat w = 0;
    CGFloat h = 0;
    for(TagForItem *item in [self.view_tag subviews])
    {
        CGRect frameTag = item.frame;
        if(w + item.frame.size.width > self.view_tag.frame.size.width)
        {
            w = 0;
            h += 15;
        }
        frameTag.origin.x = w;
        frameTag.origin.y = h;
        item.frame = frameTag;
        w += item.frame.size.width  + 5;
    }
    
    CGRect frameViewTag = self.view_tag.frame;
    frameViewTag.size.height = h + 10;
    self.view_tag.frame = frameViewTag;
    
    CGRect frameViewTips = self.viewTips.frame;
    frameViewTips.size.height = frameViewTag.origin.y + frameViewTag.size.height + 20;
    self.viewTips.frame = frameViewTips;
}

- (IBAction)onViewComment:(UIButton *)sender
{
    ListCommentUserVC *vc = [[ListCommentUserVC alloc] initWithNibName:@"ListCommentUserVC" bundle:nil];
    [vc addRestaurant:data];
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)onFavourite:(UIButton *)sender
{
    if(self.btnFavorito.selected)
    {
        [self.btnFavorito setSelected:NO];
    }
    else
    {
        [self.btnFavorito setSelected:YES];
    }
    dispatch_async(kBgQueue, ^{
        NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
        [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"email"] forKey:@"email"];
        [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"key"] forKey:@"key"];
        [params setObject:[NSString stringWithFormat:@"%@", [data valueForKey:@"id"]] forKey:@"id"];
        
        [NLoader jsonDataOfURL:LINK_GET_FAVOURITE_RESTAURANT params:params];
    });
}

- (IBAction)makeReview:(UIButton *)sender
{
    MakeReviewVC *vc = [[MakeReviewVC alloc] initWithNibName:@"MakeReviewVC" bundle:nil];
    [vc addRestaurant:data];
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)onViewMap:(UIButton *)sender
{
    ViewMapRestaurantVC *vc = [[ViewMapRestaurantVC alloc] initWithNibName:@"ViewMapRestaurantVC" bundle:nil];
    [vc setRestaurant:data];
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)onShowComment:(id)sender {
    ListCommentVC *listVC = [[ListCommentVC alloc] initWithNibName:@"ListCommentVC" bundle:nil];
    [listVC addRestaurant:data];
    [self.navigationController pushViewController:listVC animated:YES];
}

- (void) showLoading
{
    popupLoading = [[CustomIOS7AlertView alloc] init];
    
    [popupLoading setContainerView:[[GlobalData shareGlobalData] createViewLoading]];
    
    [popupLoading setButtonTitles:nil];
    [popupLoading setDelegate:self];
    
    [popupLoading setUseMotionEffects:true];
    [popupLoading show];
    
}
- (void)customIOS7dialogButtonTouchUpInside: (CustomIOS7AlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    [alertView close];
}

- (void) loadDataPhoto
{
    [self.table reloadData];
    [self showLoading];
    
    dispatch_async(kBgQueue, ^{
        NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
        [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"email"] forKey:@"email"];
        [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"key"] forKey:@"key"];
        [params setObject:[NSString stringWithFormat:@"%@", [data valueForKey:@"id"]] forKey:@"id"];
        
        NSDictionary *response = [NLoader jsonDataOfURL:LINK_GET_PHOTO_RESTAURANT params:params];
        
        [self performSelectorOnMainThread:@selector(getPhotoComplete:) withObject:response waitUntilDone:NO];
    });
}

- (void) getPhotoComplete:(NSDictionary *)result
{
    [popupLoading close];
    if(result == nil)
    {
        [[GlobalData shareGlobalData] showAlert:@"Network error. Please check your connectivity." Title:@"Alert"];
    }
    else
    {
        if([[result valueForKey:@"status"] boolValue])
        {
            dataPhoto = [[NSMutableArray alloc] initWithArray:[result valueForKey:@"data"]];
            [self.table reloadData];
        }
        else
        {
            [[GlobalData shareGlobalData] showAlert:[result objectForKey:@"message"] Title:@"Alert!"];
        }
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return dataPhoto.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    PhotoRestaurantCell *cell = (PhotoRestaurantCell *)[tableView dequeueReusableCellWithIdentifier:@"PhotoRestaurantCell"];
    if(cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"PhotoRestaurantCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    [self configureCell:cell atIndexPath:indexPath];
    return cell;
}

-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self configureCell:_stubCell atIndexPath:indexPath];
    CGFloat height = [_stubCell getHeight];
    return height;
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 33.f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [[tableView cellForRowAtIndexPath:indexPath] setSelected:NO animated:YES];
    
    NSDictionary *dt = [dataPhoto objectAtIndex:indexPath.row];
    MyProfileVC *vc = [[MyProfileVC alloc] initWithNibName:@"MyProfileVC" bundle:nil];
    [vc setUserID:[NSString stringWithFormat:@"%@", [dt valueForKey:@"id"]]];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)tableView:(UITableView *)tableView didEndEditingRowAtIndexPath:(NSIndexPath *)indexPath
{
	[tableView reloadData];
}

- (void)configureCell:(PhotoRestaurantCell *)cell atIndexPath:(NSIndexPath *)indexPath
{
    [cell addData:[dataPhoto objectAtIndex:indexPath.row]];
}
@end
