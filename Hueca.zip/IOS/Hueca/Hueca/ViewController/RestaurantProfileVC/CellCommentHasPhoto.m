//
//  CellCommentHasPhoto.m
//  Hueca
//
//  Created by Mobiz on 6/18/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "CellCommentHasPhoto.h"
#import "NLoader.h"

@implementation CellCommentHasPhoto

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)addData:(NSDictionary *)dt
{
    CGRect frameViewComment = self.viewComment.frame;
//    frameViewComment.origin.y = frameViewTips.size.height + frameViewTips.origin.y;
    
    // Last Comment
//    NSDictionary *comment = [dt objectForKey:@"content"];

    if([dt count] > 0)
   {
       [self.viewComment setHidden:NO];
       self.contentComment.frame = CGRectMake(49, 21, 219, 128);
       
       self.contentComment.numberOfLines = 0;
       
       CGSize maximumLabelSize = CGSizeMake(215, 200);
       
       CGSize expectedLabelSize = [self.contentComment.text sizeWithFont:self.contentComment.font constrainedToSize:maximumLabelSize lineBreakMode:NSLineBreakByWordWrapping];
       
       
       CGRect newFrame = self.contentComment.frame;
       newFrame.size.height = expectedLabelSize.height;
       self.contentComment.frame = newFrame;
       
        self.contentComment.text = [dt valueForKey:@"name"];
//        self.contentComment.textColor = [UIColor colorFromHexString:@"#bce6ff"];
        [self.contentComment sizeToFit];
        [self.avatar setImage:[UIImage imageNamed:@"avatar"]];
       self.txtDate.text = [dt valueForKey:@"time"];

        UIImage *image = nil;
        image = [NLoader imageWithURL:[dt valueForKey:@"avatar"]
                      completeHandler:^(UIImage *img) { [self.avatar setImage:img]; }
                                cache:nil];
        if(image)
        {
            [self.avatar setImage:image];
        }
       
       UIImage *imageThumb = nil;
       imageThumb = [NLoader imageWithURL:[dt valueForKey:@"img"]
                     completeHandler:^(UIImage *imgThumb) { [self.imgThumb setImage:imgThumb]; }
                               cache:nil];
       if(imageThumb)
       {
           [self.imgThumb setImage:imageThumb];
       }

//        frameViewComment.size.height = 32 + (self.txtComment.frame.size.height > 25 ? self.txtComment.frame.size.height : 25);
   }
    else
    {
//        frameViewComment.size.height = 10;
    }
    
//    self.viewComment.frame = frameViewComment;
}

- (float) getHeight
{
    return 340.0f;
}

@end
