//
//  RestaurantProfileVC.h
//  Hueca
//
//  Created by NhiepPhong on 4/29/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewHeader.h"
#import "KAProgressLabel.h"
#import "CustomIOS7AlertView.h"
#import "PhotoRestaurantCell.h"
#import "KSLabel.h"
#import "MakeReviewVC.h"

@interface RestaurantProfileVC : UIViewController<UITableViewDataSource, UITableViewDelegate, CustomIOS7AlertViewDelegate>
{
    CustomIOS7AlertView *popupLoading;
    ViewHeader *viewHeader;
    NSDictionary *data;
    int idRestaurant;
    NSMutableArray *dataPhoto;
    PhotoRestaurantCell *_stubCell;
}

@property (weak, nonatomic) IBOutlet UIImageView *bg;
@property (weak, nonatomic) IBOutlet UIImageView *image;
@property (weak, nonatomic) IBOutlet UIButton *btnChangeMap;

@property (weak, nonatomic) IBOutlet UIImageView *img_rank;
@property (weak, nonatomic) IBOutlet UILabel *count_favourite;
@property (weak, nonatomic) IBOutlet KSLabel *txt_place;
@property (weak, nonatomic) IBOutlet KSLabel *txt_time_open;
@property (weak, nonatomic) IBOutlet UIButton *btnCalificar;
@property (weak, nonatomic) IBOutlet UIButton *btnFavorito;
@property (weak, nonatomic) IBOutlet UIButton *btnMap;

@property (weak, nonatomic) IBOutlet KAProgressLabel *priceCircle;
@property (weak, nonatomic) IBOutlet UILabel *priceTxt;

@property (weak, nonatomic) IBOutlet KAProgressLabel *quantityCircle;
@property (weak, nonatomic) IBOutlet UILabel *quantityTxt;
@property (weak, nonatomic) IBOutlet KAProgressLabel *qualityCircle;
@property (weak, nonatomic) IBOutlet UILabel *qualityTxt;
@property (weak, nonatomic) IBOutlet UIView *line1;
@property (weak, nonatomic) IBOutlet UILabel *labelDescription;
@property (weak, nonatomic) IBOutlet UITextView *txtDescription;
@property (weak, nonatomic) IBOutlet UIView *viewComment;
@property (weak, nonatomic) IBOutlet UILabel *labelComment;
@property (weak, nonatomic) IBOutlet UIImageView *avatarComment;
@property (weak, nonatomic) IBOutlet UITextView *txtComment;
@property (strong, nonatomic) IBOutlet UIView *viewHeaderTable;
@property (weak, nonatomic) IBOutlet UIImageView *badge_1;
@property (weak, nonatomic) IBOutlet UIImageView *badge_2;
@property (weak, nonatomic) IBOutlet UIImageView *badge_3;
@property (weak, nonatomic) IBOutlet UIView *viewTips;
@property (weak, nonatomic) IBOutlet UIView *view_tag;
@property (weak, nonatomic) IBOutlet UILabel *txtTips;
@property (weak, nonatomic) IBOutlet UIImageView *imgIconHuecaSponsored;

@property (weak, nonatomic) IBOutlet UITableView *table;

- (void) setIdRestaurant:(int)id;
- (IBAction)onViewComment:(UIButton *)sender;
- (IBAction)onFavourite:(UIButton *)sender;
- (IBAction)makeReview:(UIButton *)sender;
- (IBAction)onViewMap:(UIButton *)sender;
- (IBAction)onShowComment:(id)sender;

@end
