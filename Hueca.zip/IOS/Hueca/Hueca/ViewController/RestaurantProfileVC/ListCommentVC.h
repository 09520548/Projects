//
//  ListCommentVC.h
//  Hueca
//
//  Created by Mobiz on 6/18/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewHeader.h"
#import "CustomIOS7AlertView.h"
#import "CellCommentNoPhoto.h"
#import "CellCommentHasPhoto.h"
#import "MyProfileVC.h"

@interface ListCommentVC : UIViewController<UITableViewDataSource, UITableViewDelegate, CustomIOS7AlertViewDelegate>
{
    ViewHeader *viewHeader;
    NSDictionary *dataRestaurant;
    NSMutableArray *data;
    CellCommentNoPhoto *_stubCell;
    CellCommentHasPhoto *_stubCell2;
    CustomIOS7AlertView *popupLoading;
}

@property (weak, nonatomic) IBOutlet UIImageView *bg;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UITableView *myTable;

- (void) addRestaurant:(NSDictionary *)dt;
@end
