//
//  TagForItem.m
//  Hueca
//
//  Created by NhiepPhong on 6/6/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "TagForItem.h"
#import "GlobalData.h"

@implementation TagForItem

- (id)initWithFrame:(CGRect)frame andData:(NSString *)dt
{
    self = [super initWithFrame:frame];
    if (self)
    {
        
    }
    
    data = dt;
    
    UIImage *bg = [[UIImage imageNamed: @"item_tag"] resizableImageWithCapInsets:UIEdgeInsetsMake(7.0, 7.0, 7.0, 7.0)];
    bgImg = [[UIImageView alloc] initWithImage:bg];
    [self addSubview:bgImg];
    
    title = [[UILabel alloc] init];
    title.backgroundColor = [UIColor clearColor];
    title.textColor = [UIColor colorFromHexString:@"#996633"];
    title.text = dt;
    title.font = [UIFont rw_FontBoldWithSize:8];
    [self addSubview:title];
    
    CGRect frameTitle = title.frame;
    
    frameTitle.size.width = [[GlobalData shareGlobalData] widthOfString:title.text withFont:title.font andMaxWidth:200.0f] + 7;
    frameTitle.origin.x = 10;
    frameTitle.origin.y = -1;
    frameTitle.size.height = 13;
    title.frame = frameTitle;
    
    frame.size.width = title.frame.size.width + 7;
    self.frame = frame;
    
    bgImg.frame = CGRectMake(0, 0, self.frame.size.width, 13);
    
    return self;
}

@end
