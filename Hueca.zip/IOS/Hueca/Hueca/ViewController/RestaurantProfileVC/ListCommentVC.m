//
//  ListCommentVC.m
//  Hueca
//
//  Created by Mobiz on 6/18/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "ListCommentVC.h"
#import "NDevice.h"
#import "GlobalData.h"
#import "NPConstants.h"
#import "NLoader.h"


@interface ListCommentVC ()

@end

@implementation ListCommentVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
         data = [NSMutableArray new];
    }
    return self;
}

- (void)viewWillAppear:(BOOL)animated
{
    
    UINib *cellNib = [UINib nibWithNibName:@"CellCommentNoPhoto" bundle:nil];
    [self.myTable registerNib:cellNib forCellReuseIdentifier:@"CellCommentNoPhoto"];
    _stubCell = [cellNib instantiateWithOwner:nil options:nil][0];
    
    UINib *cellNib2 = [UINib nibWithNibName:@"CellCommentHasPhoto" bundle:nil];
    [self.myTable registerNib:cellNib2 forCellReuseIdentifier:@"CellCommentHasPhoto"];
    _stubCell2 = [cellNib2 instantiateWithOwner:nil options:nil][0];
    
    viewHeader = [[ViewHeader alloc] initWithFrame:CGRectMake(0, 0, 320, 46)];
    [self.view addSubview:viewHeader];
    [viewHeader setVC:self];
    [viewHeader setTitlePage:@"Comentarios y Fotos"];
    
    NSString *imgName = @"bg";
    
    if([NDevice screenType] == NDeviceScreenIPHONE5)
    {
        imgName = @"bg-568h";
    }
    
    self.bg.image = [UIImage imageNamed:imgName];
    self.bg.frame = CGRectMake(0, 0, [NDevice getWidth], [NDevice getHeight]);
    
    self.myTable.frame = CGRectMake(0, 46, 320, self.view.frame.size.height - 46);
    
    UIView *viewHeaderTable = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 20)];
    viewHeaderTable.backgroundColor = [UIColor clearColor];
    self.myTable.tableHeaderView = viewHeaderTable;
    
    [self loadData];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) addRestaurant:(NSDictionary *)dt
{
    dataRestaurant = dt;
    NSLog(@"dataRestaurant: %@", dataRestaurant);
}

- (void) loadData
{
    [self showLoading];
    dispatch_async(kBgQueue, ^{
        NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
        [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"email"] forKey:@"email"];
        [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"key"] forKey:@"key"];
        [params setObject:[NSString stringWithFormat:@"%@", [dataRestaurant valueForKey:@"id"]] forKey:@"id"];
        
        NSDictionary *response = [NLoader jsonDataOfURL:LINK_GET_LISTCOMMENT params:params];
        
        [self performSelectorOnMainThread:@selector(getDataComplete:) withObject:response waitUntilDone:NO];
    });
}

- (void) getDataComplete:(NSDictionary *)result
{
    [popupLoading close];
    if(result == nil)
    {
        [[GlobalData shareGlobalData] showAlert:@"Network error. Please check your connectivity." Title:@"Alert"];
    }
    else
    {
        NSLog(@"getDataComplete: %@", result);
        data = [[NSMutableArray alloc] initWithArray:[result objectForKey:@"data"]];
        [self.myTable reloadData];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return data.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *currData = [data objectAtIndex:indexPath.row];
    if ([[currData objectForKey:@"type"] intValue] == 0) {
        CellCommentNoPhoto *cell = (CellCommentNoPhoto *)[tableView dequeueReusableCellWithIdentifier:@"CellCommentNoPhoto"];
        if(cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"CellCommentNoPhoto" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        [self configureCell:cell atIndexPath:indexPath];
        return cell;
    }
    else
    {
        CellCommentHasPhoto *cell = (CellCommentHasPhoto *)[tableView dequeueReusableCellWithIdentifier:@"CellCommentHasPhoto"];
        if(cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"CellCommentHasPhoto" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        [self configureCellHasPhoto:cell atIndexPath:indexPath];
        return cell;
    }
}

-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CGFloat height = 33.0f;
    NSDictionary *currData = [data objectAtIndex:indexPath.row];
    if ([[currData objectForKey:@"type"] intValue] == 0) {
        [self configureCell:_stubCell atIndexPath:indexPath];
        height = [_stubCell getHeight];
    }
    else {
        [self configureCellHasPhoto:_stubCell2 atIndexPath:indexPath];
        height = [_stubCell2 getHeight];
    }
    
    
    return height;
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 33.f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [[tableView cellForRowAtIndexPath:indexPath] setSelected:NO animated:YES];
    
    NSDictionary *dt = [data objectAtIndex:indexPath.row];
    MyProfileVC *vc = [[MyProfileVC alloc] initWithNibName:@"MyProfileVC" bundle:nil];
    [vc setUserID:[NSString stringWithFormat:@"%@", [dt valueForKey:@"uid"]]];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOS7AlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    [alertView close];
}

- (void)configureCell:(CellCommentNoPhoto *)cell atIndexPath:(NSIndexPath *)indexPath
{
    [cell addData:[data objectAtIndex:indexPath.row]];
}

- (void)configureCellHasPhoto:(CellCommentHasPhoto *)cell atIndexPath:(NSIndexPath *)indexPath
{
    [cell addData:[data objectAtIndex:indexPath.row]];
}

- (void) showLoading
{
    popupLoading = [[CustomIOS7AlertView alloc] init];
    
    [popupLoading setContainerView:[[GlobalData shareGlobalData] createViewLoading]];
    
    [popupLoading setButtonTitles:nil];
    [popupLoading setDelegate:self];
    
    [popupLoading setUseMotionEffects:true];
    [popupLoading show];
    
}

@end
