//
//  CellFeedHeader.m
//  Hueca
//
//  Created by NhiepPhong on 5/2/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "CellFeedHeader.h"
#import "NLoader.h"

@implementation CellFeedHeader

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        UIView* xibView = [[[NSBundle mainBundle] loadNibNamed:@"CellFeedHeader" owner:self options:nil] objectAtIndex:0];
        [xibView setFrame:[self bounds]];
        [self addSubview:xibView];
        
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTapBanner)];
        tapGesture.numberOfTapsRequired = 1;
        [self addGestureRecognizer:tapGesture];
    }
    return self;
}

- (void) addData:(NSDictionary *)dt
{
    data = dt;
    
    if([[data valueForKey:@"typeAd"] intValue] == 1) //Images
    {
        UIImage *image = nil;
        image = [NLoader imageWithURL:[dt valueForKey:@"thumb"]
                      completeHandler:^(UIImage *img) { [self.image setImage:img]; }
                                cache:nil];
        if(image)
        {
            [self.image setImage:image];
        }
        [self.image setContentMode:UIViewContentModeScaleAspectFill];
        
        [self.image setHidden:NO];
        [self.thumb setHidden:YES];
        self.image.layer.masksToBounds = TRUE;
        [self.txtContent setHidden:YES];
    }
    else //Text
    {
        [self.image setHidden:YES];
        [self.thumb setHidden:NO];
        [self.txtContent setHidden:NO];
        
        UIImage *image = nil;
        image = [NLoader imageWithURL:[dt valueForKey:@"thumb"]
                      completeHandler:^(UIImage *img) { [self.thumb setImage:img]; }
                                cache:nil];
        if(image)
        {
            [self.thumb setImage:image];
        }
        self.thumb.layer.masksToBounds = TRUE;
        [self.thumb setContentMode:UIViewContentModeScaleAspectFill];
        
        self.txtContent.text = [dt valueForKey:@"content"];
        
        self.thumb.layer.borderColor = [[UIColor whiteColor] CGColor];
        self.thumb.layer.borderWidth = 1;
        self.txtContent.font = [UIFont rw_FontBoldWithSize:10];
        
        CGSize maximumLabelSize = CGSizeMake(223, 200);
        
        CGSize expectedLabelSize = [self.txtContent.text sizeWithFont:self.txtContent.font constrainedToSize:maximumLabelSize lineBreakMode:self.txtContent.lineBreakMode];
        
        CGRect newFrame = self.txtContent.frame;
        newFrame.size.height = expectedLabelSize.height;
        self.txtContent.frame = newFrame;
        
        CGRect frameView = self.frame;
        frameView.size.height = 75;
        if(self.txtContent.frame.origin.y + self.txtContent.frame.size.height > 69)
        {
            frameView.size.height = self.txtContent.frame.origin.y + self.txtContent.frame.size.height + 25;
        }
        
        self.frame = frameView;
    }
    
    CGRect frameBg = self.frame;
    frameBg.size.height = frameBg.size.height - 20;
    frameBg.size.width = 280;
    frameBg.origin.x = 10;
    frameBg.origin.y = 10;
    UIView *viewBg = [[UIView alloc] initWithFrame:frameBg];
    viewBg.backgroundColor = [UIColor colorFromHexString:@"#b9eea8"];
    viewBg.layer.borderWidth = 1;
    viewBg.layer.cornerRadius = 2;
    viewBg.layer.borderColor = [[UIColor colorFromHexString:@"#096094"] CGColor];
    
    [self addSubview:viewBg];
    [self sendSubviewToBack:viewBg];
}

- (void)onTapBanner
{
    [self.delegate onTouchHeader:data];
}

@end
