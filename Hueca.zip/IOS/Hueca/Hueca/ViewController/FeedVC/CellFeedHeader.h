//
//  CellFeedHeader.h
//  Hueca
//
//  Created by NhiepPhong on 5/2/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CellFeddHeaderDelegate <NSObject>

- (void) onTouchHeader:(NSDictionary *)dt;

@end
@interface CellFeedHeader : UIView
{
    NSDictionary *data;
}
@property (weak, nonatomic) IBOutlet UIImageView *thumb;
@property (weak, nonatomic) IBOutlet UIImageView *image;
@property (weak, nonatomic) IBOutlet UILabel *txtContent;
@property id<CellFeddHeaderDelegate>delegate;

- (void) addData:(NSDictionary *)dt;

@end
