//
//  FeedVC.m
//  Hueca
//
//  Created by NhiepPhong on 4/23/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "FeedVC.h"
#import "NDevice.h"
#import "GlobalData.h"
#import "NLoader.h"
#import "RestaurantProfileVC.h"
#import "MyProfileVC.h"

@interface FeedVC ()
{
    NSString *filter;
    NSString *idCity;
    BOOL isLoading;
    BOOL isCanLoadMore;
    NSDictionary *dataAdvertisement;
    NSMutableArray *data;
}
@end

@implementation FeedVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        data = [NSMutableArray new];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    UINib *cellNib = [UINib nibWithNibName:@"CellItemFeed" bundle:nil];
    [self.table registerNib:cellNib forCellReuseIdentifier:@"CellItemFeed"];
    _stubCell = [cellNib instantiateWithOwner:nil options:nil][0];

    viewHeader = [[ViewHeader alloc] initWithFrame:CGRectMake(0, 0, 320, 46)];
    [self.view addSubview:viewHeader];
    
    [viewHeader setVC:self];
    [viewHeader setTitlePage:@"Feed"];
    
    NSString *imgName = @"bg";
    
    if([NDevice screenType] == NDeviceScreenIPHONE5)
    {
        imgName = @"bg-568h";
    }
    
    self.bg.image = [UIImage imageNamed:imgName];
    self.bg.frame = CGRectMake(0, 0, [NDevice getWidth], [NDevice getHeight]);
    
    self.btnSelectCate.titleLabel.font = [UIFont rw_FontBoldWithSize:16];
    
    [self.view addSubview:self.viewSelectBox];
    
    [self.viewSelectBox initView:self.view.frame];
    
    [self.btnSelectCate setTitle:@"Ciudad" forState:UIControlStateNormal];
    
    self.table.frame = CGRectMake(0, 120, 320, self.view.frame.size.height - 120);
    
    cellHeader = [[CellFeedHeader alloc] initWithFrame:CGRectMake(0, 0, 320, 70)];
    cellHeader.delegate = self;
    self.table.tableHeaderView = nil;
    
    isCanLoadMore = TRUE;
    isLoading = FALSE;
    idCity = @"";
    data = [NSMutableArray new];
    [self setBtnFilter:self.btnRating];
}

- (void) loadData
{
    if(!isLoading)
    {
        if(data.count == 0)
        {
            [self showLoading];
        }
        isLoading = TRUE;
        dispatch_async(kBgQueue, ^{
            
            NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
            [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"email"] forKey:@"email"];
            [params setObject:[[GlobalData shareGlobalData].userInfo valueForKey:@"key"] forKey:@"key"];
            [params setObject:idCity forKey:@"city"];
            [params setObject:filter forKey:@"filter"];
            [params setObject:[NSString stringWithFormat:@"%d", data.count] forKey:@"start"];
            
            NSDictionary *response = [NLoader jsonDataOfURL:LINK_GET_FEED params:params];
            
            [self performSelectorOnMainThread:@selector(getDataComplete:) withObject:response waitUntilDone:NO];
        });
    }
}

- (void) getDataComplete:(NSDictionary *)result
{
    isLoading = FALSE;
    isCanLoadMore = FALSE;
    [popupLoading close];
    
    if(result == nil)
    {
        [[GlobalData shareGlobalData] showAlert:@"Network error. Please check your connectivity." Title:@"Alert"];
    }
    else
    {
        if([[result valueForKey:@"status"] boolValue])
        {
            dataAdvertisement = [result objectForKey:@"advertisement"];
            NSArray *dt = [result objectForKey:@"data"];
            [data addObjectsFromArray:dt];

            if(dt.count > 0)
            {
                isCanLoadMore = TRUE;
            }
            
            [cellHeader addData:dataAdvertisement];
            self.table.tableHeaderView = cellHeader;
            
            [self.table reloadData];
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (IBAction)onFilter:(UIButton *)sender
{
    [self setBtnFilter:sender];
}

- (IBAction)onOpenSelectCate:(UIButton *)sender
{
    [self.viewSelectBox show];
}

- (void) setBtnFilter:(UIButton *)btn
{
    [self.btnRating setSelected:NO];
    [self.btnPINS setSelected:NO];
    [self.btnHuecas setSelected:NO];
    
    if(btn == self.btnRating)
    {
        [self.btnRating setSelected:YES];
        filter = @"review";
    }
    else if(btn == self.btnPINS)
    {
        [self.btnPINS setSelected:YES];
        filter = @"checkin";
    }
    else if(btn == self.btnHuecas)
    {
        [self.btnHuecas setSelected:YES];
        filter = @"restaurant";
    }
    data = [NSMutableArray new];
    [self.table reloadData];
    
    [self loadData];
}

- (void)onSelectCategory:(NSDictionary *)dt
{
    [self.btnSelectCate setTitle:[dt valueForKey:@"name"] forState:UIControlStateNormal];
    idCity = [NSString stringWithFormat:@"%@", [dt valueForKey:@"id"]];
    data = [NSMutableArray new];
    [self.table reloadData];
    [self loadData];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return data.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellItemFeed *cell = (CellItemFeed *)[tableView dequeueReusableCellWithIdentifier:@"CellItemFeed"];
    if(cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"CellItemFeed" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    [self configureCell:cell atIndexPath:indexPath];
    return cell;
}

-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self configureCell:_stubCell atIndexPath:indexPath];
    CGFloat height = [_stubCell getHeight];
    return height;
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 33.f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [[tableView cellForRowAtIndexPath:indexPath] setSelected:NO animated:YES];
    
    NSDictionary *dt = [data objectAtIndex:indexPath.row];
    if([[dt valueForKey:@"obj"] intValue] == 1)
    {
        RestaurantProfileVC *vc = [[RestaurantProfileVC alloc] initWithNibName:@"RestaurantProfileVC" bundle:nil];
        [vc setIdRestaurant:[[dt valueForKey:@"id"] intValue]];
        [self.navigationController pushViewController:vc animated:YES];
    }
    else
    {
        MyProfileVC *vc = [[MyProfileVC alloc] initWithNibName:@"MyProfileVC" bundle:nil];
        [vc setUserID:[NSString stringWithFormat:@"%@", [dt valueForKey:@"id"]]];
        [self.navigationController pushViewController:vc animated:YES];
    }
}

- (void)tableView:(UITableView *)tableView didEndEditingRowAtIndexPath:(NSIndexPath *)indexPath
{
	[tableView reloadData];
}

- (void)configureCell:(CellItemFeed *)cell atIndexPath:(NSIndexPath *)indexPath
{
    [cell addData:[data objectAtIndex:indexPath.row]];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    float yOffset = scrollView.contentOffset.y;
    
    if(yOffset >= (scrollView.contentSize.height - scrollView.frame.size.height)-10)
    {
        if(isCanLoadMore && !isLoading)
        {
            [self loadData];
        }
    }
}

- (void) onTouchHeader:(NSDictionary *)dt
{
    if([[dt valueForKey:@"type"] isEqualToString:@"link"])
    {
        NSString *url = [dt valueForKey:@"link"];
        [[UIApplication sharedApplication]openURL:[NSURL URLWithString:url]];
    }
    else
    {
        RestaurantProfileVC *vc = [[RestaurantProfileVC alloc] initWithNibName:@"RestaurantProfileVC" bundle:nil];
        [vc setIdRestaurant:[[dt valueForKey:@"id"] intValue]];
        [self.navigationController pushViewController:vc animated:YES];
    }
}

- (void) showLoading
{
    popupLoading = [[CustomIOS7AlertView alloc] init];
    
    [popupLoading setContainerView:[[GlobalData shareGlobalData] createViewLoading]];
    
    [popupLoading setButtonTitles:nil];
    [popupLoading setDelegate:self];
    
    [popupLoading setUseMotionEffects:true];
    [popupLoading show];
    
}
- (void)customIOS7dialogButtonTouchUpInside: (CustomIOS7AlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    [alertView close];
}
@end
