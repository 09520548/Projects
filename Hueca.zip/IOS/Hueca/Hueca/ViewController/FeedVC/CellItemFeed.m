//
//  CellItemFeed.m
//  Hueca
//
//  Created by NhiepPhong on 5/2/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "CellItemFeed.h"
#import "NLoader.h"

@implementation CellItemFeed

- (void)awakeFromNib
{
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

- (void) addData:(NSDictionary *)dt
{
    UIImage *image = nil;
    image = [NLoader imageWithURL:[dt valueForKey:@"image"]
                  completeHandler:^(UIImage *img) { [self.thumb setImage:img]; }
                            cache:nil];
    if(image)
    {
        [self.thumb setImage:image];
    }
    [self.thumb setContentMode:UIViewContentModeScaleAspectFill];
    
    self.txtContent.text = [dt valueForKey:@"content"];
    self.txtTime.text = [dt valueForKey:@"time"];
    
    self.thumb.layer.borderColor = [[UIColor whiteColor] CGColor];
    self.thumb.layer.borderWidth = 1;
    self.txtContent.font = [UIFont rw_FontBoldWithSize:10];
    self.txtTime.font = [UIFont rw_FontBoldWithSize:9];
    
    CGSize maximumLabelSize = CGSizeMake(185, 200);
    
    CGSize expectedLabelSize = [self.txtContent.text sizeWithFont:self.txtContent.font constrainedToSize:maximumLabelSize lineBreakMode:self.txtContent.lineBreakMode];
    
    CGRect newFrame = self.txtContent.frame;
    newFrame.size.height = expectedLabelSize.height;
    self.txtContent.frame = newFrame;
    
    CGRect frameView = self.frame;
    frameView.size.height = 57;
    if(self.txtContent.frame.origin.y + self.txtContent.frame.size.height > 47)
    {
        frameView.size.height = self.txtContent.frame.origin.y + self.txtContent.frame.size.height + 25;
    }
    
    self.frame = frameView;
    
    CGRect frameBg = self.frame;
    frameBg.size.height = frameBg.size.height - 10;
    frameBg.size.width = 280;
    frameBg.origin.x = 10;
    frameBg.origin.y = 0;
    UIView *viewBg = [[UIView alloc] initWithFrame:self.frame];
    UIView *viewBgContent = [[UIView alloc] initWithFrame:frameBg];
    viewBgContent.backgroundColor = [UIColor colorFromHexString:@"#d7ebf7"];
    viewBgContent.layer.borderWidth = 1;
    viewBgContent.layer.borderColor = [[UIColor colorFromHexString:@"#096094"] CGColor];
    [viewBg addSubview:viewBgContent];
    
    UIView *viewBgHover = [[UIView alloc] initWithFrame:self.frame];
    UIView *viewBgHoverContent = [[UIView alloc] initWithFrame:frameBg];
    viewBgHoverContent.backgroundColor = [UIColor colorFromHexString:@"#baefaa"];
    viewBgHoverContent.layer.borderWidth = 1;
    viewBgHoverContent.layer.borderColor = [[UIColor colorFromHexString:@"#096094"] CGColor];
    [viewBgHover addSubview:viewBgHoverContent];
    
    
    [self setBackgroundView:viewBg];
    [self setSelectedBackgroundView:viewBgHover];
}

- (float) getHeight
{
    return self.frame.size.height;
}
@end
