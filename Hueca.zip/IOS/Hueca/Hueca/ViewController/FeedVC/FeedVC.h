//
//  FeedVC.h
//  Hueca
//
//  Created by NhiepPhong on 4/23/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CategorySelectBox.h"
#import "ViewHeader.h"
#import "CellItemFeed.h"
#import "CellFeedHeader.h"
#import "CustomIOS7AlertView.h"

@interface FeedVC : UIViewController<CategorySelectBoxDelegate, UITableViewDataSource, UITableViewDelegate, CellFeddHeaderDelegate, CustomIOS7AlertViewDelegate>
{
    CustomIOS7AlertView *popupLoading;
    ViewHeader *viewHeader;
    CellItemFeed *_stubCell;
    CellFeedHeader *cellHeader;
}
@property (weak, nonatomic) IBOutlet UIImageView *bg;
@property (weak, nonatomic) IBOutlet UITableView *table;
@property (weak, nonatomic) IBOutlet UIButton *btnRating;
@property (weak, nonatomic) IBOutlet UIButton *btnHuecas;
@property (weak, nonatomic) IBOutlet UIButton *btnPINS;
@property (weak, nonatomic) IBOutlet UIButton *btnSelectCate;
@property (weak, nonatomic) IBOutlet CategorySelectBox *viewSelectBox;

- (IBAction)onFilter:(UIButton *)sender;
- (IBAction)onOpenSelectCate:(UIButton *)sender;

@end
