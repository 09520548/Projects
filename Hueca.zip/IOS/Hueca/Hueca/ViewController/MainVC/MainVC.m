//
//  MainVC.m
//  Hueca
//
//  Created by NhiepPhong on 5/5/14.
//  Copyright (c) 2014 NHIEPPHONG. All rights reserved.
//

#import "MainVC.h"
#import "MMDrawerController.h"
#import "MMDrawerVisualState.h"
#import "HomeVC.h"
#import "SideMenuRightVC.h"

@interface MainVC ()

@end

@implementation MainVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
    
    }
    return self;
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    HomeVC *vc = [[HomeVC alloc] initWithNibName:@"HomeVC" bundle:nil];
    UINavigationController *navi = [[UINavigationController alloc] initWithRootViewController:vc];
    [navi.navigationBar setHidden:YES];
    SideMenuRightVC *rightSideMenuController = [[SideMenuRightVC alloc] initWithNibName:@"SideMenuRightVC" bundle:nil];
    UINavigationController *naviRight = [[UINavigationController alloc] initWithRootViewController:rightSideMenuController];
    [naviRight.navigationBar setHidden:YES];
    
    MMDrawerController *container = [[MMDrawerController alloc] initWithCenterViewController:navi leftDrawerViewController:nil rightDrawerViewController:naviRight];
    [container setOpenDrawerGestureModeMask:MMOpenDrawerGestureModeNone];
    [container setCloseDrawerGestureModeMask:MMCloseDrawerGestureModeAll];
    [container setDrawerVisualStateBlock:[MMDrawerVisualState swingingDoorVisualStateBlock]];
    
    UINavigationController* naviMain = [[UINavigationController alloc] initWithRootViewController:container];
    [naviMain.navigationBar setHidden:YES];
    [self presentViewController:naviMain animated:NO completion:nil];
    
    if([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    }
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
