//
//  BLCenterSideVC.m
//  ResumeBuildling
//
//  Created by Mobiz on 10/7/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import "BLCenterSideVC.h"
#import "UIViewController+MMDrawerController.h"
#import "BLEducationVC.h"
#import "BLExperiencesVC.h"
#import "BLExportVC.h"
#import "BLObjectiveVC.h"
#import "BLReferencesVC.h"
#import "BLSkillVC.h"
#import "BLTemplateVC.h"
#import "BLAppDelegate.h"
#import "Profile.h"

@interface BLCenterSideVC ()

@end

@implementation BLCenterSideVC


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UITapGestureRecognizer *tapGeusture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapHandler:)];
    tapGeusture.numberOfTapsRequired = 1;
    [self.view addGestureRecognizer:tapGeusture];
    
    [_txtLastName setValue:[UIColor whiteColor] forKeyPath:@"_placeholderLabel.textColor"];
    [_txtFirstName setValue:[UIColor whiteColor] forKeyPath:@"_placeholderLabel.textColor"];
    [_txtEmail setValue:[UIColor whiteColor] forKeyPath:@"_placeholderLabel.textColor"];
    [_txtPhone setValue:[UIColor whiteColor] forKeyPath:@"_placeholderLabel.textColor"];
    [_txtState setValue:[UIColor whiteColor] forKeyPath:@"_placeholderLabel.textColor"];
    [_txtStreet setValue:[UIColor whiteColor] forKeyPath:@"_placeholderLabel.textColor"];
    [_txtZip setValue:[UIColor whiteColor] forKeyPath:@"_placeholderLabel.textColor"];
    
    self.navigationController.navigationBarHidden = YES;
    self.lblTitle.text = @"Contact Info";
    
    //1
    BLAppDelegate* appDelegate = [UIApplication sharedApplication].delegate;
    //2
    self.managedObjectContext = appDelegate.managedObjectContext;
    
    [self getData];
    
    //    for (NSManagedObject *info in fetchedObjects) {
    //        NSLog(@"Name: %@", [info valueForKey:@"name"]);
    //        NSManagedObject *details = [info valueForKey:@"details"];
    //        NSLog(@"Zip: %@", [details valueForKey:@"zip"]);
    //    }
    
    
//    NSManagedObject *failedBankInfo = [NSEntityDescription
//                                       insertNewObjectForEntityForName:@"FailedBankInfo"
//                                       inManagedObjectContext:context];
//    [failedBankInfo setValue:@"Test Bank" forKey:@"name"];
//    [failedBankInfo setValue:@"Testville" forKey:@"city"];
//    [failedBankInfo setValue:@"Testland" forKey:@"state"];
//    NSManagedObject *failedBankDetails = [NSEntityDescription
//                                          insertNewObjectForEntityForName:@"FailedBankDetails"
//                                          inManagedObjectContext:context];
//    [failedBankDetails setValue:[NSDate date] forKey:@"closeDate"];
//    [failedBankDetails setValue:[NSDate date] forKey:@"updateDate"];
//    [failedBankDetails setValue:[NSNumber numberWithInt:12345] forKey:@"zip"];
//    [failedBankDetails setValue:failedBankInfo forKey:@"info"];
//    [failedBankInfo setValue:failedBankDetails forKey:@"details"];
//    if (![context save:&error]) {
//        NSLog(@"Whoops, couldn't save: %@", [error localizedDescription]);
//    }
    
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
    
    if (orientation == UIInterfaceOrientationLandscapeLeft || orientation == UIInterfaceOrientationLandscapeRight) {
        //        NSLog(@"landscape");
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
            [self.myScroll setContentSize:CGSizeMake(1, 1000)];
        }
        else if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
            [self.myScroll setContentSize:CGSizeMake(1, 2700)];
        }
    }
    else {
        //        NSLog(@"portrait");
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
            [self.myScroll setContentSize:CGSizeMake(1, 500)];
        }
        else if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
            [self.myScroll setContentSize:CGSizeMake(1, 500)];
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)tapHandler:(UIGestureRecognizer *)ges {
    [_txtEmail resignFirstResponder];
    [_txtFirstName resignFirstResponder];
    [_txtLastName resignFirstResponder];
    [_txtPhone resignFirstResponder];
    [_txtState resignFirstResponder];
    [_txtStreet resignFirstResponder];
    [_txtZip resignFirstResponder];
}

- (IBAction)showCat:(id)sender {
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}

- (IBAction)save:(id)sender {
    NSString *lastname = _txtLastName.text;
    NSString *firstname = _txtFirstName.text;
    NSString *email = _txtEmail.text;
    NSString *phone = _txtPhone.text;
    NSString *street = _txtStreet.text;
    NSString *state = _txtState.text;
    NSString *zip = _txtZip.text;
    
    if (![lastname isEqualToString:@""] && ![firstname isEqualToString:@""] && ![email isEqualToString:@""] && ![phone isEqualToString:@""] && ![street isEqualToString:@""] && ![state isEqualToString:@""] && ![zip isEqualToString:@""]) {
        [self addData];
    }
    else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Please input all fields before continue" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
}

- (void)selectCategory:(int)ID {
    switch (ID) {
        case 0:
            [self.navigationController popToRootViewControllerAnimated:YES];
            break;
        case 1: {
            BLObjectiveVC *objectiveVC = [[BLObjectiveVC alloc] initWithNibName:@"BLObjectiveVC" bundle:nil];
            [self.navigationController pushViewController:objectiveVC animated:YES];
        }
            break;
        case 2: {
            BLExperiencesVC *experienceVC = [[BLExperiencesVC alloc] initWithNibName:@"BLExperiencesVC" bundle:nil];
            [self.navigationController pushViewController:experienceVC animated:YES];
        }
            break;
        case 3: {
            BLEducationVC *educationVC = [[BLEducationVC alloc] initWithNibName:@"BLEducationVC" bundle:nil];
            [self.navigationController pushViewController:educationVC animated:YES];
        }
            break;
        case 4: {
            BLSkillVC *skillVC = [[BLSkillVC alloc] initWithNibName:@"BLSkillVC" bundle:nil];
            [self.navigationController pushViewController:skillVC animated:YES];
        }
            break;
        case 5: {
            BLReferencesVC *referenceVC = [[BLReferencesVC alloc] initWithNibName:@"BLReferencesVC" bundle:nil];
            [self.navigationController pushViewController:referenceVC animated:YES];
        }
            break;
        case 6: {
            BLExportVC *exportVC = [[BLExportVC alloc] initWithNibName:@"BLExportVC" bundle:nil];
            [self.navigationController pushViewController:exportVC animated:YES];
        }
            break;
        case 7: {
            BLTemplateVC *templateVC = [[BLTemplateVC alloc] initWithNibName:@"BLTemplateVC" bundle:nil];
            [self.navigationController pushViewController:templateVC animated:YES];
        }
            break;
        default:
            break;
    }
}

- (void)addData {
    
    // initializing NSFetchRequest
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    
    //Setting Entity to be Queried
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Profile"
                                              inManagedObjectContext:self.managedObjectContext];
    [fetchRequest setEntity:entity];
    NSError* error;
    
    // Query on managedObjectContext With Generated fetchRequest
    NSArray *fetchedRecords = [self.managedObjectContext executeFetchRequest:fetchRequest error:&error];
    
    if (fetchedRecords.count > 0) {
        Profile *profile = [fetchedRecords objectAtIndex:0];
        profile.lastname = _txtLastName.text;
        profile.firstname = _txtFirstName.text;
        profile.emai = _txtEmail.text;
        profile.phone = _txtPhone.text;
        profile.street = _txtStreet.text;
        profile.state = _txtState.text;
        profile.zip = _txtZip.text;
        
        NSError *error;
        if (![self.managedObjectContext save:&error]) {
            NSLog(@"Whoops, couldn't save: %@", [error localizedDescription]);
        }
        else {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success" message:@"Data has been saved" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alert show];
        }
        
        
    }
    else {
        //  1
        Profile * newEntry = [NSEntityDescription insertNewObjectForEntityForName:@"Profile" inManagedObjectContext:self.managedObjectContext];
        //  2
        newEntry.id = @"0";
        newEntry.emai = _txtEmail.text;
        newEntry.firstname = _txtFirstName.text;
        newEntry.lastname = _txtLastName.text;
        newEntry.phone = _txtPhone.text;
        newEntry.state = _txtState.text;
        newEntry.street = _txtStreet.text;
        newEntry.zip = _txtZip.text;
        
        //  3
        NSError *error;
        if (![self.managedObjectContext save:&error]) {
            NSLog(@"Whoops, couldn't save: %@", [error localizedDescription]);
        }
        else {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success" message:@"Data has been saved" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alert show];
        }
    }
    
    
}

- (void)getData {
    // initializing NSFetchRequest
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    
    //Setting Entity to be Queried
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Profile"
                                              inManagedObjectContext:self.managedObjectContext];
    [fetchRequest setEntity:entity];
    NSError* error;
    
    // Query on managedObjectContext With Generated fetchRequest
    NSArray *fetchedRecords = [self.managedObjectContext executeFetchRequest:fetchRequest error:&error];
    
    if (fetchedRecords.count > 0) {
        Profile *profile = [fetchedRecords objectAtIndex:0];
        _txtLastName.text = profile.lastname;
        _txtFirstName.text = profile.firstname;
        _txtEmail.text = profile.emai;
        _txtPhone.text = profile.phone;
        _txtStreet.text = profile.street;
        _txtState.text = profile.state;
        _txtZip.text = profile.zip;
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    return [textField resignFirstResponder];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    if (fromInterfaceOrientation == UIInterfaceOrientationLandscapeLeft || fromInterfaceOrientation == UIInterfaceOrientationLandscapeRight) {
        //        NSLog(@"portrait");
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
            [self.myScroll setContentSize:CGSizeMake(1, 500)];
        }
        else if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
            [self.myScroll setContentSize:CGSizeMake(1, 500)];
        }
    }
    else {
        //        NSLog(@"lanscape");
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
            [self.myScroll setContentSize:CGSizeMake(1, 1000)];
        }
        else if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
            [self.myScroll setContentSize:CGSizeMake(1, 2700)];
        }
    }
}

@end
