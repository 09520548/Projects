//
//  BLObjectiveVC.h
//  ResumeBuildling
//
//  Created by Mobiz on 10/7/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BLCustomAlertView.h"
#import "BLCustomAlertView2.h"

@interface BLObjectiveVC : UIViewController <UITableViewDataSource, UITableViewDelegate, BLCustomAlertViewDelegate, UIAlertViewDelegate, BLCustomAlertView2Delegate> {
    NSMutableArray *arrData;
    NSInteger totalItem;
    NSInteger currSelected;
}
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@property (weak, nonatomic) IBOutlet UITableView *myTableView;
@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;

- (IBAction)showCat:(id)sender;
- (IBAction)addNew:(id)sender;
- (IBAction)save:(id)sender;
@end
