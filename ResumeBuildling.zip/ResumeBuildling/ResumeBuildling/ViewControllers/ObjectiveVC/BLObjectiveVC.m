//
//  BLObjectiveVC.m
//  ResumeBuildling
//
//  Created by Mobiz on 10/7/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import "BLObjectiveVC.h"
#import "UIViewController+MMDrawerController.h"
#import "BLAppDelegate.h"
#import "Obj.h"

@interface BLObjectiveVC ()

@end

@implementation BLObjectiveVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.myTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    
    self.lblTitle.text = @"Objective";
    arrData = [[NSMutableArray alloc] init];
    
    BLAppDelegate* appDelegate = [UIApplication sharedApplication].delegate;
    self.managedObjectContext = appDelegate.managedObjectContext;
    [self getData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)showCat:(id)sender {
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}

- (IBAction)addNew:(id)sender {
    [[BLGlobal getInstance] showAlertInputAtView:self.view withPlaceData:@[@"Detail"]];
    [BLGlobal getInstance].customAlert.delegate = self;
}

- (IBAction)save:(id)sender {
    NSError *error;
    if (![self.managedObjectContext save:&error]) {
        NSLog(@"Whoops, couldn't save: %@", [error localizedDescription]);
    }
    else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success" message:@"Data has been saved" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
}

- (void)didClickButtonAtIndex:(NSInteger)index {
    [[BLGlobal getInstance] hideAlertView];
    if (index == 0) {
        NSString *detail = [BLGlobal getInstance].customAlert.txt1.text;
        
        if (![detail isEqualToString:@""]) {
            //  1
            Obj * newEntry = [NSEntityDescription insertNewObjectForEntityForName:@"Obj" inManagedObjectContext:self.managedObjectContext];
            //  2
            newEntry.id = [NSString stringWithFormat:@"%ld", (long)(totalItem)];
            newEntry.detail = detail;
            newEntry.position = @"";
            newEntry.company = @"";
            
            [arrData addObject:newEntry];
            
            totalItem = arrData.count;
            
        }
        
        [self.myTableView reloadData];
    }
}

- (void)getData {
    // initializing NSFetchRequest
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    
    //Setting Entity to be Queried
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Obj"
                                              inManagedObjectContext:self.managedObjectContext];
    [fetchRequest setEntity:entity];
    NSError* error;
    
    // Query on managedObjectContext With Generated fetchRequest
    NSArray *fetchedRecords = [self.managedObjectContext executeFetchRequest:fetchRequest error:&error];
    
    if (fetchedRecords.count > 0) {
        for (Obj *obj in fetchedRecords) {
            [arrData addObject:obj];
        }
    }
    
    totalItem = arrData.count;
    
    [self.myTableView reloadData];
}

#pragma mark - TABLE
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return arrData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = (UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
        cell.backgroundColor = [UIColor clearColor];
        cell.textLabel.textColor = [UIColor whiteColor];
        cell.detailTextLabel.textColor = [UIColor whiteColor];
    }
    
    Obj *curData = [arrData objectAtIndex:indexPath.row];
    cell.textLabel.text = curData.detail;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    currSelected = indexPath.row;
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Delete Data" message:@"Are you sure to delete this data?" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Delete", @"Edit", nil];
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if ([alertView.title isEqualToString:@"Delete Data"]) {
        if (buttonIndex == 1) {
            [self.managedObjectContext deleteObject:[arrData objectAtIndex:currSelected]];
            [arrData removeObjectAtIndex:currSelected];
            NSError *error;
            if (![self.managedObjectContext save:&error]) {
                NSLog(@"Whoops, couldn't delete: %@", [error localizedDescription]);
            }
            else {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success" message:@"Data has been deleted" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                [alert show];
            }
            [self.myTableView reloadData];
        }
        else if (buttonIndex == 2) {
            Obj *curData = [arrData objectAtIndex:currSelected];
            [[BLGlobal getInstance] showAlertInputAtView:self.view withPlaceData:@[curData.detail] placeholder:@[@"Detail"]];
            [BLGlobal getInstance].customAlert2.delegate = self;
        }
    }
}

- (void)didClickButtonAtIndex2:(NSInteger)index {
    [[BLGlobal getInstance] hideAlertView];
    if (index == 0) {
        NSString *detail = [BLGlobal getInstance].customAlert2.txt1.text;
        
        if (![detail isEqualToString:@""]) {
            
            Obj * newEntry = [arrData objectAtIndex:currSelected];
            newEntry.detail = detail;
            newEntry.position = @"";
            newEntry.company = @"";
            
            
            [self save:nil];
            arrData = nil;
            arrData = [NSMutableArray new];
            [self getData];
            [self.myTableView reloadData];
        }
        
        
    }
}
@end
