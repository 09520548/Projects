//
//  BLCustomAlertView2.h
//  ResumeBuildling
//
//  Created by Mobiz on 10/13/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol BLCustomAlertView2Delegate <NSObject>

@optional
- (void)didClickButtonAtIndex2:(NSInteger)index;

@end

@interface BLCustomAlertView2 : UIView <UITextFieldDelegate>

@property (retain, nonatomic) UITextField *txt1;
@property (retain, nonatomic) UITextField *txt2;
@property (retain, nonatomic) UITextField *txt3;
@property (retain, nonatomic) UITextField *txt4;

@property (assign) id<BLCustomAlertView2Delegate> delegate;

- (id)initWithNumberOfInputText:(NSInteger)number inView:(UIView *)view andData:(NSArray *)arrData placeHolder:(NSArray *)placeholder;

@end
