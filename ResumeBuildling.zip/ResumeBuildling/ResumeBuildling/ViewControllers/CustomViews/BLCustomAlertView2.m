//
//  BLCustomAlertView2.m
//  ResumeBuildling
//
//  Created by Mobiz on 10/13/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import "BLCustomAlertView2.h"

@implementation BLCustomAlertView2

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (id)initWithNumberOfInputText:(NSInteger)number inView:(UIView *)view andData:(NSArray *)arrData placeHolder:(NSArray *)placeholder {
    self = [super initWithFrame:CGRectMake(view.frame.size.width/2-150, view.frame.size.height/2-150, 300, 300)];
    
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        UILabel *lblTitle = [[UILabel alloc] initWithFrame:CGRectMake(0, 10, 300, 21)];
        lblTitle.text = @"Edit Data";
        lblTitle.textColor = [UIColor blackColor];
        lblTitle.textAlignment = NSTextAlignmentCenter;
        [self addSubview:lblTitle];
        
        
        
        if (number == 1) {
            self.frame = CGRectMake(view.frame.size.width/2-150, view.frame.size.height/2-150, 300, 150);
            
            _txt1 = [[UITextField alloc] initWithFrame:CGRectMake(5, lblTitle.frame.origin.x + lblTitle.frame.size.height + 30, 290, 30)];
            _txt1.placeholder = [placeholder objectAtIndex:0];
            _txt1.text = [arrData objectAtIndex:0];
            [_txt1 setBorderStyle:UITextBorderStyleLine];
            [_txt1 setValue:[UIColor grayColor] forKeyPath:@"_placeholderLabel.textColor"];
            [_txt1 setTextColor:[UIColor blackColor]];
            [self addSubview:_txt1];
            _txt1.delegate = self;
            
            UIButton *btnOK = [UIButton buttonWithType:UIButtonTypeCustom];
            btnOK.frame = CGRectMake(5, _txt1.frame.origin.y + _txt1.frame.size.height + 20, 140, 40);
            [btnOK setTitle:@"OK" forState:UIControlStateNormal];
            [btnOK setBackgroundColor:[UIColor grayColor]];
            btnOK.tag = 0;
            [btnOK addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:btnOK];
            
            UIButton *btnCancel = [UIButton buttonWithType:UIButtonTypeCustom];
            btnCancel.frame = CGRectMake(155, _txt1.frame.origin.y + _txt1.frame.size.height + 20, 140, 40);
            [btnCancel setTitle:@"Cancel" forState:UIControlStateNormal];
            [btnCancel setBackgroundColor:[UIColor grayColor]];
            btnCancel.tag = 1;
            [btnCancel addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:btnCancel];
            
        }
        else if (number == 2) {
            self.frame = CGRectMake(view.frame.size.width/2-150, view.frame.size.height/2-150, 300, 180);
            
            _txt1 = [[UITextField alloc] initWithFrame:CGRectMake(5, lblTitle.frame.origin.y + lblTitle.frame.size.height + 10, 290, 30)];
            _txt1.placeholder = [placeholder objectAtIndex:0];
            _txt1.text = [arrData objectAtIndex:0];
            [_txt1 setBorderStyle:UITextBorderStyleLine];
            [_txt1 setValue:[UIColor grayColor] forKeyPath:@"_placeholderLabel.textColor"];
            [_txt1 setTextColor:[UIColor blackColor]];
            [self addSubview:_txt1];
            
            _txt2 = [[UITextField alloc] initWithFrame:CGRectMake(5, _txt1.frame.origin.y + _txt1.frame.size.height + 10, 290, 30)];
            _txt2.placeholder = [placeholder objectAtIndex:1];
            _txt2.text = [arrData objectAtIndex:1];
            [_txt2 setBorderStyle:UITextBorderStyleLine];
            [_txt2 setValue:[UIColor grayColor] forKeyPath:@"_placeholderLabel.textColor"];
            [_txt2 setTextColor:[UIColor blackColor]];
            [self addSubview:_txt2];
            
            UIButton *btnOK = [UIButton buttonWithType:UIButtonTypeCustom];
            btnOK.frame = CGRectMake(5, _txt2.frame.origin.y + _txt2.frame.size.height + 20, 140, 40);
            [btnOK setTitle:@"OK" forState:UIControlStateNormal];
            [btnOK setBackgroundColor:[UIColor grayColor]];
            btnOK.tag = 0;
            [btnOK addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:btnOK];
            
            UIButton *btnCancel = [UIButton buttonWithType:UIButtonTypeCustom];
            btnCancel.frame = CGRectMake(155, _txt2.frame.origin.y + _txt2.frame.size.height + 20, 140, 40);
            [btnCancel setTitle:@"Cancel" forState:UIControlStateNormal];
            [btnCancel setBackgroundColor:[UIColor grayColor]];
            btnCancel.tag = 1;
            [btnCancel addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:btnCancel];
            
            _txt1.delegate = self;
            _txt2.delegate = self;
        }
        else if (number == 3) {
            self.frame = CGRectMake(view.frame.size.width/2-150, view.frame.size.height/2-150, 300, 230);
            
            _txt1 = [[UITextField alloc] initWithFrame:CGRectMake(5, lblTitle.frame.origin.y + lblTitle.frame.size.height + 10, 290, 30)];
            _txt1.placeholder = [placeholder objectAtIndex:0];
            _txt1.text = [arrData objectAtIndex:0];
            [_txt1 setBorderStyle:UITextBorderStyleLine];
            [_txt1 setValue:[UIColor grayColor] forKeyPath:@"_placeholderLabel.textColor"];
            [_txt1 setTextColor:[UIColor blackColor]];
            [self addSubview:_txt1];
            
            _txt2 = [[UITextField alloc] initWithFrame:CGRectMake(5, _txt1.frame.origin.y + _txt1.frame.size.height + 10, 290, 30)];
            _txt2.placeholder = [placeholder objectAtIndex:1];
            _txt2.text = [arrData objectAtIndex:1];
            [_txt2 setBorderStyle:UITextBorderStyleLine];
            [_txt2 setValue:[UIColor grayColor] forKeyPath:@"_placeholderLabel.textColor"];
            [_txt2 setTextColor:[UIColor blackColor]];
            [self addSubview:_txt2];
            
            _txt3 = [[UITextField alloc] initWithFrame:CGRectMake(5, _txt2.frame.origin.y + _txt2.frame.size.height + 10, 290, 30)];
            _txt3.placeholder = [placeholder objectAtIndex:2];
            _txt3.text = [arrData objectAtIndex:2];
            [_txt3 setBorderStyle:UITextBorderStyleLine];
            [_txt3 setValue:[UIColor grayColor] forKeyPath:@"_placeholderLabel.textColor"];
            [_txt3 setTextColor:[UIColor blackColor]];
            [self addSubview:_txt3];
            
            UIButton *btnOK = [UIButton buttonWithType:UIButtonTypeCustom];
            btnOK.frame = CGRectMake(5, _txt3.frame.origin.y + _txt3.frame.size.height + 20, 140, 40);
            [btnOK setTitle:@"OK" forState:UIControlStateNormal];
            [btnOK setBackgroundColor:[UIColor grayColor]];
            btnOK.tag = 0;
            [btnOK addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:btnOK];
            
            UIButton *btnCancel = [UIButton buttonWithType:UIButtonTypeCustom];
            btnCancel.frame = CGRectMake(155, _txt3.frame.origin.y + _txt3.frame.size.height + 20, 140, 40);
            [btnCancel setTitle:@"Cancel" forState:UIControlStateNormal];
            [btnCancel setBackgroundColor:[UIColor grayColor]];
            btnCancel.tag = 1;
            [btnCancel addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:btnCancel];
            
            _txt1.delegate = self;
            _txt2.delegate = self;
            _txt3.delegate = self;
        }
        
        else if (number == 4) {
            _txt1 = [[UITextField alloc] initWithFrame:CGRectMake(5, lblTitle.frame.origin.y + lblTitle.frame.size.height + 10, 290, 30)];
            _txt1.placeholder = [placeholder objectAtIndex:0];
            _txt1.text = [arrData objectAtIndex:0];
            [_txt1 setBorderStyle:UITextBorderStyleLine];
            [_txt1 setValue:[UIColor grayColor] forKeyPath:@"_placeholderLabel.textColor"];
            [_txt1 setTextColor:[UIColor blackColor]];
            [self addSubview:_txt1];
            
            _txt2 = [[UITextField alloc] initWithFrame:CGRectMake(5, _txt1.frame.origin.y + _txt1.frame.size.height + 10, 290, 30)];
            _txt2.placeholder = [placeholder objectAtIndex:1];
            _txt2.text = [arrData objectAtIndex:1];
            [_txt2 setBorderStyle:UITextBorderStyleLine];
            [_txt2 setValue:[UIColor grayColor] forKeyPath:@"_placeholderLabel.textColor"];
            [_txt2 setTextColor:[UIColor blackColor]];
            [self addSubview:_txt2];
            
            _txt3 = [[UITextField alloc] initWithFrame:CGRectMake(5, _txt2.frame.origin.y + _txt2.frame.size.height + 10, 290, 30)];
            _txt3.placeholder = [placeholder objectAtIndex:2];
            _txt3.text = [arrData objectAtIndex:2];
            [_txt3 setBorderStyle:UITextBorderStyleLine];
            [_txt3 setValue:[UIColor grayColor] forKeyPath:@"_placeholderLabel.textColor"];
            [_txt3 setTextColor:[UIColor blackColor]];
            [self addSubview:_txt3];
            
            _txt4 = [[UITextField alloc] initWithFrame:CGRectMake(5, _txt3.frame.origin.y + _txt3.frame.size.height + 10, 290, 30)];
            _txt4.placeholder = [placeholder objectAtIndex:3];
            _txt4.text = [arrData objectAtIndex:3];
            [_txt4 setBorderStyle:UITextBorderStyleLine];
            [_txt4 setValue:[UIColor grayColor] forKeyPath:@"_placeholderLabel.textColor"];
            [_txt4 setTextColor:[UIColor blackColor]];
            [self addSubview:_txt4];
            
            UIButton *btnOK = [UIButton buttonWithType:UIButtonTypeCustom];
            btnOK.frame = CGRectMake(5, _txt4.frame.origin.y + _txt4.frame.size.height + 20, 140, 40);
            [btnOK setTitle:@"OK" forState:UIControlStateNormal];
            [btnOK setBackgroundColor:[UIColor grayColor]];
            btnOK.tag = 0;
            [btnOK addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:btnOK];
            
            UIButton *btnCancel = [UIButton buttonWithType:UIButtonTypeCustom];
            btnCancel.frame = CGRectMake(155, _txt4.frame.origin.y + _txt4.frame.size.height + 20, 140, 40);
            [btnCancel setTitle:@"Cancel" forState:UIControlStateNormal];
            [btnCancel setBackgroundColor:[UIColor grayColor]];
            btnCancel.tag = 1;
            [btnCancel addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:btnCancel];
            
            _txt1.delegate = self;
            _txt2.delegate = self;
            _txt3.delegate = self;
            _txt4.delegate = self;
        }
    }
    
    return self;
}

- (IBAction)btnClicked:(id)sender {
    [self.delegate didClickButtonAtIndex2:[sender tag]];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    return [textField resignFirstResponder];
}

@end
