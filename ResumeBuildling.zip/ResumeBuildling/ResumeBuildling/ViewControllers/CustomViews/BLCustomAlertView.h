//
//  BLCustomAlertView.h
//  ResumeBuildling
//
//  Created by Mobiz on 10/7/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol BLCustomAlertViewDelegate <NSObject>

@optional
- (void)didClickButtonAtIndex:(NSInteger)index;

@end

@interface BLCustomAlertView : UIView <UITextFieldDelegate>

@property (retain, nonatomic) UITextField *txt1;
@property (retain, nonatomic) UITextField *txt2;
@property (retain, nonatomic) UITextField *txt3;
@property (retain, nonatomic) UITextField *txt4;

@property (assign) id<BLCustomAlertViewDelegate> delegate;

- (id)initWithNumberOfInputText:(NSInteger)number inView:(UIView *)view andData:(NSArray *)arrData;

@end
