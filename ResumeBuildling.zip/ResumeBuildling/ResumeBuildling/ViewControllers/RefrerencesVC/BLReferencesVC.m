//
//  BLReferencesVC.m
//  ResumeBuildling
//
//  Created by Mobiz on 10/7/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import "BLReferencesVC.h"
#import "UIViewController+MMDrawerController.h"
#import "BLAppDelegate.h"
#import "Ref.h"
#import "BLEducationCell.h"

@interface BLReferencesVC ()

@end

@implementation BLReferencesVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.myTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    
    self.lblTitle.text = @"References";
    arrData = [[NSMutableArray alloc] init];
    
    BLAppDelegate* appDelegate = [UIApplication sharedApplication].delegate;
    self.managedObjectContext = appDelegate.managedObjectContext;
    [self getData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)showCat:(id)sender {
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}

- (IBAction)save:(id)sender {
    NSError *error;
    if (![self.managedObjectContext save:&error]) {
        NSLog(@"Whoops, couldn't save: %@", [error localizedDescription]);
    }
    else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success" message:@"Data has been saved" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
}

- (IBAction)addNew:(id)sender {
    [[BLGlobal getInstance] showAlertInputAtView:self.view withPlaceData:@[@"Name", @"Company", @"Detail"]];
    [BLGlobal getInstance].customAlert.delegate = self;
}

- (void)didClickButtonAtIndex:(NSInteger)index {
    [[BLGlobal getInstance] hideAlertView];
    if (index == 0) {
        NSString *name = [BLGlobal getInstance].customAlert.txt1.text;
        NSString *company = [BLGlobal getInstance].customAlert.txt2.text;
        NSString *detail = [BLGlobal getInstance].customAlert.txt3.text;
        
        if (![name isEqualToString:@""] && ![company isEqualToString:@""] && ![detail isEqualToString:@""]) {
            //  1
            Ref * newEntry = [NSEntityDescription insertNewObjectForEntityForName:@"Ref" inManagedObjectContext:self.managedObjectContext];
            //  2
            newEntry.id = [NSString stringWithFormat:@"%ld", (long)(totalItem)];
            newEntry.detail = detail;
            newEntry.company = company;
            newEntry.name = name;
            
            [arrData addObject:newEntry];
            
            totalItem = arrData.count;
            
        }
        
        [self.myTableView reloadData];
    }
}

- (void)getData {
    // initializing NSFetchRequest
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    
    //Setting Entity to be Queried
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Ref"
                                              inManagedObjectContext:self.managedObjectContext];
    [fetchRequest setEntity:entity];
    NSError* error;
    
    // Query on managedObjectContext With Generated fetchRequest
    NSArray *fetchedRecords = [self.managedObjectContext executeFetchRequest:fetchRequest error:&error];
    
    if (fetchedRecords.count > 0) {
        for (Ref *ref in fetchedRecords) {
            [arrData addObject:ref];
        }
    }
    
    totalItem = arrData.count;
    
    [self.myTableView reloadData];
}

#pragma mark - TABLE
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return arrData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *simpleTableIdentifier = @"BLEducationCell";
    
    BLEducationCell *cell = (BLEducationCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"BLEducationCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    Ref *curData = [arrData objectAtIndex:indexPath.row];
    cell.lblSchool.text = [NSString stringWithFormat:@"Name: %@", curData.name];
    cell.lblBranch.text = [NSString stringWithFormat:@"Company: %@", curData.company];
    cell.lblDate.text = curData.detail;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    currSelected = indexPath.row;
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Delete Data" message:@"Are you sure to delete this data?" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Delete", @"Edit", nil];
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if ([alertView.title isEqualToString:@"Delete Data"]) {
        if (buttonIndex == 1) {
            [self.managedObjectContext deleteObject:[arrData objectAtIndex:currSelected]];
            [arrData removeObjectAtIndex:currSelected];
            NSError *error;
            if (![self.managedObjectContext save:&error]) {
                NSLog(@"Whoops, couldn't delete: %@", [error localizedDescription]);
            }
            else {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success" message:@"Data has been deleted" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                [alert show];
            }
            [self.myTableView reloadData];
        }
        else if (buttonIndex == 2) {
            Ref *curData = [arrData objectAtIndex:currSelected];
            [[BLGlobal getInstance] showAlertInputAtView:self.view withPlaceData:@[curData.name, curData.company, curData.detail] placeholder:@[@"Name", @"Company", @"Detail"]];
            [BLGlobal getInstance].customAlert2.delegate = self;
        }
    }
}

- (void)didClickButtonAtIndex2:(NSInteger)index {
    [[BLGlobal getInstance] hideAlertView];
    if (index == 0) {
        NSString *name = [BLGlobal getInstance].customAlert2.txt1.text;
        NSString *company = [BLGlobal getInstance].customAlert2.txt2.text;
        NSString *detail = [BLGlobal getInstance].customAlert2.txt3.text;
        
        if (![name isEqualToString:@""] && ![company isEqualToString:@""] && ![detail isEqualToString:@""]) {
            
            Ref * newEntry = [arrData objectAtIndex:currSelected];
            //  2
            newEntry.detail = detail;
            newEntry.company = company;
            newEntry.name = name;
            
            
            [self save:nil];
            arrData = nil;
            arrData = [NSMutableArray new];
            [self getData];
            [self.myTableView reloadData];
        }
        
        
    }
}
@end
