//
//  BLEducationVC.m
//  ResumeBuildling
//
//  Created by Mobiz on 10/7/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import "BLEducationVC.h"
#import "UIViewController+MMDrawerController.h"
#import "BLAppDelegate.h"
#import "Edu.h"
#import "BLEducationCell.h"

@interface BLEducationVC ()

@end

@implementation BLEducationVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.myTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    
    self.lblTitle.text = @"Education";
    
    arrData = [[NSMutableArray alloc] init];
    
    BLAppDelegate* appDelegate = [UIApplication sharedApplication].delegate;
    self.managedObjectContext = appDelegate.managedObjectContext;
    [self getData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)showCat:(id)sender {
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}

- (IBAction)save:(id)sender {
    NSError *error;
    if (![self.managedObjectContext save:&error]) {
        NSLog(@"Whoops, couldn't save: %@", [error localizedDescription]);
    }
    else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success" message:@"Data has been saved" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
}

- (IBAction)addNew:(id)sender {
    [[BLGlobal getInstance] showAlertInputAtView:self.view withPlaceData:@[@"School Name", @"Branch", @"From Date", @"To Date"]];
    [BLGlobal getInstance].customAlert.delegate = self;
}

- (void)didClickButtonAtIndex:(NSInteger)index {
    [[BLGlobal getInstance] hideAlertView];
    if (index == 0) {
        NSString *schoolName = [BLGlobal getInstance].customAlert.txt1.text;
        NSString *brach = [BLGlobal getInstance].customAlert.txt2.text;
        NSString *fromDate = [BLGlobal getInstance].customAlert.txt3.text;
        NSString *toDate = [BLGlobal getInstance].customAlert.txt4.text;

        if (![schoolName isEqualToString:@""] && ![brach isEqualToString:@""] && ![fromDate isEqualToString:@""] && ![toDate isEqualToString:@""]) {
            //  1
            Edu * newEntry = [NSEntityDescription insertNewObjectForEntityForName:@"Edu" inManagedObjectContext:self.managedObjectContext];
            //  2
            newEntry.id = [NSString stringWithFormat:@"%ld", (long)(totalItem)];
            newEntry.name = schoolName;
            newEntry.specific = brach;
            newEntry.fromDate = fromDate;
            newEntry.toDate = toDate;
            
            [arrData addObject:newEntry];
            
            totalItem = arrData.count;
            
        }
        
        [self.myTableView reloadData];
    }
}

- (void)getData {
    // initializing NSFetchRequest
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    
    //Setting Entity to be Queried
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Edu"
                                              inManagedObjectContext:self.managedObjectContext];
    [fetchRequest setEntity:entity];
    NSError* error;
    
    // Query on managedObjectContext With Generated fetchRequest
    NSArray *fetchedRecords = [self.managedObjectContext executeFetchRequest:fetchRequest error:&error];
    
    if (fetchedRecords.count > 0) {
        for (Edu *edu in fetchedRecords) {
            [arrData addObject:edu];
        }
    }
    
    totalItem = arrData.count;
    
    [self.myTableView reloadData];
}

#pragma mark - TABLE
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return arrData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
//    UITableViewCell *cell = (UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"cell"];
//    if (cell == nil) {
//        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"cell"];
//        cell.backgroundColor = [UIColor clearColor];
//        cell.textLabel.textColor = [UIColor whiteColor];
//        cell.detailTextLabel.textColor = [UIColor whiteColor];
//    }
    
    static NSString *simpleTableIdentifier = @"BLEducationCell";
    
    BLEducationCell *cell = (BLEducationCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"BLEducationCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }

    
    Edu *curData = [arrData objectAtIndex:indexPath.row];
    cell.lblSchool.text = [NSString stringWithFormat:@"School: %@", curData.name];
    cell.lblBranch.text = [NSString stringWithFormat:@"Branch: %@", curData.specific];
    cell.lblDate.text = [NSString stringWithFormat:@"From: %@ To: %@", curData.fromDate, curData.toDate];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    currSelected = indexPath.row;
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Delete Data" message:@"Are you sure to delete this data?" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Delete", @"Edit", nil];
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if ([alertView.title isEqualToString:@"Delete Data"]) {
        if (buttonIndex == 1) {
            [self.managedObjectContext deleteObject:[arrData objectAtIndex:currSelected]];
            [arrData removeObjectAtIndex:currSelected];
            NSError *error;
            if (![self.managedObjectContext save:&error]) {
                NSLog(@"Whoops, couldn't delete: %@", [error localizedDescription]);
            }
            else {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success" message:@"Data has been deleted" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                [alert show];
            }
            [self.myTableView reloadData];
        }
        else if (buttonIndex == 2) {
            Edu *curData = [arrData objectAtIndex:currSelected];
            [[BLGlobal getInstance] showAlertInputAtView:self.view withPlaceData:@[curData.name, curData.specific, curData.fromDate, curData.toDate] placeholder:@[@"School Name", @"Branch", @"From Date", @"To Date"]];
            [BLGlobal getInstance].customAlert2.delegate = self;
        }
    }
}

- (void)didClickButtonAtIndex2:(NSInteger)index {
    [[BLGlobal getInstance] hideAlertView];
    if (index == 0) {
        NSString *schoolName = [BLGlobal getInstance].customAlert2.txt1.text;
        NSString *brach = [BLGlobal getInstance].customAlert2.txt2.text;
        NSString *fromDate = [BLGlobal getInstance].customAlert2.txt3.text;
        NSString *toDate = [BLGlobal getInstance].customAlert2.txt4.text;
        
        if (![schoolName isEqualToString:@""] && ![brach isEqualToString:@""] && ![fromDate isEqualToString:@""] && ![toDate isEqualToString:@""]) {
            Edu * newEntry = [arrData objectAtIndex:currSelected];
            newEntry.name = schoolName;
            newEntry.specific = brach;
            newEntry.fromDate = fromDate;
            newEntry.toDate = toDate;
            
            [self save:nil];
            arrData = nil;
            arrData = [NSMutableArray new];
            [self getData];
            [self.myTableView reloadData];
            
        }
        
        
    }
}
@end
