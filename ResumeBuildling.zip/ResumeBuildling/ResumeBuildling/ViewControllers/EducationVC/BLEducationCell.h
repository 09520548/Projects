//
//  BLEducationCell.h
//  ResumeBuildling
//
//  Created by Mobiz on 10/13/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BLEducationCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *lblSchool;
@property (weak, nonatomic) IBOutlet UILabel *lblBranch;
@property (weak, nonatomic) IBOutlet UILabel *lblDate;
@end
