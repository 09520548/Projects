//
//  BLLeftSideVC.m
//  ResumeBuildling
//
//  Created by Mobiz on 10/7/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import "BLLeftSideVC.h"
#import "UIViewController+MMDrawerController.h"

@interface BLLeftSideVC ()

@end

@implementation BLLeftSideVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.myTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    
    NSDictionary *dic1 = [[NSDictionary alloc] initWithObjectsAndKeys:@"Contact Info", @"title", @"Your basic information", @"detail", @"img_profile", @"icon", nil];
    NSDictionary *dic2 = [[NSDictionary alloc] initWithObjectsAndKeys:@"Objective", @"title", @"Your profesional goals", @"detail", @"img_objective", @"icon", nil];
    NSDictionary *dic3 = [[NSDictionary alloc] initWithObjectsAndKeys:@"Experience", @"title", @"Your work history", @"detail", @"img_exp", @"icon", nil];
    NSDictionary *dic4 = [[NSDictionary alloc] initWithObjectsAndKeys:@"Education", @"title", @"Your education background", @"detail", @"img_education", @"icon", nil];
    NSDictionary *dic5 = [[NSDictionary alloc] initWithObjectsAndKeys:@"Skills", @"title", @"A list of keywords that", @"detail", @"img_skills", @"icon", nil];
    NSDictionary *dic6 = [[NSDictionary alloc] initWithObjectsAndKeys:@"References", @"title", @"People you worked with in", @"detail", @"img_ref", @"icon", nil];
    NSDictionary *dic7 = [[NSDictionary alloc] initWithObjectsAndKeys:@"Export", @"title", @"Export your resume", @"detail", @"img_export", @"icon", nil];
    NSDictionary *dic8 = [[NSDictionary alloc] initWithObjectsAndKeys:@"Template", @"title", @"Choose template style", @"detail", @"img_theme", @"icon", nil];
    
    arrData = [NSArray arrayWithObjects:dic1, dic2, dic3, dic4, dic5, dic6, dic7, dic8, nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - TABLEVIEW
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return arrData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"cell"];
        cell.backgroundColor = [UIColor clearColor];
        cell.textLabel.textColor = [UIColor whiteColor];
        cell.detailTextLabel.textColor = [UIColor whiteColor];
    }
    
    if (arrData.count > 0) {
        NSDictionary *currData = [arrData objectAtIndex:indexPath.row];
        cell.textLabel.text = [NSString stringWithFormat:@"%@", [currData objectForKey:@"title"]];
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%@", [currData objectForKey:@"detail"]];
        cell.imageView.image = [UIImage imageNamed:[currData objectForKey:@"icon"]];
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self.delegate selectCategory:indexPath.row];
    [self.mm_drawerController closeDrawerAnimated:YES completion:nil];
}

@end
