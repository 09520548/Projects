//
//  BLExperiencesVC.m
//  ResumeBuildling
//
//  Created by Mobiz on 10/7/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import "BLExperiencesVC.h"
#import "UIViewController+MMDrawerController.h"
#import "BLAppDelegate.h"
#import "Exp.h"
#import "BLExperienceCell.h"

@interface BLExperiencesVC ()

@end

@implementation BLExperiencesVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.myTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    
    [self.myTableView registerNib:[UINib nibWithNibName:@"BLExperienceCell" bundle:nil ] forCellReuseIdentifier:@"BLExperienceCell"];
    
    self.lblTitle.text = @"Experience";
    arrData = [[NSMutableArray alloc] init];
    
    BLAppDelegate* appDelegate = [UIApplication sharedApplication].delegate;
    self.managedObjectContext = appDelegate.managedObjectContext;
    [self getData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
    
}

- (IBAction)showCat:(id)sender {
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}

- (IBAction)adNew:(id)sender {
    [[BLGlobal getInstance] showAlertInputAtView:self.view withPlaceData:@[@"Name", @"State", @"Detail", @"Response"]];
    [BLGlobal getInstance].customAlert.delegate = self;
}

- (IBAction)save:(id)sender {
    NSError *error;
    if (![self.managedObjectContext save:&error]) {
        NSLog(@"Whoops, couldn't save: %@", [error localizedDescription]);
    }
    else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success" message:@"Data has been saved" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
}

- (void)didClickButtonAtIndex:(NSInteger)index {
    [[BLGlobal getInstance] hideAlertView];
    if (index == 0) {
        NSString *name = [BLGlobal getInstance].customAlert.txt1.text;
        NSString *state = [BLGlobal getInstance].customAlert.txt2.text;
        NSString *detail = [BLGlobal getInstance].customAlert.txt3.text;
        NSString *response = [BLGlobal getInstance].customAlert.txt4.text;
        
        if (![name isEqualToString:@""] && ![state isEqualToString:@""] && ![detail isEqualToString:@""] && ![response isEqualToString:@""]) {
            Exp * newEntry = [NSEntityDescription insertNewObjectForEntityForName:@"Exp" inManagedObjectContext:self.managedObjectContext];
            
            newEntry.id = [NSString stringWithFormat:@"%ld", (long)(totalItem)];
            newEntry.name = name;
            newEntry.state = state;
            newEntry.detail = detail;
            newEntry.respons = response;
            
            [arrData addObject:newEntry];
            
            totalItem = arrData.count;
            
        }
        
        [self.myTableView reloadData];
    }
}

- (void)getData {
    // initializing NSFetchRequest
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    
    //Setting Entity to be Queried
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Exp"
                                              inManagedObjectContext:self.managedObjectContext];
    [fetchRequest setEntity:entity];
    NSError* error;
    
    // Query on managedObjectContext With Generated fetchRequest
    NSArray *fetchedRecords = [self.managedObjectContext executeFetchRequest:fetchRequest error:&error];
    
    if (fetchedRecords.count > 0) {
        for (Exp *exp in fetchedRecords) {
            [arrData addObject:exp];
        }
    }
    
    totalItem = arrData.count;
    
    [self.myTableView reloadData];
}

#pragma mark - TABLE
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return arrData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
//    UITableViewCell *cell = (UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"cell"];
//    if (cell == nil) {
//        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"cell"];
//        cell.backgroundColor = [UIColor clearColor];
//        cell.textLabel.textColor = [UIColor whiteColor];
//        cell.detailTextLabel.textColor = [UIColor whiteColor];
//    }
//    
//    Exp *curData = [arrData objectAtIndex:indexPath.row];
//    cell.textLabel.text = [NSString stringWithFormat:@"Name: %@ - State: %@", curData.name, curData.state];
//    cell.detailTextLabel.text = [NSString stringWithFormat:@"Detail: %@ - Response: %@", curData.detail, curData.respons];
    
    static NSString *simpleTableIdentifier = @"BLExperienceCell";
    
    BLExperienceCell *cell = (BLExperienceCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"BLExperienceCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    Exp *curData = [arrData objectAtIndex:indexPath.row];
    
    cell.lblName.text = [NSString stringWithFormat:@"Name: %@", curData.name];
    cell.lblState.text = [NSString stringWithFormat:@"State: %@", curData.state];
    cell.lblDetail.text = [NSString stringWithFormat:@"Detail: %@", curData.detail];
    cell.lblResponse.text = [NSString stringWithFormat:@"Response: %@", curData.respons];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    currSelected = indexPath.row;
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Delete Data" message:@"Are you sure to delete this data?" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Delete", @"Edit", nil];
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if ([alertView.title isEqualToString:@"Delete Data"]) {
        if (buttonIndex == 1) {
            [self.managedObjectContext deleteObject:[arrData objectAtIndex:currSelected]];
            [arrData removeObjectAtIndex:currSelected];
            NSError *error;
            if (![self.managedObjectContext save:&error]) {
                NSLog(@"Whoops, couldn't delete: %@", [error localizedDescription]);
            }
            else {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success" message:@"Data has been deleted" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                [alert show];
            }
            [self.myTableView reloadData];
        }
        else if (buttonIndex == 2) {
             Exp *curData = [arrData objectAtIndex:currSelected];
            [[BLGlobal getInstance] showAlertInputAtView:self.view withPlaceData:@[curData.name, curData.state, curData.detail, curData.respons] placeholder:@[@"Name", @"State", @"Detail", @"Response"]];
            [BLGlobal getInstance].customAlert2.delegate = self;
        }
    }
}

- (void)didClickButtonAtIndex2:(NSInteger)index {
    [[BLGlobal getInstance] hideAlertView];
    if (index == 0) {
        NSString *name = [BLGlobal getInstance].customAlert2.txt1.text;
        NSString *state = [BLGlobal getInstance].customAlert2.txt2.text;
        NSString *detail = [BLGlobal getInstance].customAlert2.txt3.text;
        NSString *response = [BLGlobal getInstance].customAlert2.txt4.text;
        
        if (![name isEqualToString:@""] && ![state isEqualToString:@""] && ![detail isEqualToString:@""] && ![response isEqualToString:@""]) {
            Exp * newEntry = [arrData objectAtIndex:currSelected];
            
            newEntry.name = name;
            newEntry.state = state;
            newEntry.detail = detail;
            newEntry.respons = response;
            
            
            [self save:nil];
            arrData = nil;
            arrData = [NSMutableArray new];
            [self getData];
            [self.myTableView reloadData];
        }
        
        
    }
}
@end
