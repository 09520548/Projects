//
//  BLExportVC.h
//  ResumeBuildling
//
//  Created by Mobiz on 10/7/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BLExportVC : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;

- (IBAction)showCat:(id)sender;
@end
