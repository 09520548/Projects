//
//  BLGlobal.m
//  ResumeBuildling
//
//  Created by Mobiz on 10/7/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import "BLGlobal.h"

@implementation BLGlobal


+(BLGlobal *) getInstance
{
    static BLGlobal *instance =nil;
    
    @synchronized(self)
    {
        if(instance==nil)
        {
            instance = [BLGlobal new];
        }
    }
    return instance;
}

- (void)showAlertInputAtView:(UIView *)view withPlaceData:(NSArray *)arrData {
    self.mainView = view;
    self.bgView = [[UIView alloc] initWithFrame:self.mainView.frame];
    [self.bgView setBackgroundColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:0.5f]];
    [self.mainView addSubview:self.bgView];
    self.customAlert = [[BLCustomAlertView alloc] initWithNumberOfInputText:arrData.count inView:view andData:arrData];
    [self.mainView addSubview:self.customAlert];
//    self.customAlert.delegate = self;
    
}

- (void)showAlertInputAtView:(UIView *)view withPlaceData:(NSArray *)arrData placeholder:(NSArray *)placeholder {
    self.mainView = view;
    self.bgView = [[UIView alloc] initWithFrame:self.mainView.frame];
    [self.bgView setBackgroundColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:0.5f]];
    [self.mainView addSubview:self.bgView];
    self.customAlert2 = [[BLCustomAlertView2 alloc] initWithNumberOfInputText:arrData.count inView:view andData:arrData placeHolder:placeholder];
    [self.mainView addSubview:self.customAlert2];
    //    self.customAlert.delegate = self;
    
}

- (void)hideAlertView {
    [self.bgView removeFromSuperview];
    [self.customAlert removeFromSuperview];
    [self.customAlert2 removeFromSuperview];
}

- (void)didClickButtonAtIndex:(NSInteger)index {
    [self hideAlertView];
}

@end
