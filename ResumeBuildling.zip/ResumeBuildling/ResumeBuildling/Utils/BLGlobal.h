//
//  BLGlobal.h
//  ResumeBuildling
//
//  Created by Mobiz on 10/7/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BLCustomAlertView.h"
#import "BLCustomAlertView2.h"

@interface BLGlobal : NSObject<BLCustomAlertViewDelegate, BLCustomAlertView2Delegate>

@property (strong, nonatomic) UIView *mainView;
@property (strong, nonatomic) UIView *bgView;
@property (strong, nonatomic) BLCustomAlertView *customAlert;
@property (strong, nonatomic) BLCustomAlertView2 *customAlert2;


+ (BLGlobal *)getInstance;

- (void)showAlertInputAtView:(UIView *)view withPlaceData:(NSArray *)arrData;
- (void)showAlertInputAtView:(UIView *)view withPlaceData:(NSArray *)arrData placeholder:(NSArray *)placeholder;
- (void)hideAlertView;

@end
