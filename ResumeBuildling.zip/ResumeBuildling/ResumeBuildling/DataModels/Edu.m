//
//  Edu.m
//  ResumeBuildling
//
//  Created by Mobiz on 10/9/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import "Edu.h"


@implementation Edu

@dynamic fromDate;
@dynamic id;
@dynamic name;
@dynamic specific;
@dynamic toDate;

@end
