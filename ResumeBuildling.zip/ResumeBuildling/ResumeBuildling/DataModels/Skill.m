//
//  Skill.m
//  ResumeBuildling
//
//  Created by Mobiz on 10/9/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import "Skill.h"


@implementation Skill

@dynamic id;
@dynamic name;

@end
