//
//  Obj.m
//  ResumeBuildling
//
//  Created by Mobiz on 10/9/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import "Obj.h"


@implementation Obj

@dynamic id;
@dynamic detail;
@dynamic position;
@dynamic company;

@end
