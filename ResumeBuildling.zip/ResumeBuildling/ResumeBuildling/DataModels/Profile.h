//
//  Profile.h
//  ResumeBuildling
//
//  Created by Mobiz on 10/8/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Profile : NSManagedObject

@property (nonatomic, retain) NSString * emai;
@property (nonatomic, retain) NSString * firstname;
@property (nonatomic, retain) NSString * id;
@property (nonatomic, retain) NSString * lastname;
@property (nonatomic, retain) NSString * phone;
@property (nonatomic, retain) NSString * state;
@property (nonatomic, retain) NSString * street;
@property (nonatomic, retain) NSString * zip;

@end
