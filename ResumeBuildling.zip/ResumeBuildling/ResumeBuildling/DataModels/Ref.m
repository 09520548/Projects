//
//  Ref.m
//  ResumeBuildling
//
//  Created by Mobiz on 10/9/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import "Ref.h"


@implementation Ref

@dynamic company;
@dynamic detail;
@dynamic id;
@dynamic name;

@end
