//
//  Profile.m
//  ResumeBuildling
//
//  Created by Mobiz on 10/8/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import "Profile.h"


@implementation Profile

@dynamic emai;
@dynamic firstname;
@dynamic id;
@dynamic lastname;
@dynamic phone;
@dynamic state;
@dynamic street;
@dynamic zip;

@end
