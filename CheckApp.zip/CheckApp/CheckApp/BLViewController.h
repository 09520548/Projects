//
//  BLViewController.h
//  CheckApp
//
//  Created by Mobiz on 11/13/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BLViewController : UIViewController

@end
