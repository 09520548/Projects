//
//  BLViewController.m
//  CheckApp
//
//  Created by Mobiz on 11/13/14.
//  Copyright (c) 2014 Mobiz. All rights reserved.
//

#import "BLViewController.h"

@interface BLViewController ()
@property (weak, nonatomic) IBOutlet UIButton *btnDownload;

@end

@implementation BLViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(checkIsDownloaded) userInfo:nil repeats:YES];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)checkIsDownloaded {
    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"checkapp:"]]) {
        self.btnDownload.hidden = YES;
    }
    else {
        self.btnDownload.hidden = NO;
    }
}

- (IBAction)open:(id)sender {
    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"checkapp:"]]) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"checkapp:"]];
    }
    else {
        NSLog(@"emd");
    }
}
@end
